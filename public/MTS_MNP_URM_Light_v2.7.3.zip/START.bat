@echo off
cd /d "%~dp0"
title MTS MNP Retention Workspace
start /min powershell -ExecutionPolicy Bypass -WindowStyle Hidden -Command "=39281; =New-Object System.Net.HttpListener; .Prefixes.Add("http://127.0.0.1:"++"/"); .Start(); while(.IsListening){ =.GetContext(); =.Request; =.Response; =.Url.LocalPath; if( -eq "/"){ ="/index.html" }; =Join-Path (Get-Location) ("app"+.Replace("/","\")); if(Test-Path ){ =[System.IO.File]::ReadAllBytes(); .ContentLength64=.Length; if(.EndsWith(".js")){.ContentType="application/javascript"}elseif(.EndsWith(".css")){.ContentType="text/css"}elseif(.EndsWith(".html")){.ContentType="text/html"}elseif(.EndsWith(".woff2")){.ContentType="font/woff2"}elseif(.EndsWith(".png")){.ContentType="image/png"}elseif(.EndsWith(".svg")){.ContentType="image/svg+xml"}; .OutputStream.Write(,0,.Length) }else{ .StatusCode=404 }; .OutputStream.Close() }"
timeout /t 1 >nul
start msedge.exe --app=http://127.0.0.1:39281/ 2>nul
if %errorlevel% neq 0 ( start chrome.exe --app=http://127.0.0.1:39281/ 2>nul )
if %errorlevel% neq 0 ( start http://127.0.0.1:39281/ )
exit
