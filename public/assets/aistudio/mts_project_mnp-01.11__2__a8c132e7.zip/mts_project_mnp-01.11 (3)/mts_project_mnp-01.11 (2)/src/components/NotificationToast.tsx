import React, { useState, useEffect } from 'react';
import { Bell, X, ArrowRight } from 'lucide-react';
import { PushNotificationPosition } from '../types';

export interface ToastItem {
  id: string;
  title: string;
  phone: string;
  attempt?: number;
  maxAttempts?: number;
  region?: string;
  leadId?: string;
  position?: PushNotificationPosition;
  timestamp: number;
}

interface ToastWithAnimation extends ToastItem {
  isEntering: boolean;
  isExiting: boolean;
  position: PushNotificationPosition;
}

interface NotificationToastContainerProps {
  position?: PushNotificationPosition;
  enabled?: boolean;
}

export const NotificationToastContainer: React.FC<NotificationToastContainerProps> = ({
  position = 'top-right',
  enabled = true,
}) => {
  const [toasts, setToasts] = useState<ToastWithAnimation[]>([]);
  const [activePosition, setActivePosition] = useState<PushNotificationPosition>(position);

  // Синхронизация с входящим пропсом position
  useEffect(() => {
    if (position) {
      setActivePosition(position);
    }
  }, [position]);

  // Слушатель событий изменения активной позиции из настроек
  useEffect(() => {
    const handleSetPosition = (e: Event) => {
      const custom = e as CustomEvent<{ position?: PushNotificationPosition }>;
      if (custom.detail?.position) {
        setActivePosition(custom.detail.position);
      }
    };

    window.addEventListener('mts-set-push-position', handleSetPosition);
    return () => window.removeEventListener('mts-set-push-position', handleSetPosition);
  }, []);

  // Слушатель появления новых тостов
  useEffect(() => {
    const handleToast = (e: Event) => {
      if (!enabled) return;

      const customEvent = e as CustomEvent<ToastItem>;
      if (!customEvent.detail) return;
      const detail = customEvent.detail;
      const targetPos: PushNotificationPosition =
        detail.position || activePosition || position || 'top-right';

      // Если в событии передана конкретная позиция, переключаем активную позицию
      setActivePosition(targetPos);

      const newId = detail.id || String(Date.now() + Math.random());
      const newToast: ToastWithAnimation = {
        ...detail,
        id: newId,
        phone: detail.phone || '+7 (916) 123-45-67',
        attempt: detail.attempt || 1,
        maxAttempts: detail.maxAttempts || 3,
        region: detail.region || 'г. Москва и Московская область',
        position: targetPos,
        isEntering: true,
        isExiting: false,
      };

      setToasts((prev) => [newToast, ...prev.slice(0, 2)]);

      // Снимаем класс начальной анимации появления через 30мс для запуска CSS transition
      requestAnimationFrame(() => {
        setTimeout(() => {
          setToasts((prev) =>
            prev.map((t) => (t.id === newId ? { ...t, isEntering: false } : t))
          );
        }, 30);
      });

      // Автоматическое скрытие через 10 секунд
      setTimeout(() => {
        dismissToast(newId);
      }, 10000);
    };

    window.addEventListener('mts-inapp-toast', handleToast);
    return () => window.removeEventListener('mts-inapp-toast', handleToast);
  }, [enabled, activePosition, position]);

  // Плавное закрытие уведомления (уезжает за край экрана)
  const dismissToast = (id: string, callback?: () => void) => {
    setToasts((prev) =>
      prev.map((t) => (t.id === id ? { ...t, isExiting: true } : t))
    );
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
      if (callback) callback();
    }, 240);
  };

  // Переход к карточке абонента с плавным уездом пуша за край
  const handleGoToCard = (toast: ToastWithAnimation) => {
    dismissToast(toast.id, () => {
      window.dispatchEvent(
        new CustomEvent('mts-focus-lead', {
          detail: { leadId: toast.leadId, phone: toast.phone },
        })
      );
    });
  };

  if (!enabled || toasts.length === 0) return null;

  // Абсолютно точное позиционирование контейнера на экране
  const getContainerStyle = (pos: PushNotificationPosition): React.CSSProperties => {
    switch (pos) {
      case 'top-left':
        return {
          top: '20px',
          left: '20px',
          right: 'auto',
          bottom: 'auto',
          transform: 'none',
          alignItems: 'flex-start',
        };
      case 'top-center':
        return {
          top: '20px',
          left: '50%',
          right: 'auto',
          bottom: 'auto',
          transform: 'translateX(-50%)',
          alignItems: 'center',
        };
      case 'bottom-right':
        return {
          bottom: '20px',
          right: '20px',
          top: 'auto',
          left: 'auto',
          transform: 'none',
          alignItems: 'flex-end',
          flexDirection: 'column-reverse',
        };
      case 'center-right':
        return {
          top: '50%',
          right: '20px',
          bottom: 'auto',
          left: 'auto',
          transform: 'translateY(-50%)',
          alignItems: 'flex-end',
        };
      case 'top-right':
      default:
        return {
          top: '20px',
          right: '20px',
          bottom: 'auto',
          left: 'auto',
          transform: 'none',
          alignItems: 'flex-end',
        };
    }
  };

  // Определение стилей анимации появления и уезда в зависимости от расположения
  const getToastStyle = (toast: ToastWithAnimation): React.CSSProperties => {
    const pos = toast.position || activePosition;
    const transition = 'transform 0.28s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.28s cubic-bezier(0.16, 1, 0.3, 1)';

    if (toast.isExiting) {
      if (pos === 'top-left') {
        return { transform: 'translateX(-120%) scale(0.95)', opacity: 0, transition, pointerEvents: 'none' };
      }
      if (pos === 'top-center') {
        return { transform: 'translateY(-120%) scale(0.95)', opacity: 0, transition, pointerEvents: 'none' };
      }
      return { transform: 'translateX(120%) scale(0.95)', opacity: 0, transition, pointerEvents: 'none' };
    }

    if (toast.isEntering) {
      switch (pos) {
        case 'top-left':
          return { transform: 'translateX(-70px) scale(0.96)', opacity: 0, transition };
        case 'top-center':
          return { transform: 'translateY(-60px) scale(0.96)', opacity: 0, transition };
        case 'bottom-right':
          return { transform: 'translateY(60px) scale(0.96)', opacity: 0, transition };
        case 'center-right':
          return { transform: 'translateX(70px) scale(0.96)', opacity: 0, transition };
        case 'top-right':
        default:
          return { transform: 'translateX(70px) scale(0.96)', opacity: 0, transition };
      }
    }

    return { transform: 'translate(0, 0) scale(1)', opacity: 1, transition };
  };

  return (
    <div
      style={getContainerStyle(activePosition)}
      className="fixed z-[9999] flex flex-col gap-3 max-w-[390px] w-full pointer-events-none transition-all duration-300"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          style={getToastStyle(toast)}
          className="pointer-events-auto bg-[#FAF8F5] rounded-3xl shadow-2xl border border-[#E8E3D9] p-4 text-[#1D2023] relative overflow-hidden"
          role="alert"
        >
          {/* Верхняя плашка: иконка МТС Напоминание и кнопка закрытия */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#EFEBE4] text-[#1D2023] flex items-center justify-center shrink-0">
                <Bell className="w-3.5 h-3.5 text-[#1D2023]" />
              </div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#626C77]">
                МТС Напоминание
              </span>
            </div>

            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              className="text-[#8C95A0] hover:text-[#1D2023] p-1 rounded-full hover:bg-[#EFEBE4] transition-colors cursor-pointer"
              title="Закрыть уведомление"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Заголовок звонка */}
          <div className="text-sm font-bold text-[#1D2023] mb-3 flex items-center gap-1.5">
            <span>🔔</span>
            <span>{toast.title || 'Требуется исходящий вызов'}</span>
          </div>

          {/* Информация: Номер телефона, Попытка, Регион (единый молочный фон без внутренних обводок) */}
          <div className="space-y-2 mb-3.5 px-1">
            {/* Номер телефона */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#7D8895]">
                Номер телефона
              </span>
              <span className="text-sm font-bold text-[#1D2023] font-mono tracking-wide">
                {toast.phone}
              </span>
            </div>

            {/* Попытка (без обводки) */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#7D8895]">
                Попытка
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EDE8E0] text-[#1D2023]">
                Попытка {toast.attempt || 1} из {toast.maxAttempts || 3}
              </span>
            </div>

            {/* Регион */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#7D8895] shrink-0">
                Регион
              </span>
              <span className="text-xs font-semibold text-[#1D2023] text-right truncate max-w-[230px]">
                {toast.region || 'г. Москва и Московская область'}
              </span>
            </div>
          </div>

          {/* Кнопка МТС стандарта: серая, округлая, с зеленой анимированной стрелкой */}
          <button
            type="button"
            onClick={() => handleGoToCard(toast)}
            className="w-full h-10 px-4 rounded-full bg-[#E9EBEF] hover:bg-[#DFE2E6] text-[#1D2023] text-xs font-bold transition-all shadow-2xs flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
          >
            <span>Перейти к карточке</span>
            <ArrowRight className="w-4 h-4 text-[#00B956] animate-arrow-pingpong shrink-0" />
          </button>
        </div>
      ))}
    </div>
  );
};
