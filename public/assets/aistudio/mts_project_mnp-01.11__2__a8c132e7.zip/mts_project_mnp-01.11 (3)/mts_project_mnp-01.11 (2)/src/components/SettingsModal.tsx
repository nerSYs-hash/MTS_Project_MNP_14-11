import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Volume2,
  Bell,
  RotateCcw,
  Download,
  Copy,
  Check,
  HelpCircle,
  RotateCw,
  Upload,
  ShieldCheck,
  Minus,
  Plus,
  Sparkles,
  PackageCheck,
  BookOpen,
  FileCheck,
} from 'lucide-react';
import { TimerSettings, ShiftStats, ClientLead, PushNotificationPosition } from '../types';
import { playChimeSound, requestNotificationPermission, sendDesktopNotification } from '../utils/audioAlert';
import { generateShiftReportText } from '../utils/storage';
import { downloadUpdateFile, CURRENT_APP_VERSION, CURRENT_UPDATE_PACKAGE, getInstalledAppVersion } from '../utils/updateManager';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TimerSettings;
  onSaveSettings: (settings: TimerSettings) => void;
  stats: ShiftStats;
  leads: ClientLead[];
  onResetShift: () => void;
  onRestoreBackup?: () => boolean;
  onImportLeadsText?: (text: string) => number;
  onSelectUpdateFile?: (file: File) => void;
  onOpenGuide?: () => void;
}

// Фирменный переключатель-тумблер МТС (iOS style switch)
const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}> = ({ checked, onChange, disabled = false }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    disabled={disabled}
    onClick={() => onChange(!checked)}
    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 ease-in-out cursor-pointer focus:outline-none ${
      disabled ? 'opacity-40 cursor-not-allowed' : ''
    } ${checked ? 'bg-[#E30613]' : 'bg-[#D5D8DD]'}`}
  >
    <span
      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
        checked ? 'translate-x-5.5' : 'translate-x-0.5'
      }`}
    />
  </button>
);

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  stats,
  leads,
  onResetShift,
  onRestoreBackup,
  onImportLeadsText,
  onSelectUpdateFile,
  onOpenGuide,
}) => {
  const updateFileInputRef = useRef<HTMLInputElement>(null);
  const [collapseDelay, setCollapseDelay] = useState(
    settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
  );
  const [headerCollapseAnimationEnabled, setHeaderCollapseAnimationEnabled] = useState(
    settings.headerCollapseAnimationEnabled !== false
  );
  const [soundEnabled, setSoundEnabled] = useState(settings.soundEnabled);
  const [volume, setVolume] = useState(settings.volume);
  const [includeWithoutTpInSaved, setIncludeWithoutTpInSaved] = useState(
    settings.includeWithoutTpInSaved !== false
  );
  const [includeEiInSaved, setIncludeEiInSaved] = useState(
    settings.includeEiInSaved !== false
  );
  const [enableNumbersAccounting, setEnableNumbersAccounting] = useState(
    settings.enableNumbersAccounting !== false
  );
  const [kpiFontWeight, setKpiFontWeight] = useState<'normal' | 'medium' | 'semibold' | 'bold'>(
    settings.kpiFontWeight || 'normal'
  );
  const [enablePushNotifications, setEnablePushNotifications] = useState(
    settings.enablePushNotifications !== false
  );
  const [pushPosition, setPushPosition] = useState<PushNotificationPosition>(
    settings.pushPosition || 'top-right'
  );
  const [notificationsGranted, setNotificationsGranted] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission === 'granted';
    }
    return false;
  });

  const [reportCopied, setReportCopied] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [showCollapseTooltip, setShowCollapseTooltip] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState<string | null>(null);
  const [showImportBox, setShowImportBox] = useState(false);
  const [importText, setImportText] = useState('');
  const [importResultMsg, setImportResultMsg] = useState<string | null>(null);

  // Синхронизация полей настроек при каждом открытии модального окна
  useEffect(() => {
    if (isOpen) {
      setCollapseDelay(
        settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
      );
      setHeaderCollapseAnimationEnabled(settings.headerCollapseAnimationEnabled !== false);
      setSoundEnabled(settings.soundEnabled);
      setVolume(settings.volume);
      setIncludeWithoutTpInSaved(settings.includeWithoutTpInSaved !== false);
      setIncludeEiInSaved(settings.includeEiInSaved !== false);
      setEnableNumbersAccounting(settings.enableNumbersAccounting !== false);
      setKpiFontWeight(settings.kpiFontWeight || 'normal');
      setEnablePushNotifications(settings.enablePushNotifications !== false);
      setPushPosition(settings.pushPosition || 'top-right');
      if (typeof window !== 'undefined' && 'Notification' in window) {
        setNotificationsGranted(Notification.permission === 'granted');
      }
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings({
      ...settings,
      collapseDelayMinutes: collapseDelay,
      headerCollapseAnimationEnabled,
      soundEnabled,
      volume,
      includeWithoutTpInSaved,
      includeEiInSaved,
      enableNumbersAccounting,
      kpiFontWeight,
      enablePushNotifications,
      pushPosition,
    });
    onClose();
  };

  const handleTestSound = () => {
    playChimeSound(volume);
  };

  const handleToggleNotifications = async (enable: boolean) => {
    if (enable) {
      const granted = await requestNotificationPermission();
      setNotificationsGranted(granted);
    } else {
      setNotificationsGranted(false);
    }
  };

  const handleCopyReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    navigator.clipboard.writeText(reportText);
    setReportCopied(true);
    setTimeout(() => setReportCopied(false), 2000);
  };

  const handleDownloadReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MTS_MNP_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Внешний расширенный контейнер max-w-2xl с округлыми углами rounded-3xl и overflow-hidden */}
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-[#F1F3F5] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Шапка модалки (зафиксирована сверху) */}
        <div className="px-6 sm:px-7 pt-5 pb-4 border-b border-[#F1F3F5] flex items-center justify-between shrink-0 bg-white">
          <div>
            <h3 className="text-lg font-bold text-[#1D2023] font-mts-extended">Настройки рабочего места</h3>
            <p className="text-xs text-[#626C77] font-normal mt-0.5">
              Сворачивание рабочего места, анимации, звук оповещений и отчет смены
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl hover:bg-gray-100 text-[#626C77] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Прокручиваемое содержимое модалки: все тумблеры выровнены строго в одну колонку справа */}
        <div className="overflow-y-auto px-6 sm:px-7 py-2 flex-1">
          {/* 1. Блок: Режим ожидания */}
          <div className="py-3.5 flex items-center justify-between gap-6">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                  Режим ожидания (сворачивание в центр)
                </span>
                <button
                  type="button"
                  onClick={() => setShowCollapseTooltip((v) => !v)}
                  className="text-[#8C95A0] p-0.5 cursor-pointer hover:text-[#1D2023] transition-colors"
                  title="Справка по режиму ожидания"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                При неактивности карточки плавно сворачиваются, блоки KPI центрируются
              </p>
            </div>
            <ToggleSwitch
              checked={collapseDelay > 0}
              onChange={(enabled) => setCollapseDelay(enabled ? 3 : 0)}
            />
          </div>

          {/* Информационная подсказка */}
          {showCollapseTooltip && (
            <div className="mb-3 p-3 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF] text-[#1D2023] text-xs leading-relaxed flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E30613] mt-1.5 shrink-0" />
              <span>
                При неактивности оператора карточка клиента и очередь плавно сворачиваются, а 4 блока KPI перемещаются в центр экрана. При наступлении времени любого перезвона всё автоматически мгновенно разворачивается!
              </span>
            </div>
          )}

          {/* Регулировка времени автосворачивания */}
          {collapseDelay > 0 && (
            <div className="mb-3.5 p-3 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF] flex items-center justify-between gap-4 flex-wrap">
              <span className="text-xs text-[#626C77] font-medium">Время до сворачивания:</span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 5, 10].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => setCollapseDelay(mins)}
                      className={`h-7 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center ${
                        collapseDelay === mins
                          ? 'bg-[#0077FF] text-white shadow-2xs'
                          : 'bg-white hover:bg-gray-100 text-[#626C77] hover:text-[#1D2023] border border-[#D5D8DD]'
                      }`}
                    >
                      {mins}м
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-xl border border-[#D5D8DD] focus-within:border-[#0077FF] focus-within:ring-1 focus-within:ring-[#0077FF]/30">
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={collapseDelay}
                    onChange={(e) => {
                      const v = parseInt(e.target.value, 10);
                      if (!isNaN(v)) {
                        setCollapseDelay(Math.min(60, Math.max(1, v)));
                      }
                    }}
                    className="w-7 text-center font-bold text-[#1D2023] text-xs focus:outline-none"
                  />
                  <span className="text-[11px] font-bold text-[#626C77]">мин</span>
                </div>
              </div>
            </div>
          )}

          {/* 2. Блок: Анимация верхней панели управления */}
          <div className="py-3.5 border-t border-[#F1F3F5] flex items-center justify-between gap-6">
            <div className="min-w-0 flex-1">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Анимация верхней панели управления
              </span>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                При сворачивании правые кнопки плавно уезжают вверх, оставляя логотип МТС и часы
              </p>
            </div>
            <ToggleSwitch
              checked={headerCollapseAnimationEnabled}
              onChange={setHeaderCollapseAnimationEnabled}
            />
          </div>

          {/* 3. Блок: Толщина цифр панели KPI (в едином стиле segmented control как фильтры) */}
          <div className="py-3.5 border-t border-[#F1F3F5] space-y-2">
            <div>
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Толщина цифр панели KPI
              </span>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                Настройка жирности цифр (Всего звонков, Сохранено, Конверсия, Ожидание)
              </p>
            </div>
            <div className="inline-flex w-full p-1 bg-[#F4F5F7] rounded-2xl gap-1 border border-[#EBECEF]">
              {[
                { key: 'normal', label: 'Обычный' },
                { key: 'medium', label: 'Средний' },
                { key: 'semibold', label: 'Полужирный' },
                { key: 'bold', label: 'Жирный' },
              ].map((w) => (
                <button
                  key={w.key}
                  type="button"
                  onClick={() => setKpiFontWeight(w.key as any)}
                  className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                    kpiFontWeight === w.key
                      ? 'bg-white text-[#1D2023] shadow-xs font-bold'
                      : 'text-[#626C77] hover:text-[#1D2023]'
                  }`}
                >
                  {w.label}
                </button>
              ))}
            </div>
          </div>

          {/* 4. Блок: Учёт детализации (выведен из серого фона, тумблеры в одну линию) */}
          <div className="py-3.5 border-t border-[#F1F3F5] flex items-center justify-between gap-6">
            <div className="min-w-0 flex-1">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Учитывать «Без смены ТП» в сохранениях
              </span>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                Засчитывать сохранения без смены ТП в общий счетчик «Сохранено клиентов» и конверсию
              </p>
            </div>
            <ToggleSwitch
              checked={includeWithoutTpInSaved}
              onChange={setIncludeWithoutTpInSaved}
            />
          </div>

          <div className="py-3.5 border-t border-[#F1F3F5] flex items-center justify-between gap-6">
            <div className="min-w-0 flex-1">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Учитывать «ЕИ» в сохранениях
              </span>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                Засчитывать сохранение по Единичному Инциденту (ЕИ) в общий счетчик «Сохранено клиентов» и конверсию
              </p>
            </div>
            <ToggleSwitch
              checked={includeEiInSaved}
              onChange={setIncludeEiInSaved}
            />
          </div>

          {/* Блок: Учёт номеров */}
          <div className="py-3.5 border-t border-[#F1F3F5] flex items-center justify-between gap-6">
            <div className="min-w-0 flex-1">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Учёт номеров
              </span>
              <p className="text-[11px] text-[#626C77] mt-0.5">
                Отображать строку ввода номеров и журнал сохранённых абонентов на рабочем месте
              </p>
            </div>
            <ToggleSwitch
              checked={enableNumbersAccounting}
              onChange={setEnableNumbersAccounting}
            />
          </div>

          {/* 5. Блок: Оповещения, Push-уведомления и Звуки */}
          <div className="py-3.5 border-t border-[#F1F3F5] space-y-3.5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-red-50 text-[#E30613] flex items-center justify-center">
                <Bell className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                  Оповещения, Push и Звуковые сигналы
                </span>
                <p className="text-[11px] text-[#626C77]">
                  Настройка всплывающих Push-карточек, расположения на экране и звука звонков
                </p>
              </div>
            </div>

            {/* Экранные Push-уведомления (дублирование блока «Требуется исходящий вызов») */}
            <div className="p-3.5 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF] space-y-3">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-[#1D2023]">
                      Всплывающие Push-уведомления (Toast)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      Дублирование
                    </span>
                  </div>
                  <p className="text-[11px] text-[#626C77] mt-0.5 leading-snug">
                    Показывать всплывающую карточку при 00:00 таймера. Статичный блок «Требуется исходящий вызов» на рабочем месте остаётся активным всегда.
                  </p>
                </div>
                <ToggleSwitch
                  checked={enablePushNotifications}
                  onChange={setEnablePushNotifications}
                />
              </div>

              {/* Выбор расположения Push-уведомлений на экране */}
              {enablePushNotifications && (
                <div className="pt-2.5 border-t border-[#EBECEF] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#1D2023]">
                      Расположение Push на экране:
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        window.dispatchEvent(
                          new CustomEvent('mts-set-push-position', {
                            detail: { position: pushPosition },
                          })
                        );
                        window.dispatchEvent(
                          new CustomEvent('mts-inapp-toast', {
                            detail: {
                              id: 'demo-test-' + Date.now(),
                              title: 'Требуется исходящий вызов',
                              phone: '+7 (921) 987-65-43',
                              attempt: 1,
                              maxAttempts: 3,
                              region: 'г. Санкт-Петербург и Ленинградская область',
                              position: pushPosition,
                              timestamp: Date.now(),
                            },
                          })
                        );
                      }}
                      className="text-[11px] font-bold text-[#0077FF] hover:text-[#0055CC] flex items-center gap-1 cursor-pointer transition-colors"
                      title="Проверить появление уведомления в выбранной позиции"
                    >
                      <Sparkles className="w-3 h-3 text-[#0077FF]" />
                      <span>Проверить Push</span>
                    </button>
                  </div>

                  {/* 5 позиций появления пуш-уведомлений */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                    {[
                      { key: 'top-right', label: 'Сверху справа', badge: 'По умолчанию', icon: '↗' },
                      { key: 'top-left', label: 'Сверху слева', badge: '', icon: '↖' },
                      { key: 'top-center', label: 'По центру сверху', badge: '', icon: '⬆' },
                      { key: 'center-right', label: 'Справа по центру', badge: '', icon: '➡' },
                      { key: 'bottom-right', label: 'Снизу справа', badge: '', icon: '↘' },
                    ].map((pos) => {
                      const isSelected = pushPosition === pos.key;
                      const handlePickPosition = (newPos: PushNotificationPosition) => {
                        setPushPosition(newPos);
                        // Немедленно переключаем позицию в контейнере тостов
                        window.dispatchEvent(
                          new CustomEvent('mts-set-push-position', {
                            detail: { position: newPos },
                          })
                        );
                        // И сразу показываем демонстрационный пуш именно из этой выбранной стороны!
                        window.dispatchEvent(
                          new CustomEvent('mts-inapp-toast', {
                            detail: {
                              id: 'pos-test-' + Date.now(),
                              title: 'Требуется исходящий вызов',
                              phone: '+7 (921) 987-65-43',
                              attempt: 1,
                              maxAttempts: 3,
                              region: 'г. Санкт-Петербург и Ленинградская область',
                              position: newPos,
                              timestamp: Date.now(),
                            },
                          })
                        );
                      };

                      return (
                        <button
                          key={pos.key}
                          type="button"
                          onClick={() => handlePickPosition(pos.key as PushNotificationPosition)}
                          className={`p-2 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                            isSelected
                              ? 'bg-white border-[#0077FF] shadow-xs ring-1 ring-[#0077FF]/40 text-[#1D2023]'
                              : 'bg-white hover:bg-gray-50 border-[#D5D8DD] text-[#626C77] hover:text-[#1D2023]'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold">{pos.icon}</span>
                            {isSelected && (
                              <span className="w-1.5 h-1.5 rounded-full bg-[#0077FF]" />
                            )}
                          </div>
                          <span className="text-xs font-bold mt-1 text-[#1D2023]">
                            {pos.label}
                          </span>
                          {pos.badge && (
                            <span className="text-[9px] font-semibold text-[#8C95A0] mt-0.5">
                              {pos.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Звуковой сигнал при 00:00 */}
            <div className="flex items-center justify-between gap-6 pt-1">
              <div className="min-w-0 flex-1">
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                  Звуковой сигнал при 00:00
                </span>
                <p className="text-[11px] text-[#626C77] mt-0.5">
                  Воспроизводить фирменный сигнал МТС при наступлении времени звонка
                </p>
              </div>
              <div className="flex items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={handleTestSound}
                  title="Проверить звук звонка"
                  className="w-8 h-8 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer shrink-0 border border-[#D5D8DD]"
                >
                  <Volume2 className="w-4 h-4 text-[#1D2023]" />
                </button>
                <ToggleSwitch
                  checked={soundEnabled}
                  onChange={setSoundEnabled}
                />
              </div>
            </div>

            {/* Ползунок громкости */}
            <div className="flex items-center gap-3">
              <span className="text-xs text-[#626C77] shrink-0">Громкость звука:</span>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="flex-1 accent-[#E30613] cursor-pointer h-1.5 bg-gray-200 rounded-lg"
              />
              <span className="text-xs font-bold text-[#1D2023] w-9 text-right tabular-nums shrink-0">
                {Math.round(volume * 100)}%
              </span>
            </div>

            {/* Всплывающие системные уведомления Windows / macOS браузера */}
            <div className="flex items-center justify-between gap-6 pt-1">
              <div className="min-w-0 flex-1">
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                  Системные уведомления ОС / браузера
                </span>
                <p className="text-[11px] text-[#626C77] mt-0.5">
                  Отправлять нативные уведомления Windows / macOS, если вкладка свёрнута
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    sendDesktopNotification({
                      title: 'Требуется исходящий вызов',
                      phone: '+7 (916) 123-45-67',
                      attempt: 1,
                      maxAttempts: 3,
                      region: 'Москва',
                    });
                  }}
                  title="Показать тестовое системное уведомление"
                  className="h-7 px-2.5 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-[11px] font-semibold transition-colors cursor-pointer border border-[#D5D8DD]"
                >
                  Тест
                </button>
                <ToggleSwitch
                  checked={notificationsGranted}
                  onChange={handleToggleNotifications}
                />
              </div>
            </div>
          </div>

          {/* 6. Отчёт смены */}
          <div className="pt-3 border-t border-[#F1F3F5] space-y-2.5">
            <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
              Отчёт смены
            </span>
            <div className="p-3 bg-[#F4F5F7] rounded-2xl text-xs space-y-1 font-mono text-[#1D2023] border border-[#EBECEF]">
              <div>• Всего звонков: {stats.totalCallsCount}</div>
              <div>• Сохранено клиентов: {stats.savedCount}</div>
              <div>• Конверсия смены: {stats.conversionRate.toFixed(1)}%</div>
            </div>

            <div className="flex items-center gap-2 pt-0.5">
              <button
                type="button"
                onClick={handleCopyReport}
                className="flex-1 h-9 px-3 rounded-xl bg-[#F4F5F7] hover:bg-[#E9ECEF] border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
              >
                {reportCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{reportCopied ? 'Скопировано в буфер' : 'Скопировать отчёт'}</span>
              </button>
              <button
                type="button"
                onClick={handleDownloadReport}
                className="h-9 px-3.5 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-[#EBECEF]"
              >
                <Download className="w-4 h-4 text-[#626C77]" />
                <span>Файл .txt</span>
              </button>
            </div>
          </div>

          {/* 7. Резервные копии и восстановление заявок */}
          <div className="pt-3 border-t border-[#F1F3F5] space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                Резервные копии и восстановление
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onRestoreBackup) {
                      const ok = onRestoreBackup();
                      if (ok) {
                        setRestoreFeedback('Рабочие заявки успешно восстановлены из резервной копии!');
                        setTimeout(() => setRestoreFeedback(null), 3500);
                      } else {
                        setRestoreFeedback('Резервная копия пуста или еще не была создана.');
                        setTimeout(() => setRestoreFeedback(null), 3500);
                      }
                    }
                  }}
                  className="text-xs font-bold text-[#1D2023] hover:text-[#E30613] flex items-center gap-1 cursor-pointer transition-colors"
                  title="Восстановить предыдущий список заявок из автосохраненного бэкапа"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Восстановить из авто-бэкапа</span>
                </button>
              </div>
            </div>

            {restoreFeedback && (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center gap-2 animate-in fade-in">
                <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{restoreFeedback}</span>
              </div>
            )}

            {/* Быстрый импорт номеров списком */}
            <div>
              {!showImportBox ? (
                <button
                  type="button"
                  onClick={() => setShowImportBox(true)}
                  className="text-xs text-[#626C77] hover:text-[#1D2023] font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-[#626C77]" />
                  <span>Вставить номера списком для восстановления (Excel / CRM / Блокнот)</span>
                </button>
              ) : (
                <div className="p-3 bg-[#F4F5F7] rounded-2xl border border-[#D5D8DD] space-y-2">
                  <label className="text-[11px] font-bold text-[#1D2023] block">
                    Вставьте номера абонентов (каждый с новой строки или через запятую):
                  </label>
                  <textarea
                    value={importText}
                    onChange={(e) => setImportText(e.target.value)}
                    placeholder="+7 (912) 000-00-00&#10;+79270000000&#10;89991234567..."
                    rows={3}
                    className="w-full p-2.5 rounded-xl bg-white border border-[#D5D8DD] text-xs font-mono text-[#1D2023] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none"
                  />
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-[#626C77]">
                      Регионы и таймеры рассчитаются автоматически
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setShowImportBox(false);
                          setImportText('');
                        }}
                        className="px-2.5 py-1 text-xs text-[#626C77] hover:text-[#1D2023] cursor-pointer"
                      >
                        Отмена
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (onImportLeadsText && importText.trim()) {
                            const count = onImportLeadsText(importText);
                            setImportResultMsg(`Успешно добавлено ${count} заявок в очередь!`);
                            setImportText('');
                            setShowImportBox(false);
                            setTimeout(() => setImportResultMsg(null), 3000);
                          }
                        }}
                        className="px-3.5 py-1 rounded-xl bg-[#E30613] hover:bg-[#C40510] text-white text-xs font-bold cursor-pointer"
                      >
                        Импортировать
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {importResultMsg && (
                <div className="mt-1.5 p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800">
                  {importResultMsg}
                </div>
              )}
            </div>
          </div>

          {/* 8. Центр обновлений УРМ */}
          <div className="pt-3.5 border-t border-[#F1F3F5] space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E30613]" />
                <span>Центр обновлений УРМ</span>
              </span>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                getInstalledAppVersion() === '2.7.3'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                v{getInstalledAppVersion()} {getInstalledAppVersion() === '2.7.3' ? '(Обновление активно ✅)' : '(Ожидает обновления)'}
              </span>
            </div>

            <p className="text-[11px] text-[#626C77] leading-relaxed">
              Быстрое и безопасное обновление: скачайте мини-файл <strong>.mtsupdate (1.5 МБ)</strong> и просто перетащите его прямо в окно программы. Все таймеры, клиенты и статистика сохраняются на 100%.
            </p>

            {/* Блок переключения версий для проверки обновления */}
            {getInstalledAppVersion() === '2.7.3' ? (
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between gap-3">
                <div className="text-xs text-emerald-900 leading-snug">
                  <span className="font-bold block">🟢 Версия 2.7.3 активна и готова к работе!</span>
                  <span className="text-[11px] text-emerald-700">Хотите проверить работу обновления? Нажмите кнопку сброса на 2.7.2.</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    localStorage.setItem('mts_app_installed_version', '2.7.2');
                    localStorage.removeItem('mts_dynamic_bundle_js');
                    localStorage.removeItem('mts_dynamic_bundle_css');
                    localStorage.removeItem('mts_app_last_update_pkg');
                    window.location.reload();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 text-xs font-bold hover:bg-emerald-100 transition-colors cursor-pointer shrink-0 shadow-2xs"
                  title="Сбросить локальную версию на 2.7.2, чтобы заново перетащить файл и проверить процесс обновления"
                >
                  Сбросить на 2.7.2 для теста
                </button>
              </div>
            ) : (
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between gap-3">
                <div className="text-xs text-amber-900 leading-snug">
                  <span className="font-bold block">🟡 Установлена версия 2.7.2 (Тестовый режим)</span>
                  <span className="text-[11px] text-amber-700">Перетащите скачанный файл .mtsupdate на экран или выберите его ниже.</span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {/* Главная кнопка: Скачать файл обновления .mtsupdate (1.5 МБ) */}
              <button
                type="button"
                onClick={() => downloadUpdateFile('2.7.3')}
                title="Скачать мини-файл update_v2.7.3.mtsupdate (1.5 МБ) для быстрой рассылки сотрудникам"
                className="h-10 px-3 rounded-xl bg-[#E30613] hover:bg-[#C50410] text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <Download className="w-4 h-4 text-white" />
                <span>Файл .mtsupdate (1.5 МБ)</span>
              </button>

              {/* Кнопка 2: Скачать app.asar для замены в папке программы */}
              <a
                href="/app.asar"
                download="app.asar"
                title="Скачать app.asar (10 МБ). Заменяется в 1 клик в папке resources/app.asar на компьютере"
                className="h-10 px-3 rounded-xl bg-[#1D2023] hover:bg-[#343A40] text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <span>Файл app.asar (10 МБ)</span>
              </a>
            </div>

            <div className="pt-0.5 flex items-center">
              {/* Кнопка выбрать файл вручную */}
              <button
                type="button"
                onClick={() => updateFileInputRef.current?.click()}
                title="Выбрать файл .mtsupdate или .json для установки обновления"
                className="w-full h-8 px-3 rounded-xl bg-white hover:bg-[#F4F5F7] border border-[#D5D8DD] text-[#626C77] hover:text-[#1D2023] text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <PackageCheck className="w-3.5 h-3.5 text-[#0077FF]" />
                <span>Установить из файла .mtsupdate на этом ПК</span>
              </button>

              <input
                ref={updateFileInputRef}
                type="file"
                accept=".mtsupdate,.json,application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file && onSelectUpdateFile) {
                    onSelectUpdateFile(file);
                    onClose();
                  }
                  e.target.value = '';
                }}
              />
            </div>
          </div>

          {/* 9. Руководство оператора (Гайд по функциям) */}
          {onOpenGuide && (
            <div className="pt-3.5 border-t border-[#F1F3F5] flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#1D2023] flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#E30613]" />
                  <span>Руководство оператора (Гайд)</span>
                </div>
                <p className="text-[11px] text-[#626C77] mt-0.5">
                  Интерактивный тур с описанием ключевых функций и скриншотами
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenGuide();
                }}
                className="h-8 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-[#E30613] text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border border-red-200 shadow-2xs"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Открыть тур</span>
              </button>
            </div>
          )}

          {/* 10. Сброс смены */}
          <div className="pt-3 border-t border-[#F1F3F5] flex items-center justify-between gap-3 text-xs">
            {confirmReset ? (
              <div className="flex items-center gap-2">
                <span className="text-[#E30613] font-bold">Сбросить счетчики смены?</span>
                <button
                  type="button"
                  onClick={() => {
                    onResetShift();
                    setConfirmReset(false);
                  }}
                  className="px-3 py-1 bg-[#E30613] text-white rounded-lg font-bold cursor-pointer"
                >
                  Да
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 text-gray-500 hover:text-black cursor-pointer"
                >
                  Отмена
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="text-[#E30613] hover:underline font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Сбросить счетчики смены</span>
              </button>
            )}
          </div>
        </div>

        {/* Нижние кнопки (зафиксированы снизу) */}
        <div className="px-6 py-4 border-t border-[#F1F3F5] flex items-center justify-end gap-2.5 shrink-0 bg-white">
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-5 rounded-xl border border-[#D5D8DD] hover:bg-gray-50 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer"
          >
            Закрыть
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="h-10 px-6 rounded-xl bg-[#E30613] hover:bg-[#C50410] active:scale-[0.98] text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};
