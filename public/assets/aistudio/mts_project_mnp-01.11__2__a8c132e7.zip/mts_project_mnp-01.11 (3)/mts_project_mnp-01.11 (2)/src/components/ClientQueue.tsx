import React, { useState } from 'react';
import { Search, PhoneCall, CheckCircle2, Clock, PhoneOff } from 'lucide-react';
import { ClientLead, CallStatus } from '../types';
import { ClientCard } from './ClientCard';

interface ClientQueueProps {
  leads: ClientLead[];
  onUpdateStatus: (
    id: string,
    newStatus: CallStatus,
    options?: {
      customTimerMinutes?: number;
      notes?: string;
      isClientAgreed?: boolean;
      attemptCount?: number;
    }
  ) => void;
  onDeleteLead: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onUpdateLead?: (id: string, updates: Partial<ClientLead>) => void;
  getRemainingTime: (targetTimestamp: number | null) => {
    totalSeconds: number;
    isExpired: boolean;
    formatted: string;
    isOverdue: boolean;
  };
  highlightedLeadId?: string | null;
}

type TabType = 'all' | 'due' | 'auto' | 'callback' | 'saved' | 'refused';

export const ClientQueue: React.FC<ClientQueueProps> = ({
  leads,
  onUpdateStatus,
  onDeleteLead,
  onUpdateNotes,
  onUpdateLead,
  getRemainingTime,
  highlightedLeadId,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Сортировка очереди:
  // - Завершенные (сохранен/отказ) уходят в конец общего списка
  // - В табе «Пора звонить» первыми идут самые срочные
  // - Новая заполненная заявка (авто или перезвон) ВСЕГДА ПОДНИМАЕТСЯ ПЕРВОЙ НАВЕРХ!
  const sortedLeads = [...leads].sort((a, b) => {
    const isDoneA = a.status === 'saved' || a.status === 'refused' || a.status === 'unreachable';
    const isDoneB = b.status === 'saved' || b.status === 'refused' || b.status === 'unreachable';
    if (isDoneA && !isDoneB) return 1;
    if (!isDoneA && isDoneB) return -1;

    if (activeTab === 'due') {
      const timeA = a.targetCallbackTime || Number.MAX_SAFE_INTEGER;
      const timeB = b.targetCallbackTime || Number.MAX_SAFE_INTEGER;
      return timeA - timeB;
    }

    // Новые заявки всегда первой в списке (по дате добавления)
    return (b.createdAt || 0) - (a.createdAt || 0);
  });

  // Активные клиенты в очереди (ожидающие звонка)
  const activeLeads = leads.filter(
    (l) => l.status !== 'saved' && l.status !== 'refused' && l.status !== 'unreachable'
  );
  const isAutoLead = (l: ClientLead) => {
    return Boolean(l.isAnsweringMachineForced || l.status === 'answering_machine' || !l.scheduledByAgreedTime);
  };

  const autoLeads = activeLeads.filter(isAutoLead);
  const callbackLeads = activeLeads.filter((l) => !isAutoLead(l));

  const dueLeads = activeLeads.filter((l) => {
    if (l.targetCallbackTime) {
      return getRemainingTime(l.targetCallbackTime).isExpired;
    }
    return false;
  });

  // Точный подсчет количества по табам: auto + callback = activeLeads.length
  const counts = {
    all: leads.length,
    due: dueLeads.length,
    auto: autoLeads.length,
    callback: callbackLeads.length,
    saved: leads.filter((l) => l.status === 'saved').length,
    refused: leads.filter((l) => l.status === 'refused').length,
  };

  // Фильтрация
  const filteredLeads = sortedLeads.filter((lead) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchPhone = lead.phone.toLowerCase().includes(q) || lead.rawPhone.includes(q);
      const matchCity = lead.city.toLowerCase().includes(q);
      const matchNotes = lead.notes.toLowerCase().includes(q);
      if (!matchPhone && !matchCity && !matchNotes) return false;
    }

    if (activeTab === 'all') return true;
    if (activeTab === 'due') {
      if (lead.targetCallbackTime) {
        return getRemainingTime(lead.targetCallbackTime).isExpired;
      }
      return false;
    }
    if (activeTab === 'auto') {
      return (
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable' &&
        isAutoLead(lead)
      );
    }
    if (activeTab === 'callback') {
      return (
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable' &&
        !isAutoLead(lead)
      );
    }
    if (activeTab === 'saved') return lead.status === 'saved';
    if (activeTab === 'refused') return lead.status === 'refused';

    return true;
  });

  return (
    <section className="space-y-4">
      {/* Панель табов и поиска */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3 sm:p-4 rounded-3xl border border-[#F1F3F5] shadow-mts-card">
        {/* Переключатели фильтров (без иконок, без подсчета, стиль переключателя) */}
        <div className="inline-flex p-1 bg-[#F4F5F7] rounded-2xl gap-1 border border-[#EBECEF] overflow-x-auto scrollbar-none max-w-full">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'all'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            Все
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('due')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'due'
                ? 'bg-white text-[#E30613] shadow-xs font-bold'
                : 'text-[#626C77] hover:text-[#E30613]'
            }`}
          >
            Пора звонить
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('auto')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'auto'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            Автоответчик
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('callback')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'callback'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            Перезвон
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'saved'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            Сохранение
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('refused')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              activeTab === 'refused'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            Отказы
          </button>
        </div>

        {/* Быстрый поиск (синяя 2px обводка при фокусе) */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-[#8C95A0] absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Поиск по номеру, городу..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') e.currentTarget.blur();
            }}
            className="w-full h-10 pl-9 pr-3.5 rounded-xl border border-[#D5D8DD] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none text-xs text-[#1D2023] bg-white placeholder-[#8C95A0]"
          />
        </div>
      </div>

      {/* Список карточек клиентов */}
      {filteredLeads.length > 0 ? (
        <div className="space-y-3 pt-2 px-1">
          {filteredLeads.map((lead, index) => {
            const timeInfo = getRemainingTime(lead.targetCallbackTime);
            const isMostUrgent = index === 0 && timeInfo.isExpired;
            const isHighlighted = highlightedLeadId === lead.id;

            return (
              <ClientCard
                key={lead.id}
                lead={lead}
                onUpdateStatus={onUpdateStatus}
                onDeleteLead={onDeleteLead}
                onUpdateNotes={onUpdateNotes}
                onUpdateLead={onUpdateLead}
                remainingTime={timeInfo}
                isMostUrgent={isMostUrgent}
                isHighlighted={isHighlighted}
              />
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-10 border border-[#F1F3F5] shadow-mts-card text-center">
          <div className="w-14 h-14 rounded-2xl bg-[#F4F5F7] text-[#626C77] flex items-center justify-center mx-auto mb-3">
            <PhoneCall className="w-6 h-6 text-[#8C95A0]" />
          </div>
          <h3 className="text-base font-bold text-[#1D2023]">В этой вкладке пока нет заявок</h3>
          <p className="text-xs text-[#626C77] font-normal mt-1 max-w-md mx-auto">
            {searchQuery
              ? 'По запросу ничего не найдено.'
              : 'Внесите номер абонента в Карточку Клиента выше, чтобы записать звонок.'}
          </p>
        </div>
      )}
    </section>
  );
};
