import React, { useState } from 'react';
import { Star, X, Check } from 'lucide-react';
import { loadQuickPhrasesFromStorage, saveQuickPhrasesToStorage } from '../utils/quickPhrases';

interface QuickPhrasesPickerProps {
  onSelectPhrase: (phrase: string) => void;
  compact?: boolean;
}

export const QuickPhrasesPicker: React.FC<QuickPhrasesPickerProps> = ({
  onSelectPhrase,
}) => {
  const [phrases, setPhrases] = useState<string[]>(() => loadQuickPhrasesFromStorage());
  const [isAdding, setIsAdding] = useState(false);
  const [newPhraseText, setNewPhraseText] = useState('');

  const handleAddPhrase = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newPhraseText.trim();
    if (!trimmed) return;
    if (!phrases.includes(trimmed)) {
      const updated = [trimmed, ...phrases];
      setPhrases(updated);
      saveQuickPhrasesToStorage(updated);
    }
    setNewPhraseText('');
    setIsAdding(false);
  };

  const handleDeletePhrase = (e: React.MouseEvent, phraseToDelete: string) => {
    e.stopPropagation();
    const updated = phrases.filter((p) => p !== phraseToDelete);
    setPhrases(updated);
    saveQuickPhrasesToStorage(updated);
  };

  return (
    <div className="space-y-1.5 pt-0.5">
      <div className="flex items-center justify-end gap-2">
        {!isAdding ? (
          <button
            type="button"
            onClick={() => setIsAdding(true)}
            title="Добавить фразу"
            className="w-6 h-6 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#8C95A0] hover:text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer border border-[#E4E7EC]"
          >
            <Star className="w-3.5 h-3.5 text-[#8C95A0]" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              setIsAdding(false);
              setNewPhraseText('');
            }}
            className="text-[11px] font-medium text-[#626C77] hover:text-[#1D2023] cursor-pointer"
          >
            Отмена
          </button>
        )}
      </div>

      {/* Быстрое добавление новой фразы в накопленный список (без вложенного form) */}
      {isAdding && (
        <div className="flex items-center gap-1.5 animate-in fade-in duration-150">
          <input
            type="text"
            value={newPhraseText}
            onChange={(e) => setNewPhraseText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                e.stopPropagation();
                handleAddPhrase();
              }
            }}
            placeholder="Введите фразу..."
            autoFocus
            className="flex-1 h-7 px-2.5 rounded-lg bg-white border border-[#D5D8DD] text-xs text-[#1D2023] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/20 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => handleAddPhrase()}
            disabled={!newPhraseText.trim()}
            className="h-7 px-2.5 rounded-lg bg-[#F4F5F7] hover:bg-[#E9ECEF] border border-[#D5D8DD] disabled:opacity-50 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
          >
            <Check className="w-3 h-3 text-[#626C77]" />
            <span>Сохранить</span>
          </button>
        </div>
      )}

      {/* Список фраз, наполняемый оператором в течение дня */}
      {phrases.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 max-h-32 overflow-y-auto pr-1">
          {phrases.map((phrase) => (
            <div
              key={phrase}
              onClick={() => onSelectPhrase(phrase)}
              className="group inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#F8F9FA] hover:bg-gray-100 border border-[#E9ECEF] text-xs text-[#1D2023] transition-all cursor-pointer shadow-2xs select-none"
              title="Нажмите, чтобы вставить в заметку"
            >
              <span className="truncate max-w-[240px] sm:max-w-[340px]">{phrase}</span>
              <button
                type="button"
                onClick={(e) => handleDeletePhrase(e, phrase)}
                title="Удалить из быстрых фраз"
                className="opacity-0 group-hover:opacity-100 p-0.5 rounded-md hover:bg-red-50 text-slate-400 hover:text-[#FF0032] transition-opacity cursor-pointer shrink-0"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
