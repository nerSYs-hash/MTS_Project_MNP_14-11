import React, { useState } from 'react';
import {
  Monitor,
  X,
  Download,
  Copy,
  Check,
  ExternalLink,
  Laptop,
  Sparkles,
  Info,
  PackageCheck,
  Terminal,
} from 'lucide-react';
import { downloadWindowsUrlShortcut, downloadWindowsAppLauncher } from '../utils/desktopLauncher';

interface DesktopInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  onInstall: () => Promise<boolean>;
}

export const DesktopInstallModal: React.FC<DesktopInstallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'exe' | 'pwa'>('exe');

  if (!isOpen) return null;

  const currentUrl = window.location.href;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    if (id === 'link') {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } else {
      setCopiedCommand(id);
      setTimeout(() => setCopiedCommand(null), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-6 border border-[#F1F3F5] shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Шапка */}
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F5]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#E30613] text-white flex items-center justify-center font-extrabold shadow-mts-red shrink-0">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-[#1D2023]">
                Установка на компьютер Windows
              </h3>
              <p className="text-xs text-[#626C77] font-normal mt-0.5">
                Конфигурация Electron EXE установщика и запуск на рабочем столе
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl hover:bg-gray-100 text-[#626C77] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Переключатель табов */}
        <div className="flex items-center gap-2 p-1 bg-[#F4F5F7] rounded-2xl">
          <button
            type="button"
            onClick={() => setActiveTab('exe')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'exe'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            <PackageCheck className="w-4 h-4 text-[#E30613]" />
            <span>Сборка EXE (Electron)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'pwa'
                ? 'bg-white text-[#1D2023] shadow-xs'
                : 'text-[#626C77] hover:text-[#1D2023]'
            }`}
          >
            <Laptop className="w-4 h-4 text-[#0077FF]" />
            <span>Быстрый ярлык Windows</span>
          </button>
        </div>

        {activeTab === 'exe' ? (
          <div className="space-y-3 animate-in fade-in duration-150">
            {/* Блок конфигурации Electron */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-2.5">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#0077FF]" />
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                  Конфигурация Electron добавлена в проект!
                </span>
              </div>
              <p className="text-xs text-[#1D2023] leading-relaxed">
                В проект добавлены:
              </p>
              <ul className="text-xs text-[#626C77] space-y-1 list-disc pl-5">
                <li><code className="text-[#1D2023] font-bold">electron/main.cjs</code> — запуск изолированного десктопного окна Windows с иконкой МТС.</li>
                <li><code className="text-[#1D2023] font-bold">electron-builder.json</code> — настройки генератора установщика NSIS (.exe) и портативной версии (.exe).</li>
                <li>Скрипты сборщика в <code className="text-[#1D2023] font-bold">package.json</code>.</li>
              </ul>
            </div>

            {/* Команды для терминала */}
            <div className="p-4 rounded-2xl bg-[#F4F5F7] border border-[#E2E8F0] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-[#E30613]" />
                  Команды сборки EXE для Windows:
                </span>
              </div>

              {/* Команда 1: Сборка установщика */}
              <div className="space-y-1">
                <span className="text-[11px] text-[#626C77] font-semibold">1. Собрать полный установщик (Setup.exe):</span>
                <div className="flex items-center gap-2 bg-[#1D2023] text-white p-2 rounded-xl text-xs font-mono">
                  <span className="flex-1 overflow-x-auto">npm run dist:win</span>
                  <button
                    type="button"
                    onClick={() => handleCopy('npm run dist:win', 'dist:win')}
                    className="p-1 rounded-lg hover:bg-white/20 transition-colors cursor-pointer text-slate-300 hover:text-white"
                  >
                    {copiedCommand === 'dist:win' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Команда 2: Сборка портативного EXE */}
              <div className="space-y-1">
                <span className="text-[11px] text-[#626C77] font-semibold">2. Собрать портативный .exe (работает без установки):</span>
                <div className="flex items-center gap-2 bg-[#1D2023] text-white p-2 rounded-xl text-xs font-mono">
                  <span className="flex-1 overflow-x-auto">npm run dist:portable</span>
                  <button
                    type="button"
                    onClick={() => handleCopy('npm run dist:portable', 'dist:portable')}
                    className="p-1 rounded-lg hover:bg-white/20 transition-colors cursor-pointer text-slate-300 hover:text-white"
                  >
                    {copiedCommand === 'dist:portable' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Команда 3: Локальный запуск десктопного окна */}
              <div className="space-y-1">
                <span className="text-[11px] text-[#626C77] font-semibold">3. Проверить запуск окна Electron:</span>
                <div className="flex items-center gap-2 bg-[#1D2023] text-white p-2 rounded-xl text-xs font-mono">
                  <span className="flex-1 overflow-x-auto">npm run electron:start</span>
                  <button
                    type="button"
                    onClick={() => handleCopy('npm run electron:start', 'electron:start')}
                    className="p-1 rounded-lg hover:bg-white/20 transition-colors cursor-pointer text-slate-300 hover:text-white"
                  >
                    {copiedCommand === 'electron:start' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-[#626C77]">
                Готовые исполняемые файлы <code className="text-[#1D2023] font-bold">.exe</code> автоматически сохраняются в папку <code className="text-[#1D2023] font-bold">release/</code>.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3 animate-in fade-in duration-150">
            {/* СПОСОБ: Скачать ярлык в 1 клик */}
            <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-2.5">
              <span className="text-[11px] font-bold text-[#E30613] uppercase tracking-wider block">
                Запуск в отдельном окне без сборщика
              </span>
              <p className="text-xs text-[#1D2023]">
                Скачайте файл запуска на рабочий стол компьютера. При двойном клике приложение откроется в отдельном чистом окне:
              </p>

              <div className="flex flex-col sm:flex-row gap-2 pt-1">
                <button
                  type="button"
                  onClick={downloadWindowsAppLauncher}
                  className="flex-1 h-10 px-4 rounded-xl bg-[#E30613] hover:bg-[#C50410] active:scale-[0.98] text-white text-xs font-bold uppercase tracking-wider shadow-mts-red transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Скачать запуск в окне (.bat)</span>
                </button>

                <button
                  type="button"
                  onClick={downloadWindowsUrlShortcut}
                  className="h-10 px-4 rounded-xl bg-white hover:bg-gray-100 border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Laptop className="w-4 h-4 text-[#0077FF]" />
                  <span>Ярлык на стол (.url)</span>
                </button>
              </div>
            </div>

            {/* Яндекс Браузер */}
            <div className="p-4 rounded-2xl bg-[#F4F5F7] border border-[#E2E8F0] space-y-2">
              <div className="text-xs font-bold text-[#1D2023] uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-4 h-4 text-[#0077FF]" />
                <span>Через меню браузера (Яндекс / Chrome / Edge)</span>
              </div>
              <ol className="text-xs text-[#1D2023] space-y-1.5 pl-4 list-decimal">
                <li>Нажмите меню браузера <strong>≡</strong> в правом верхнем углу.</li>
                <li>Выберите <strong>«Дополнительно»</strong> → <strong>«Создать ярлык...»</strong>.</li>
                <li>Отметьте <strong>«Открывать в отдельном окне»</strong> и нажмите «Создать».</li>
              </ol>
            </div>
          </div>
        )}

        {/* Ссылка на приложение */}
        <div className="p-3 bg-white rounded-2xl border border-[#E2E8F0] flex items-center gap-2">
          <input
            type="text"
            readOnly
            value={currentUrl}
            className="flex-1 h-9 px-3 rounded-xl bg-[#F4F5F7] border border-[#D5D8DD] text-xs text-[#1D2023] font-mono outline-none focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30"
          />
          <button
            type="button"
            onClick={() => handleCopy(currentUrl, 'link')}
            className="h-9 px-3 rounded-xl bg-[#F4F5F7] hover:bg-[#E9ECEF] border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shrink-0"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-[#626C77]" />}
            <span>{copiedLink ? 'Скопировано' : 'Копировать'}</span>
          </button>
          <a
            href={currentUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="h-9 px-3 rounded-xl bg-[#0077FF] hover:bg-[#0055CC] text-white text-xs font-bold transition-colors flex items-center gap-1 shrink-0"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Открыть</span>
          </a>
        </div>

        {/* Нижняя кнопка закрытия */}
        <div className="pt-2 border-t border-[#F1F3F5] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-6 rounded-xl bg-[#F4F5F7] hover:bg-[#E9ECEF] border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-colors cursor-pointer"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
