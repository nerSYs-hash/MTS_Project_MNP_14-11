import React, { useState } from 'react';
import { UserCheck, PhoneCall, TrendingUp, Timer, Plus, Minus, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { ShiftStats } from '../types';
import { formatContactsCount, formatSubscribersCount } from '../utils/pluralize';

interface KpiDashboardProps {
  stats: ShiftStats;
  activeTimersCount: number;
  dueTimersCount: number;
  autoCallbacksCount?: number;
  clientAgreedCallbacksCount?: number;
  onAdjustCalls: (delta: number) => void;
  onAdjustSaved: (delta: number) => void;
  onAdjustSavedWithoutTpChange?: (delta: number) => void;
  onAdjustSavedWithEi?: (delta: number) => void;
  onManualSzDeductWithoutTp?: () => void;
  onManualSzDeductEi?: () => void;
  onManualSzAddWithoutTp?: () => void;
  onManualSzAddEi?: () => void;
  onFocusDueQueue?: () => void;
  kpiFontWeight?: 'normal' | 'medium' | 'semibold' | 'bold';
  isCallsPulsing?: boolean;
  isSavedPulsing?: boolean;
  includeWithoutTpInSaved?: boolean;
  includeEiInSaved?: boolean;
}

export const KpiDashboard: React.FC<KpiDashboardProps> = ({
  stats,
  activeTimersCount,
  dueTimersCount,
  autoCallbacksCount = 0,
  clientAgreedCallbacksCount = 0,
  onAdjustCalls,
  onAdjustSaved,
  onAdjustSavedWithoutTpChange,
  onAdjustSavedWithEi,
  onFocusDueQueue,
  kpiFontWeight = 'normal',
  isCallsPulsing = false,
  isSavedPulsing = false,
}) => {
  const [showSyncTooltip, setShowSyncTooltip] = useState(false);
  const [isSavedTabOpen, setIsSavedTabOpen] = useState(false);

  const weightClass =
    kpiFontWeight === 'bold'
      ? 'font-bold'
      : kpiFontWeight === 'semibold'
      ? 'font-semibold'
      : kpiFontWeight === 'medium'
      ? 'font-medium'
      : 'font-normal';

  // Вычисляем процент конверсии
  const conversionDisplay = stats.totalCallsCount > 0 ? stats.conversionRate.toFixed(1) : '0.0';

  const hasQueue = activeTimersCount > 0 || dueTimersCount > 0;

  return (
    <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch">
      {/* 1. ВСЕГО ИСХОДЯЩИХ ЗВОНКОВ ЗА СМЕНУ */}
      <div className="rounded-3xl p-5 shadow-mts-card flex flex-col justify-between h-[148px] relative transition-all duration-300 bg-white border border-[#F1F3F5]">

        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-[#626C77] uppercase tracking-wider">
            Звонки
          </span>
          <div className="w-9 h-9 rounded-2xl bg-blue-50 text-[#0077FF] flex items-center justify-center shrink-0">
            <PhoneCall className="w-5 h-5" />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span
              className={`text-3xl sm:text-4xl ${weightClass} text-[#1D2023] tracking-tight font-mts-compact transition-transform ${
                isCallsPulsing ? 'animate-value-pop' : ''
              }`}
            >
              {stats.totalCallsCount}
            </span>
            <span className="text-xs text-[#626C77] font-normal">
              {formatContactsCount(stats.totalCallsCount)}
            </span>
          </div>

          {/* Быстрые кнопки ручного + / - для оператора */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAdjustCalls(-1)}
              title="Отнять 1 звонок (если ошиблись)"
              className="w-8 h-8 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors text-xs font-bold cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onAdjustCalls(1)}
              title="Добавить звонок (+)"
              className="w-9 h-9 rounded-2xl bg-blue-50 hover:bg-blue-100 text-[#0077FF] flex items-center justify-center transition-colors font-bold shadow-2xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Пустая нижняя распорка для синхронной базовой линии со 2, 3 и 4 карточками */}
        <div className="h-4" />
      </div>

      {/* 2. СОХРАНЕНИЕ С ВЫДВИЖНОЙ ШТОРКОЙ ДЕТАЛИЗАЦИИ (ТП • ЕИ) */}
      <div
        onMouseLeave={() => setIsSavedTabOpen(false)}
        className="rounded-3xl p-5 shadow-mts-card flex flex-col justify-between h-[148px] relative transition-all duration-300 bg-white border border-[#F1F3F5] overflow-hidden"
      >
        {/* ЯЗЫЧОК СВЕРХУ: потянуть язычок / открыть шторку детализации */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 z-10">
          <button
            type="button"
            onClick={() => setIsSavedTabOpen(true)}
            className="group flex items-center gap-1 px-3 py-0.5 rounded-b-xl bg-[#F0F2F5] hover:bg-[#E4E7EC] text-[#2C3138] hover:text-[#111315] border-x border-b border-[#D6DAE0] text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer shadow-2xs"
            title="Потянуть язычок сверху / открыть шторку детализации (Без ТП, ЕИ)"
          >
            <span>ТП • ЕИ</span>
            <ChevronDown className="w-3 h-3 text-[#5A6470] group-hover:translate-y-0.5 transition-transform" />
          </button>
        </div>

        {/* Лицевая часть карточки */}
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-[#626C77] uppercase tracking-wider">
            Сохранение
          </span>
          <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span
              className={`text-3xl sm:text-4xl ${weightClass} text-[#1D2023] tracking-tight font-mts-compact transition-transform ${
                isSavedPulsing ? 'animate-value-pop' : ''
              }`}
            >
              {stats.savedCount}
            </span>
            <span className="text-xs text-[#626C77] font-normal">
              {formatSubscribersCount(stats.savedCount)}
            </span>
          </div>

          {/* Быстрые кнопки ручного + / - */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAdjustSaved(-1)}
              title="Отнять 1 сохранение"
              className="w-8 h-8 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors text-xs font-bold cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onAdjustSaved(1)}
              title="Добавить сохранение (+)"
              className="w-9 h-9 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center transition-colors font-bold shadow-2xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Нижняя строчка статуса: нейтральные темно-серые надписи */}
        <div className="pt-2 border-t border-[#F1F3F5] flex items-center justify-between text-xs text-[#626C77]">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8C95A0] inline-block" />
            <span>Без ТП: <strong className="text-[#2C3138]">{stats.savedWithoutTpChange || 0}</strong></span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8C95A0] inline-block" />
            <span>ЕИ: <strong className="text-[#2C3138]">{stats.savedWithEi || 0}</strong></span>
          </div>
        </div>

        {/* ШТОРКА ДЕТАЛИЗАЦИИ (плавно выкатывается сверху вниз) */}
        <div
          className={`absolute inset-0 z-20 bg-white rounded-3xl p-3 flex flex-col justify-between border border-[#D6DAE0] shadow-xl transition-all duration-300 ease-out ${
            isSavedTabOpen
              ? 'translate-y-0 opacity-100 pointer-events-auto'
              : '-translate-y-full opacity-0 pointer-events-none'
          }`}
        >
          {/* Верх шторки: заголовок и кнопка свернуть */}
          <div className="flex items-center justify-between pb-1 border-b border-[#F1F3F5]">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#5A6470]" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#2C3138]">
                Детализация сохранений
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsSavedTabOpen(false)}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#F0F2F5] hover:bg-[#E4E7EC] text-[#4F5B66] hover:text-[#1D2023] text-[10px] font-bold transition-colors cursor-pointer"
              title="Свернуть шторку"
            >
              <span>Свернуть</span>
              <ChevronUp className="w-3 h-3" />
            </button>
          </div>

          {/* Тело шторки: счетчики Без смены ТП и ЕИ (Единичный инцидент) */}
          <div className="space-y-1.5 my-auto">
            {/* 1) Без смены ТП */}
            <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-[#F8F9FA] border border-[#E9ECEF]">
              <span className="text-[11px] font-bold text-[#2C3138] leading-tight">
                1) Без смены ТП
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-extrabold text-[#1D2023] w-5 text-center tabular-nums">
                  {stats.savedWithoutTpChange || 0}
                </span>
                <button
                  type="button"
                  onClick={() => onAdjustSavedWithoutTpChange?.(-1)}
                  className="w-6 h-6 rounded-lg bg-white hover:bg-gray-100 text-[#4F5B66] flex items-center justify-center transition-colors cursor-pointer text-xs font-bold border border-gray-200 shadow-2xs"
                  title="Отнять"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => onAdjustSavedWithoutTpChange?.(1)}
                  className="w-6 h-6 rounded-lg bg-[#F0F2F5] hover:bg-[#E4E7EC] text-[#2C3138] hover:text-[#111315] flex items-center justify-center transition-colors cursor-pointer text-xs font-bold border border-[#D6DAE0] shadow-2xs"
                  title="Добавить (+)"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* 2) ЕИ (Единичный инцидент) */}
            <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-[#F8F9FA] border border-[#E9ECEF]">
              <span className="text-[11px] font-bold text-[#2C3138] leading-tight">
                2) ЕИ (Единичный инцидент)
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-extrabold text-[#1D2023] w-5 text-center tabular-nums">
                  {stats.savedWithEi || 0}
                </span>
                <button
                  type="button"
                  onClick={() => onAdjustSavedWithEi?.(-1)}
                  className="w-6 h-6 rounded-lg bg-white hover:bg-gray-100 text-[#4F5B66] flex items-center justify-center transition-colors cursor-pointer text-xs font-bold border border-gray-200 shadow-2xs"
                  title="Отнять"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => onAdjustSavedWithEi?.(1)}
                  className="w-6 h-6 rounded-lg bg-[#F0F2F5] hover:bg-[#E4E7EC] text-[#2C3138] hover:text-[#111315] flex items-center justify-center transition-colors cursor-pointer text-xs font-bold border border-[#D6DAE0] shadow-2xs"
                  title="Добавить (+)"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Низ шторки: ручка-тяга для закрытия */}
          <div
            onClick={() => setIsSavedTabOpen(false)}
            className="pt-0.5 flex items-center justify-center gap-1 text-[10px] text-[#8C95A0] hover:text-[#1D2023] cursor-pointer"
            title="Нажмите, чтобы свернуть шторку"
          >
            <div className="w-10 h-1 rounded-full bg-gray-300 hover:bg-gray-400 transition-colors" />
          </div>
        </div>
      </div>


      {/* 3. КОНВЕРСИЯ */}
      <div className="bg-white rounded-3xl p-5 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between h-[148px] relative">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-[#626C77] uppercase tracking-wider">
            Конверсия
          </span>
          <div className="w-9 h-9 rounded-2xl bg-rose-50 text-[#E30613] flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="flex items-baseline gap-2">
          <span className={`text-3xl sm:text-4xl ${weightClass} text-[#1D2023] tracking-tight font-mts-compact`}>
            {conversionDisplay}%
          </span>
        </div>

        {/* Индикатор прогресса в нижней линии */}
        <div className="pt-2 border-t border-[#F1F3F5] flex flex-col justify-center">
          <div className="w-full bg-[#F4F5F7] h-2 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#E30613] transition-all duration-500 rounded-full"
              style={{ width: `${Math.min(stats.conversionRate, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* 4. ОЖИДАНИЕ */}
      <div
        onClick={onFocusDueQueue}
        className={`bg-white rounded-3xl p-5 border border-[#F1F3F5] flex flex-col justify-between h-[148px] cursor-pointer transition-all ${
          hasQueue ? 'animate-cast-shadow' : 'shadow-mts-card'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-[#626C77] uppercase tracking-wider">
              Ожидание
            </span>
              <div className="relative inline-block">
                <button
                  type="button"
                  onMouseEnter={() => setShowSyncTooltip(true)}
                  onMouseLeave={() => setShowSyncTooltip(false)}
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowSyncTooltip(!showSyncTooltip);
                  }}
                  className="text-[#8C95A0] transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                </button>

                {showSyncTooltip && (
                  <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-48 p-2.5 rounded-xl bg-[#1D2023] text-white text-[11px] font-normal leading-tight shadow-xl z-50 pointer-events-none">
                    Таймеры синхронизированы с часами компьютера оператора
                  </div>
                )}
              </div>
            </div>

            {/* Иконка часов */}
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center ${
                dueTimersCount > 0
                  ? 'bg-amber-50 text-amber-700'
                  : 'bg-gray-100 text-[#1D2023]'
              }`}
            >
              <Timer className="w-5 h-5" />
            </div>
          </div>

          <div className="flex items-baseline gap-2">
            <span className={`text-3xl sm:text-4xl ${weightClass} text-[#1D2023] tracking-tight font-mts-compact`}>
              {activeTimersCount}
            </span>
            <span className="text-xs text-[#626C77] font-medium">в очереди</span>
          </div>

          {/* Детализация: Авто-перезвоны vs По просьбе клиентов */}
          <div className="pt-2 border-t border-[#F1F3F5] flex items-center justify-between text-xs">
            <div
              className="flex items-center gap-1.5 text-[#626C77]"
              title="Автоматические перезвоны по правилам дозвона (попытки 1-3)"
            >
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
              <span>Авто:</span>
              <span className="font-extrabold text-[#1D2023]">{autoCallbacksCount}</span>
            </div>
            <div
              className="flex items-center gap-1.5 text-[#626C77]"
              title="Перезвоны по просьбе / согласованию с клиентом"
            >
              <span className="w-2 h-2 rounded-full bg-[#0077FF] inline-block" />
              <span>По просьбе:</span>
              <span className="font-extrabold text-[#0077FF]">{clientAgreedCallbacksCount}</span>
            </div>
          </div>
        </div>
    </section>
  );
};
