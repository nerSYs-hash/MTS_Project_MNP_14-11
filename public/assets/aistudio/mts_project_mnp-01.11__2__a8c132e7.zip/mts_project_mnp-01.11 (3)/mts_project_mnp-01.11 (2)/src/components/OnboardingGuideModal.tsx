import React, { useState, useEffect } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Bell,
  Mail,
  Copy,
  Check,
  Sparkles,
  Phone,
  UserCheck,
  TrendingUp,
  Clock,
  RotateCcw,
  Star,
  Info,
  Calendar,
  Zap,
  ArrowRight,
} from 'lucide-react';
import { GUIDE_STEPS, FEEDBACK_CONTACT } from '../data/guideData';

interface OnboardingGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStepIndex?: number;
}

export const OnboardingGuideModal: React.FC<OnboardingGuideModalProps> = ({
  isOpen,
  onClose,
  initialStepIndex = 0,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialStepIndex);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [activeKpiCard, setActiveKpiCard] = useState<number>(0);
  const [sheet2Expanded, setSheet2Expanded] = useState<boolean>(false);
  const [showReminderTooltip, setShowReminderTooltip] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(initialStepIndex);
      setActiveKpiCard(0);
      setShowReminderTooltip(false);
    }
  }, [isOpen, initialStepIndex]);

  // Плавное раскрытие таблицы номеров при переходе на 2 лист
  useEffect(() => {
    if (currentIndex === 1) {
      setSheet2Expanded(false);
      const timer = setTimeout(() => {
        setSheet2Expanded(true);
      }, 200);
      return () => clearTimeout(timer);
    } else {
      setSheet2Expanded(false);
    }
  }, [currentIndex]);

  // Keyboard navigation (arrows and Escape)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        if (currentIndex < GUIDE_STEPS.length - 1) {
          setCurrentIndex((prev) => prev + 1);
        }
      } else if (e.key === 'ArrowLeft') {
        if (currentIndex > 0) {
          setCurrentIndex((prev) => prev - 1);
        }
      } else if (e.key === 'Escape') {
        handleClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentIndex]);

  const handleClose = () => {
    try {
      localStorage.setItem('mts_urm_onboarding_completed', 'true');
    } catch {
      // ignore
    }
    onClose();
  };

  if (!isOpen) return null;

  const currentStep = GUIDE_STEPS[currentIndex];
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === GUIDE_STEPS.length - 1;

  const handleNext = () => {
    if (isLast) {
      handleClose();
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (!isFirst) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleCopyEmail = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(FEEDBACK_CONTACT.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  // Render visual content for the right pane
  const renderRightVisualContent = () => {
    switch (currentStep.id) {
      // 1 ЛИСТ: Карточки KPI в 3D (раскрыты шире, при клике приподнимаются вверх и не загораживают другие)
      case 'kpi-3d': {
        const kpiCards = [
          {
            title: 'ЗВОНКИ',
            value: '17',
            unit: 'контактов',
            icon: Phone,
            iconBg: 'bg-blue-50 text-blue-500',
            hasCounter: true,
          },
          {
            title: 'СОХРАНЕНИЕ',
            value: '14',
            unit: 'абонентов',
            icon: UserCheck,
            iconBg: 'bg-emerald-50 text-emerald-600',
            hasCounter: true,
          },
          {
            title: 'КОНВЕРСИЯ',
            value: '82.4%',
            unit: '',
            icon: TrendingUp,
            iconBg: 'bg-red-50 text-[#E30613]',
            hasProgress: true,
          },
          {
            title: 'ОЖИДАНИЕ',
            value: '2',
            unit: 'в очереди',
            icon: Clock,
            iconBg: 'bg-slate-100 text-slate-700',
            subInfo: 'Авто: 1  •  По просьбе: 1',
          },
        ];

        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            {/* 3D Сцена веерного раскрытия карточек */}
            <div
              className="relative w-full max-w-[440px] h-[255px] flex items-center justify-center pt-5"
              style={{ perspective: '1200px' }}
            >
              {kpiCards.map((card, idx) => {
                const isSelected = activeKpiCard === idx;
                // Более широкое начальное раскрытие, чтобы ни одна карточка не слипалась
                const fanX = idx * 68 - 102;
                const fanY = isSelected ? -32 : idx * 2; // При клике выдвигается строго ВВЕРХ, не закрывая соседей
                const rotY = -14 + idx * 4;
                const rotX = 3;
                const transZ = (3 - idx) * 16 + (isSelected ? 45 : 0);

                return (
                  <div
                    key={card.title}
                    onClick={() => setActiveKpiCard(idx)}
                    className={`absolute w-[205px] sm:w-[220px] bg-white rounded-2xl p-3 sm:p-3.5 border cursor-pointer transition-all duration-300 ease-out ${
                      isSelected
                        ? 'border-slate-300 shadow-[0_24px_45px_-8px_rgba(0,0,0,0.22)]'
                        : 'border-slate-100 shadow-[0_12px_24px_-6px_rgba(0,0,0,0.12)] hover:border-slate-200'
                    }`}
                    style={{
                      transform: `translate3d(${fanX}px, ${fanY}px, ${transZ}px) rotateY(${rotY}deg) rotateX(${rotX}deg)`,
                      zIndex: isSelected ? 40 : 10 + (3 - idx),
                      transformStyle: 'preserve-3d',
                    }}
                  >
                    {/* Заголовок карточки с иконкой */}
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10.5px] font-semibold text-slate-700 tracking-wider">
                        {card.title}
                      </span>
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center ${card.iconBg}`}
                      >
                        <card.icon className="w-3.5 h-3.5" />
                      </div>
                    </div>

                    {/* Числовое значение */}
                    <div className="flex items-baseline gap-1 my-0.5">
                      <span className="text-2xl sm:text-[26px] font-normal text-slate-900 tracking-tight">
                        {card.value}
                      </span>
                      {card.unit && (
                        <span className="text-[10px] font-normal text-slate-500">
                          {card.unit}
                        </span>
                      )}
                    </div>

                    {/* Дополнительные контролы */}
                    {card.hasCounter && (
                      <div className="flex items-center justify-end gap-1 mt-2 pt-1 border-t border-slate-50">
                        <span className="w-4 h-4 rounded-md bg-slate-100 text-slate-500 flex items-center justify-center text-[10px]">
                          -
                        </span>
                        <span className="w-4 h-4 rounded-md bg-blue-50 text-blue-600 flex items-center justify-center text-[10px] font-medium">
                          +
                        </span>
                      </div>
                    )}

                    {card.hasProgress && (
                      <div className="mt-2.5 pt-1">
                        <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                          <div className="w-[82%] h-full bg-[#E30613] rounded-full" />
                        </div>
                      </div>
                    )}

                    {card.subInfo && (
                      <div className="mt-2 pt-1 text-[9.5px] font-normal text-slate-500 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        <span className="truncate">{card.subInfo}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Подсказка внизу листа */}
            <div className="mt-3 flex items-center gap-2 bg-white/90 backdrop-blur-xs px-3.5 py-1.5 rounded-xl shadow-xs text-xs font-normal text-slate-600 border border-slate-200/60">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>
                Все 4 блока видны сразу и обновляются в реальном времени при каждом действии
              </span>
            </div>
          </div>
        );
      }

      // 2 ЛИСТ: Разворот списка номеров (плавная анимация при переходе, удален артефакт внизу)
      case 'numbers-registry':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            <div className="w-full max-w-[430px] flex flex-col gap-2">
              {/* Строка быстрого ввода номеров с плавно анимированной стрелкой */}
              <div
                onClick={() => setSheet2Expanded(!sheet2Expanded)}
                className="cursor-pointer transition-transform active:scale-[0.99] select-none"
                title="Нажмите для переключения разворота"
              >
                <div className="bg-white rounded-2xl shadow-md border border-slate-200/60 p-2 sm:p-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 hover:bg-slate-100 rounded-xl text-xs font-medium text-slate-700 transition-colors">
                      <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                      <span>Номера</span>
                      <ChevronRight
                        className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-500 ${
                          sheet2Expanded ? 'rotate-90' : 'rotate-0'
                        }`}
                      />
                    </div>
                    <div className="text-xs text-slate-400 font-normal flex items-center gap-1.5 pl-1">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <span>Введите номер абонента</span>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-700">
                    <Check className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* Развернутая таблица номеров - плавно выкатывается вниз, артефакт снизу строго обрезан */}
              <div
                className={`transition-all duration-700 cubic-bezier(0.16, 1, 0.3, 1) overflow-hidden ${
                  sheet2Expanded
                    ? 'max-h-[225px] opacity-100 translate-y-0 scale-100'
                    : 'max-h-0 opacity-0 -translate-y-3 scale-98 pointer-events-none'
                }`}
              >
                <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200/70 max-h-[190px] relative bg-white">
                  <img
                    src="/assets/aistudio/image_e3a02193.png"
                    alt="Таблица сохраненных номеров"
                    className="w-full h-[190px] object-cover object-top"
                  />
                </div>
              </div>
            </div>

            <div className="mt-3 text-[11px] font-normal text-slate-500 bg-white/85 backdrop-blur-xs px-3 py-1 rounded-xl shadow-xs border border-slate-200/50">
              Сохраненные номера автоматически вносятся в реестр и доступны для копирования в 1 клик
            </div>
          </div>
        );

      // 3 ЛИСТ: Карточка клиента (кристально четкая, без размытия, векторная прорисовка)
      case 'client-card-3d':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            {/* Четкая векторная карточка клиента без артефактов масштабирования */}
            <div className="w-full max-w-[440px] bg-white rounded-2xl sm:rounded-3xl shadow-[0_16px_36px_-8px_rgba(0,0,0,0.16)] border border-slate-200/70 p-3.5 sm:p-4 text-slate-900">
              {/* Шапка формы */}
              <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-slate-100">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs sm:text-[13px] font-semibold text-slate-900">
                    Карта клиента
                  </span>
                  <Info className="w-3.5 h-3.5 text-slate-400" />
                </div>
                <div className="text-[11px] font-normal text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>Время клиента: 17:58</span>
                </div>
              </div>

              {/* Поля ввода: Ссылка, Телефон, Автоответчик, Город */}
              <div className="grid grid-cols-12 gap-2 text-xs">
                {/* Ссылка */}
                <div className="col-span-5">
                  <div className="text-[9.5px] uppercase font-semibold text-slate-500 mb-0.5">
                    Ссылка
                  </div>
                  <div className="bg-slate-50 border border-slate-200/80 rounded-xl px-2 py-1.5 text-[11px] text-slate-400 truncate flex items-center justify-between">
                    <span className="truncate">https://crm.mts.ru/leads/...</span>
                    <Copy className="w-3 h-3 text-blue-500 shrink-0 ml-1" />
                  </div>
                </div>

                {/* Телефон */}
                <div className="col-span-4">
                  <div className="text-[9.5px] uppercase font-semibold text-slate-500 mb-0.5">
                    Телефон
                  </div>
                  <div className="bg-slate-50 border border-slate-200/80 rounded-xl px-2 py-1.5 text-[11px] font-mono text-slate-800">
                    +7 (912) 000-00-00
                  </div>
                </div>

                {/* Автоответчик */}
                <div className="col-span-3 flex flex-col justify-end">
                  <div className="flex items-center gap-1.5 justify-end pb-1.5">
                    <span className="text-[10px] text-slate-500 font-normal">Автоответчик</span>
                    <div className="w-7 h-4 bg-blue-600 rounded-full p-0.5 flex items-center justify-end">
                      <div className="w-3 h-3 bg-white rounded-full shadow-xs" />
                    </div>
                  </div>
                </div>

                {/* Город */}
                <div className="col-span-12 flex items-center gap-2">
                  <div className="flex-1 bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1 text-[11px] text-slate-600">
                    г. Москва, Самара...
                  </div>
                  <span className="text-[10px] text-slate-400">Частые:</span>
                  <span className="px-2 py-0.5 bg-slate-100 rounded-lg text-[10px] font-medium text-slate-700">
                    Омск
                  </span>
                </div>

                {/* Заметка с кнопкой Избранного ⭐ */}
                <div className="col-span-12">
                  <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-2 relative text-[11px] text-slate-400">
                    <span>Причина ухода, скидка, тариф, пожелания клиента...</span>
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 absolute bottom-1.5 right-2" />
                  </div>
                </div>

                {/* Нижние действия формы */}
                <div className="col-span-12 flex items-center justify-between pt-1">
                  <button
                    type="button"
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 text-slate-700 text-[11px] font-normal flex items-center gap-1.5 border border-slate-200/60"
                  >
                    <RotateCcw className="w-3 h-3 text-slate-500" />
                    <span>Когда перезвонить?</span>
                  </button>

                  <button
                    type="button"
                    className="px-3.5 py-1.5 rounded-xl bg-[#E30613] text-white text-[11px] font-semibold tracking-wide shadow-xs flex items-center gap-1"
                  >
                    <span>ЗАПИСАТЬ</span>
                    <span className="text-[9px] opacity-75">ENTER</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Выноски ключевых фич: 3 аккуратные карточки в два ряда */}
            <div className="w-full max-w-[440px] mt-2.5 grid grid-cols-3 gap-2">
              <div className="bg-white rounded-xl shadow-xs border border-slate-200/70 p-2 flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-medium text-slate-800">Регион & Время</span>
                <span className="text-[10px] font-normal text-slate-500 flex items-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                  <span>Автоматически</span>
                </span>
              </div>

              <div className="bg-white rounded-xl shadow-xs border border-slate-200/70 p-2 flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-medium text-slate-800">Быстрые заметки</span>
                <span className="text-[10px] font-normal text-slate-500 flex items-center gap-1 mt-0.5">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500 shrink-0" />
                  <span>В Избранное</span>
                </span>
              </div>

              <div className="bg-white rounded-xl shadow-xs border border-slate-200/70 p-2 flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-medium text-slate-800">Умный перезвон</span>
                <span className="text-[10px] font-normal text-slate-500 flex items-center gap-1 mt-0.5">
                  <RotateCcw className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                  <span>Настрой 1 раз</span>
                </span>
              </div>
            </div>
          </div>
        );

      // 4 ЛИСТ: Напоминания (фирменный молочный стиль МТС: без внутренних плашек, серая кнопка с зеленой анимированной стрелкой)
      case 'reminders-control':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            <div className="w-full max-w-[420px] flex flex-col gap-3">
              {/* Карточка напоминания 1 (Санкт-Петербург) */}
              <div className="bg-[#FAF8F5] rounded-3xl p-4 shadow-xl border border-[#E8E3D9] text-[#1D2023] relative">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-[#EFEBE4] text-[#1D2023] flex items-center justify-center shrink-0">
                      <Bell className="w-3.5 h-3.5 text-[#1D2023]" />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#626C77]">
                      МТС Напоминание
                    </span>
                  </div>
                  <span className="text-stone-400 p-0.5">
                    <X className="w-4 h-4" />
                  </span>
                </div>

                <div className="text-sm font-bold text-[#1D2023] mb-3 flex items-center gap-1.5">
                  <span>🔔</span>
                  <span>Требуется исходящий вызов</span>
                </div>

                {/* Информация: единый молочный фон без внутренних плашек и обводок */}
                <div className="space-y-2 mb-3.5 px-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Номер телефона</span>
                    <span className="text-sm font-bold text-[#1D2023] font-mono tracking-wide">+7 (921) 987-65-43</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Попытка</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EDE8E0] text-[#1D2023]">
                      Попытка 1 из 3
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Регион</span>
                    <span className="text-xs font-semibold text-[#1D2023]">г. Санкт-Петербург и Ленинградская область</span>
                  </div>
                </div>

                {/* Кнопка по стандарту МТС: серая с зеленой анимированной стрелкой */}
                <div className="w-full h-9 px-4 rounded-full bg-[#E9EBEF] text-[#1D2023] text-xs font-bold flex items-center justify-center gap-2 shadow-2xs">
                  <span>Перейти к карточке</span>
                  <ArrowRight className="w-4 h-4 text-[#00B956] animate-arrow-pingpong shrink-0" />
                </div>
              </div>

              {/* Карточка напоминания 2 (Москва) */}
              <div className="bg-[#FAF8F5] rounded-3xl p-4 shadow-xl border border-[#E8E3D9] text-[#1D2023] relative">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-[#EFEBE4] text-[#1D2023] flex items-center justify-center shrink-0">
                      <Bell className="w-3.5 h-3.5 text-[#1D2023]" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#626C77]">
                      МТС Напоминание
                    </span>
                  </div>
                  <span className="text-stone-400 p-0.5">
                    <X className="w-4 h-4" />
                  </span>
                </div>

                <div className="text-sm font-bold text-[#1D2023] mb-3 flex items-center gap-1.5">
                  <span>🔔</span>
                  <span>Требуется исходящий вызов</span>
                </div>

                {/* Информация: единый молочный фон без внутренних плашек и обводок */}
                <div className="space-y-2 mb-3.5 px-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Номер телефона</span>
                    <span className="text-sm font-bold text-[#1D2023] font-mono tracking-wide">+7 (916) 123-45-67</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Попытка</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EDE8E0] text-[#1D2023]">
                      Попытка 2 из 3
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#7D8895]">Регион</span>
                    <span className="text-xs font-semibold text-[#1D2023]">г. Москва и Московская область</span>
                  </div>
                </div>

                {/* Кнопка по стандарту МТС: серая с зеленой анимированной стрелкой */}
                <div className="w-full h-9 px-4 rounded-full bg-[#E9EBEF] text-[#1D2023] text-xs font-bold flex items-center justify-center gap-2 shadow-2xs">
                  <span>Перейти к карточке</span>
                  <ArrowRight className="w-4 h-4 text-[#00B956] animate-arrow-pingpong shrink-0" />
                </div>
              </div>
            </div>

            {/* Интерактивная плашка с оранжевой точкой: при наведении или нажатии показывает объяснение */}
            <div className="relative mt-3">
              <button
                type="button"
                onMouseEnter={() => setShowReminderTooltip(true)}
                onMouseLeave={() => setShowReminderTooltip(false)}
                onClick={() => setShowReminderTooltip((prev) => !prev)}
                className="inline-flex items-center gap-2 bg-white/95 hover:bg-white px-3.5 py-1.5 rounded-xl shadow-xs text-xs font-normal text-slate-700 border border-slate-200/70 hover:border-amber-300 transition-all cursor-pointer select-none"
              >
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" />
                <span>Можно настроить напоминания под себя</span>
              </button>

              {/* Всплывающее объяснение при наведении / клике */}
              {showReminderTooltip && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-[320px] sm:w-[350px] bg-slate-900/95 backdrop-blur-md text-white p-3 sm:p-3.5 rounded-2xl shadow-2xl text-[11.5px] leading-relaxed z-30 animate-in fade-in slide-in-from-bottom-2 duration-150 border border-slate-700/60">
                  <div className="font-semibold text-amber-400 flex items-center gap-1.5 mb-1.5 text-xs">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                    <span>Тройной контроль напоминаний</span>
                  </div>
                  <div className="text-slate-200 font-normal space-y-1">
                    <div>
                      • <span className="text-white font-medium">Экранный Push:</span> всплывает поверх всех окон ПК, даже если программа свернута.
                    </div>
                    <div>
                      • <span className="text-white font-medium">Звук:</span> легкий звуковой сигнал привлекает внимание оператора.
                    </div>
                    <div>
                      • <span className="text-white font-medium">Индикатор:</span> мигающая оранжевая точка в очереди звонков.
                    </div>
                  </div>
                  <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10.5px] text-slate-400">
                    💡 Все оповещения и интервалы можно настроить или отключить в Настройках ⚙️
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      // 5 ЛИСТ: Полная автоматизация (верхний блок увеличен, убран перегруз зеленью, слоган снизу)
      case 'full-automation':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            <div className="w-full max-w-[440px] flex flex-col items-center gap-3">
              {/* Верхняя крупная карточка клика по "Сохранен! (+1)" */}
              <div className="w-full bg-white rounded-2xl p-3 sm:p-3.5 shadow-md border border-slate-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs sm:text-[13px] font-mono font-medium text-slate-900">
                      +7 (921) 987-65-43
                    </div>
                    <div className="text-[10.5px] text-slate-500 font-normal">
                      Санкт-Петербург • Перезвон успешен
                    </div>
                  </div>
                </div>

                <div className="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5">
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Сохранен! (+1)</span>
                </div>
              </div>

              {/* Спокойный низ без цветового перегруза: аккуратные светлые блоки */}
              <div className="w-full bg-white rounded-2xl p-3 shadow-md border border-slate-100 flex flex-col gap-2">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                    <div className="text-[10px] font-normal text-slate-500">Журнал</div>
                    <div className="text-xs font-semibold text-slate-800 mt-0.5">+1 в таблицу</div>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                    <div className="text-[10px] font-normal text-slate-500">Звонки</div>
                    <div className="text-xs font-semibold text-slate-900 mt-0.5">+1 контакт</div>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                    <div className="text-[10px] font-normal text-slate-500">Сохранения</div>
                    <div className="text-xs font-semibold text-emerald-700 mt-0.5">+1 абонент</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Слоган вынесен вниз под картинку и оформлен в спокойном темном стиле (НЕ зеленым) */}
            <div className="mt-3 text-center">
              <div className="text-xs sm:text-[12.5px] font-semibold text-slate-800 tracking-wider uppercase">
                ВСЁ СИНХРОНИЗИРОВАНО В РЕАЛЬНОМ ВРЕМЕНИ
              </div>
              <div className="text-[11px] font-normal text-slate-500 mt-0.5">
                Конверсия пересчитывается автоматически — оператор работает только с клиентом
              </div>
            </div>
          </div>
        );

      // 6 ЛИСТ: Поддержка и предложения (без аббревиатур УРМ, подходит всем сотрудникам)
      case 'support-updates':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 sm:p-5 select-none relative overflow-hidden">
            <div className="w-full max-w-[430px] bg-white rounded-3xl shadow-xl border border-slate-100 p-5 sm:p-6 flex flex-col gap-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-red-50 text-[#E30613] flex items-center justify-center">
                    <Mail className="w-4 h-4 text-[#E30613]" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-900">
                      Обратная связь и предложения
                    </div>
                    <div className="text-[11px] font-normal text-slate-500">
                      Команда разработки МТС
                    </div>
                  </div>
                </div>
                <span className="text-[10.5px] font-medium text-[#E30613] bg-red-50 px-2.5 py-0.5 rounded-full">
                  МТС
                </span>
              </div>

              <p className="text-xs font-normal text-slate-600 leading-relaxed">
                Мы непрерывно следим за стабильностью работы программы, собираем пожелания операторов и офисных коллег и регулярно выпускаем обновления.
              </p>

              {/* Адрес электронной почты с кнопкой копирования */}
              <div className="flex items-center justify-between bg-slate-50 rounded-2xl p-2.5 px-3 border border-slate-200/80">
                <div className="flex items-center gap-2 font-mono text-xs font-medium text-slate-800">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{FEEDBACK_CONTACT.email}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleCopyEmail}
                    className="px-2.5 py-1 rounded-xl bg-[#E30613] hover:bg-[#c90511] active:scale-95 text-white text-[11px] font-medium flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                    title="Скопировать почту в буфер"
                  >
                    {copiedEmail ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedEmail ? 'Скопировано' : 'Копировать'}</span>
                  </button>
                </div>
              </div>

              {/* Передача через ВС / РГ */}
              <div className="bg-slate-50/70 rounded-2xl p-3 border border-slate-100 text-xs font-normal text-slate-600 flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E30613] shrink-0 mt-1.5" />
                <span>
                  Также вы можете передавать любые идеи напрямую{' '}
                  <span className="font-semibold text-slate-800">своему ВС / РГ</span> или руководителю смены.
                </span>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Главный контейнер в фирменной геометрии МТС */}
      <div className="w-full max-w-[940px] h-[540px] max-h-[88vh] bg-white rounded-[32px] sm:rounded-[36px] shadow-2xl overflow-hidden relative flex flex-col md:flex-row border border-slate-200/50">
        {/* Квадратная кнопка закрытия с закругленными углами */}
        <button
          type="button"
          onClick={handleClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white shadow-md border border-slate-200/80 flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-50 active:scale-95 transition-all z-30 cursor-pointer"
          title="Закрыть руководство"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2]" />
        </button>

        {/* Левая колонка: чистый белый фон, легкая типографика, фиксированная навигация */}
        <div className="w-full md:w-[44%] bg-white p-6 sm:p-8 flex flex-col justify-between shrink-0 h-full overflow-hidden z-10 select-none">
          {/* Скроллируемая область контента, чтобы нижняя панель навигации никогда не съезжала */}
          <div className="overflow-y-auto pr-1">
            {/* Заголовок с легким начертанием font-semibold */}
            <h2 className="text-xl sm:text-2xl font-semibold text-slate-900 leading-[1.25] tracking-tight mb-2.5">
              {currentStep.title}
            </h2>

            {/* Описание понятным, доступным языком font-normal */}
            <p className="text-[13px] sm:text-[13.5px] text-slate-600 leading-relaxed font-normal mb-3.5">
              {currentStep.description}
            </p>

            {/* Пункты */}
            {currentStep.bullets && (
              <ul className="space-y-1.5 pt-0.5">
                {currentStep.bullets.map((bullet, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2 text-[12px] sm:text-[12.5px] text-slate-600 font-normal leading-snug"
                  >
                    <div className="w-4 h-4 rounded-full bg-red-50 text-[#E30613] flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-2.5 h-2.5 text-[#E30613] stroke-[2.5]" />
                    </div>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Нижняя часть с элементами навигации < 1 из 6 > - ВСЕГДА на виду */}
          <div className="shrink-0 pt-4 mt-auto border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={handlePrev}
                disabled={isFirst}
                className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center text-slate-700 transition-all cursor-pointer"
                title="Предыдущий слайд (стрелка влево)"
              >
                <ChevronLeft className="w-5 h-5 stroke-[2]" />
              </button>

              <span className="text-xs sm:text-sm font-medium text-slate-700 px-2 select-none tabular-nums">
                {currentIndex + 1} из {GUIDE_STEPS.length}
              </span>

              <button
                type="button"
                onClick={handleNext}
                className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 flex items-center justify-center text-slate-700 transition-all cursor-pointer"
                title={isLast ? 'Завершить руководство' : 'Следующий слайд (стрелка вправо)'}
              >
                {isLast ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 stroke-[2]" />
                ) : (
                  <ChevronRight className="w-5 h-5 stroke-[2]" />
                )}
              </button>
            </div>

            <button
              type="button"
              onClick={handleClose}
              className="text-xs font-normal text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
            >
              Закрыть
            </button>
          </div>
        </div>

        {/* Правая колонка: благородный нейтральный светло-серый / фарфоровый фон */}
        <div className="w-full md:w-[56%] bg-gradient-to-b from-[#F4F6F9] to-[#E9EDF2] relative flex items-center justify-center p-3 sm:p-5 overflow-hidden">
          {renderRightVisualContent()}
        </div>
      </div>
    </div>
  );
};
