import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  RotateCw,
  FileCheck,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import {
  MtsUpdatePackage,
  applyUpdatePackageToStorage,
  CURRENT_APP_VERSION,
} from '../utils/updateManager';

interface UpdateInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  updatePackage: MtsUpdatePackage | null;
  errorMessage?: string | null;
}

type InstallStatus = 'ready' | 'installing' | 'success' | 'error';

export const UpdateInstallModal: React.FC<UpdateInstallModalProps> = ({
  isOpen,
  onClose,
  updatePackage,
  errorMessage: initialError,
}) => {
  const [status, setStatus] = useState<InstallStatus>('ready');
  const [progress, setProgress] = useState(0);
  const [stageText, setStageText] = useState('');
  const [errorText, setErrorText] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      if (initialError) {
        setStatus('error');
        setErrorText(initialError);
      } else if (updatePackage) {
        setStatus('ready');
        setProgress(0);
        setErrorText(null);
        setStageText('Пакет проверен и готов к установке.');
      }
    }
  }, [isOpen, updatePackage, initialError]);

  const handleStartInstallation = () => {
    if (!updatePackage) return;

    setStatus('installing');
    setProgress(5);
    setStageText('Проверка цифровой сигнатуры и целостности пакета...');

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + Math.floor(Math.random() * 12) + 8;
        if (next >= 25 && next < 55) {
          setStageText('Распаковка модулей интерфейса и стилей v' + updatePackage.version + '...');
        } else if (next >= 55 && next < 85) {
          setStageText('Синхронизация локальных настроек и журнала номеров...');
        } else if (next >= 85 && next < 100) {
          setStageText('Финализация и регистрация обновления в системе УРМ...');
        }

        if (next >= 100) {
          clearInterval(interval);
          // Применяем пакет в локальное хранилище
          const result = applyUpdatePackageToStorage(updatePackage);
          if (result.success) {
            setStatus('success');
            setStageText('Обновление завершено!');
          } else {
            setStatus('error');
            setErrorText(result.message);
          }
          return 100;
        }
        return next;
      });
    }, 200);
  };

  const handleReloadApp = async () => {
    // 1. Принудительно очищаем кэши CacheStorage (PWA / Workbox)
    if ('caches' in window) {
      try {
        const cacheKeys = await caches.keys();
        await Promise.all(cacheKeys.map((key) => caches.delete(key)));
      } catch (e) {
        console.warn('Не удалось очистить кэши браузера:', e);
      }
    }

    // 2. Снимаем старые сервис-воркеры
    if ('serviceWorker' in navigator) {
      try {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
          await reg.unregister();
        }
      } catch (e) {
        console.warn('Не удалось сбросить ServiceWorker:', e);
      }
    }

    // 3. Перезагружаем страницу с параметром обхода кэша
    const cleanUrl = window.location.origin + window.location.pathname + '?v=' + Date.now();
    window.location.replace(cleanUrl);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1D2023]/60 backdrop-blur-xs p-4 overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-[#F1F3F5] overflow-hidden flex flex-col my-auto animate-scale-up">
        {/* Шапка модального окна */}
        <div className="px-6 py-5 bg-[#F4F5F7] border-b border-[#EBECEF] flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Квадратный логотип МТС */}
            <div className="w-9 h-9 rounded-none bg-[#E30613] p-1.5 grid grid-cols-2 grid-rows-2 text-white select-none shrink-0 shadow-sm">
              <span className="text-[9px] font-normal leading-none self-start justify-self-start font-mts-extended">М</span>
              <span className="text-[9px] font-normal leading-none self-start justify-self-end font-mts-extended">Т</span>
              <span />
              <span className="text-[9px] font-normal leading-none self-end justify-self-end font-mts-extended">С</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1D2023] font-mts-extended">
                {status === 'success'
                  ? 'Обновление установлено'
                  : status === 'installing'
                  ? 'Подгрузка обновления...'
                  : 'Обнаружено обновление УРМ'}
              </h3>
              <p className="text-xs text-[#626C77]">
                Рабочее место оператора сохранения МТС (MNP)
              </p>
            </div>
          </div>

          {status !== 'installing' && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white hover:bg-gray-200 text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Тело модального окна */}
        <div className="p-6">
          {/* Состояние: Ошибка */}
          {status === 'error' && (
            <div className="flex flex-col items-center text-center py-4">
              <div className="w-14 h-14 rounded-2xl bg-red-50 text-[#E30613] flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#1D2023] mb-2 font-mts-extended">
                Ошибка установки пакета
              </h4>
              <div className="text-xs sm:text-sm text-[#1D2023] leading-relaxed max-w-md mb-6 bg-red-50/80 p-3.5 rounded-2xl border border-red-200 text-left">
                {errorText || 'Не удалось распознать или применить пакет обновления.'}
              </div>
              <button
                type="button"
                onClick={onClose}
                className="h-11 px-7 rounded-2xl bg-[#1D2023] hover:bg-black text-white text-sm font-semibold transition-colors cursor-pointer shadow-sm"
              >
                Понятно, закрыть
              </button>
            </div>
          )}

          {/* Состояние: Готово к установке */}
          {status === 'ready' && updatePackage && (
            <div className="space-y-5">
              {/* Баннер версии */}
              <div className="p-4 rounded-2xl bg-[#F4F5F7] border border-[#EBECEF] flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white text-[#E30613] flex items-center justify-center shadow-2xs border border-[#EBECEF]">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-[#1D2023] font-mts-extended">
                        Версия {updatePackage.version}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        Новая сборка
                      </span>
                    </div>
                    <span className="text-xs text-[#626C77]">
                      от {updatePackage.releaseDateFormatted}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[11px] text-[#626C77]">Текущая версия</div>
                  <div className="text-xs font-bold text-[#1D2023]">v{CURRENT_APP_VERSION}</div>
                </div>
              </div>

              {/* Название и описание */}
              <div>
                <h4 className="text-sm font-bold text-[#1D2023] mb-1">
                  {updatePackage.title}
                </h4>
                <p className="text-xs text-[#626C77] leading-relaxed">
                  {updatePackage.description}
                </p>
              </div>

              {/* Список изменений в обновлении */}
              <div>
                <div className="text-xs font-bold text-[#1D2023] uppercase tracking-wider mb-2 flex items-center gap-2">
                  <FileCheck className="w-3.5 h-3.5 text-[#0077FF]" />
                  <span>Состав обновлений ({updatePackage.changes.length})</span>
                </div>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {updatePackage.changes.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-white border border-[#EBECEF] hover:border-[#D5D8DD] transition-colors flex items-start gap-3"
                    >
                      <div className="mt-0.5 shrink-0">
                        {item.type === 'feature' ? (
                          <span className="w-5 h-5 rounded-md bg-emerald-50 text-emerald-600 flex items-center justify-center text-xs font-bold">
                            +
                          </span>
                        ) : item.type === 'fix' ? (
                          <span className="w-5 h-5 rounded-md bg-amber-50 text-amber-600 flex items-center justify-center text-xs font-bold">
                            ✓
                          </span>
                        ) : (
                          <span className="w-5 h-5 rounded-md bg-blue-50 text-[#0077FF] flex items-center justify-center text-xs font-bold">
                            ★
                          </span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-[#1D2023]">
                          {item.title}
                        </div>
                        <div className="text-[11px] text-[#626C77] leading-snug mt-0.5">
                          {item.desc}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Сохранение данных */}
              <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100 flex items-center gap-2.5 text-xs text-[#1D2023]">
                <ShieldCheck className="w-4 h-4 text-[#0077FF] shrink-0" />
                <span>Все таймеры, статистика смены и данные очереди останутся нетронутыми.</span>
              </div>

              {/* Кнопка запуска */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="h-11 px-5 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-xs font-semibold text-[#1D2023] transition-colors cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={handleStartInstallation}
                  className="h-11 px-6 rounded-2xl bg-[#E30613] hover:bg-[#C50410] text-white text-xs font-bold tracking-wider uppercase flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>Установить обновление</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Состояние: Идет установка */}
          {status === 'installing' && (
            <div className="py-6 space-y-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-2xl bg-red-50 text-[#E30613] flex items-center justify-center mb-4">
                  <RotateCw className="w-7 h-7 animate-spin" />
                </div>
                <h4 className="text-lg font-bold text-[#1D2023] mb-1 font-mts-extended">
                  Подгрузка обновления...
                </h4>
                <p className="text-xs text-[#626C77]">{stageText}</p>
              </div>

              {/* Прогресс-бар */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-[#1D2023]">
                  <span>Прогресс установки</span>
                  <span>{progress}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-[#EBECEF] overflow-hidden">
                  <div
                    className="h-full bg-[#E30613] transition-all duration-300 ease-out rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#F4F5F7] border border-[#EBECEF] text-center text-[11px] text-[#626C77]">
                Пожалуйста, не закрывайте окно программы до окончания установки.
              </div>
            </div>
          )}

          {/* Состояние: Успешно */}
          {status === 'success' && updatePackage && (
            <div className="py-6 flex flex-col items-center text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-xl font-bold text-[#1D2023] font-mts-extended mb-1">
                  Обновление v{updatePackage.version} успешно установлено!
                </h4>
                <p className="text-xs text-[#626C77] max-w-md">
                  Все новые функции активированы. Чтобы изменения вступили в силу на вашем рабочем месте, нажмите кнопку перезапуска.
                </p>
              </div>

              <div className="w-full p-4 rounded-2xl bg-[#F4F5F7] border border-[#EBECEF] text-left text-xs space-y-1">
                <div className="font-bold text-[#1D2023] flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-emerald-600" />
                  <span>Успешно активировано в версии {updatePackage.version}:</span>
                </div>
                <ul className="list-disc list-inside text-[#626C77] space-y-1 text-[11px] pt-1">
                  {updatePackage.changes && updatePackage.changes.length > 0 ? (
                    updatePackage.changes.map((c, i) => (
                      <li key={i}>
                        <strong className="text-[#1D2023]">{c.title}</strong> — {c.desc.slice(0, 75)}...
                      </li>
                    ))
                  ) : (
                    <>
                      <li>Интерактивное обучение оператора (Туториал из 6 листов)</li>
                      <li>Экранные Push-уведомления МТС с выбором 5 сторон экрана</li>
                      <li>Молочный дизайн Push-карточки со скругленной серой кнопкой</li>
                      <li>Журнал сохранённых номеров и автоматический учёт смены</li>
                    </>
                  )}
                </ul>
              </div>

              <div className="pt-2 w-full">
                <button
                  type="button"
                  onClick={handleReloadApp}
                  className="w-full h-12 rounded-2xl bg-[#E30613] hover:bg-[#C50410] text-white text-xs font-bold tracking-wider uppercase flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <RotateCw className="w-4 h-4" />
                  <span>Перезапустить приложение</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
