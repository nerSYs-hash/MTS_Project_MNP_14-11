import React from 'react';
import { Volume2, VolumeX, Settings, Monitor, Maximize2, Minimize2, Wrench, BookOpen } from 'lucide-react';
import { TimerSettings } from '../types';
import { getInstalledAppVersion } from '../utils/updateManager';

interface HeaderProps {
  localTimeStr: string;
  moscowTimeStr: string;
  currentDateStr: string;
  settings: TimerSettings;
  onToggleSound: () => void;
  onOpenSettings: () => void;
  onOpenReport: () => void;
  onOpenInstallModal: () => void;
  onOpenChangelog?: () => void;
  onOpenGuide?: () => void;
  isInstalled: boolean;
  activeTimersCount: number;
  isStandbyMode?: boolean;
  onToggleStandby?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  localTimeStr,
  moscowTimeStr,
  currentDateStr,
  settings,
  onToggleSound,
  onOpenSettings,
  onOpenInstallModal,
  onOpenChangelog,
  onOpenGuide,
  isInstalled,
  isStandbyMode = false,
  onToggleStandby,
}) => {
  const currentVersion = getInstalledAppVersion();

  return (
    <header className="bg-white border-b border-[#F1F3F5] sticky top-0 z-30 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4 relative">
        {/* Левая часть: Квадратный логотип МТС с буквами по углам и строго только MNP */}
        <div className="flex items-center gap-3 shrink-0 z-10">
          {/* Фирменный строгий квадратный логотип МТС (буквы не болд, распределены строго по углам) */}
          <div
            className="w-10 h-10 rounded-none bg-[#E30613] p-1.5 grid grid-cols-2 grid-rows-2 text-white select-none shrink-0 shadow-sm"
            title="МТС"
          >
            <span className="text-[10px] font-normal leading-none self-start justify-self-start font-mts-extended">М</span>
            <span className="text-[10px] font-normal leading-none self-start justify-self-end font-mts-extended">Т</span>
            <span />
            <span className="text-[10px] font-normal leading-none self-end justify-self-end font-mts-extended">С</span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-[#1D2023] tracking-wide uppercase font-mts-extended">
              MNP
            </span>
            <button
              type="button"
              onClick={onOpenSettings}
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 transition-all cursor-pointer hover:shadow-xs active:scale-95 ${
                currentVersion === '2.7.3'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100 shadow-2xs'
                  : 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
              }`}
              title={`Версия системы: v${currentVersion}. Нажмите, чтобы открыть Центр обновлений`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  currentVersion === '2.7.3' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                }`}
              />
              <span>v{currentVersion}</span>
              {currentVersion === '2.7.3' ? (
                <span className="hidden sm:inline font-semibold text-[9px] text-emerald-800">
                  (Тест успешен)
                </span>
              ) : (
                <span className="hidden sm:inline font-semibold text-[9px] text-amber-800">
                  (Обновить)
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Центр: Дата и системные часы ПК / МСК (строго по математическому центру экрана) */}
        <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 items-center justify-center pointer-events-none z-10">
          <div className="bg-[#F4F5F7] px-4 py-1.5 rounded-2xl flex items-center gap-3 text-xs border border-[#EBECEF] shadow-2xs pointer-events-auto">
            <div className="text-center min-w-[90px]">
              <div className="font-bold text-[#1D2023] text-sm tabular-nums tracking-wide font-mts-compact">
                {localTimeStr}
              </div>
              <div className="text-[10px] text-[#626C77] font-medium uppercase tracking-tight">
                ПК ({currentDateStr})
              </div>
            </div>
            <div className="h-6 w-px bg-[#D5D8DD]" />
            <div className="text-center min-w-[90px]">
              <div className="font-bold text-[#1D2023] text-sm tabular-nums tracking-wide font-mts-compact">
                {moscowTimeStr}
              </div>
              <div className="text-[10px] text-[#626C77] font-medium uppercase tracking-tight">
                МСК (UTC+3)
              </div>
            </div>
          </div>
        </div>

        {/* Правая часть: Кнопки действий (при сворачивании плавно уезжают вверх, если включена анимация) */}
        <div
          className={`flex items-center gap-2 shrink-0 z-10 transition-all duration-300 ease-in-out ${
            isStandbyMode && settings.headerCollapseAnimationEnabled !== false
              ? 'opacity-0 pointer-events-none -translate-y-4'
              : 'opacity-100 translate-y-0'
          }`}
        >
          {/* 1. Кнопка «На рабочий стол» */}
          {!isInstalled && (
            <button
              type="button"
              onClick={onOpenInstallModal}
              className="w-10 h-10 rounded-2xl bg-white border border-[#D5D8DD] hover:border-[#1D2023] text-[#1D2023] flex items-center justify-center transition-all cursor-pointer shadow-xs"
              title="Установить как десктопное приложение на рабочий стол ПК"
            >
              <Monitor className="w-5 h-5 text-[#1D2023]" />
            </button>
          )}

          {/* 2. Звуковое оповещение */}
          <button
            type="button"
            onClick={onToggleSound}
            title={settings.soundEnabled ? 'Звук включен (нажмите, чтобы выключить)' : 'Звук выключен'}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
              settings.soundEnabled
                ? 'bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023]'
                : 'bg-red-50 hover:bg-red-100 text-[#E30613]'
            }`}
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-5 h-5 text-[#1D2023]" />
            ) : (
              <VolumeX className="w-5 h-5 text-[#E30613]" />
            )}
          </button>

          {/* 3. Кнопка скрыть/развернуть в шапке (без слова, без красного фона, стиль как у других кнопок) */}
          {onToggleStandby && (
            <button
              type="button"
              onClick={onToggleStandby}
              title={isStandbyMode ? 'Развернуть рабочее место' : 'Свернуть в режим ожидания'}
              className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-all cursor-pointer"
            >
              {isStandbyMode ? (
                <Maximize2 className="w-5 h-5 text-[#1D2023]" />
              ) : (
                <Minimize2 className="w-5 h-5 text-[#1D2023]" />
              )}
            </button>
          )}

          {/* 4. Кнопка руководства оператора (книга) */}
          {onOpenGuide && (
            <button
              type="button"
              onClick={onOpenGuide}
              title="Руководство оператора (Гайд по функциям УРМ)"
              className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-red-50 hover:text-[#E30613] text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
            >
              <BookOpen className="w-5 h-5" />
            </button>
          )}

          {/* 5. Кнопка журнала обновлений (временно отключена в текущем цикле обновлений) */}
          {onOpenChangelog && (
            <button
              type="button"
              onClick={onOpenChangelog}
              title="Журнал обновлений (патч-ноуты)"
              className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
            >
              <Wrench className="w-5 h-5 text-[#1D2023]" />
            </button>
          )}

          {/* 6. Настройки рабочего места */}
          <button
            type="button"
            onClick={onOpenSettings}
            title="Настройки рабочего места и отчет смены"
            className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
          >
            <Settings className="w-5 h-5 text-[#1D2023]" />
          </button>
        </div>
      </div>
    </header>
  );
};
