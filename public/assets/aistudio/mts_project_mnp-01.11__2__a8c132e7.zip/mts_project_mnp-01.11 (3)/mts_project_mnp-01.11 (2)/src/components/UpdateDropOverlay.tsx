import React, { useEffect, useState } from 'react';
import { UploadCloud, FileCheck2 } from 'lucide-react';

interface UpdateDropOverlayProps {
  onFileDrop: (file: File) => void;
}

export const UpdateDropOverlay: React.FC<UpdateDropOverlayProps> = ({ onFileDrop }) => {
  const [isDraggingOverWindow, setIsDraggingOverWindow] = useState(false);
  const dragCounterRef = React.useRef(0);

  useEffect(() => {
    const handleDragEnter = (e: DragEvent) => {
      e.preventDefault();
      dragCounterRef.current += 1;
      if (e.dataTransfer && e.dataTransfer.types.includes('Files')) {
        setIsDraggingOverWindow(true);
      }
    };

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      if (e.dataTransfer) {
        e.dataTransfer.dropEffect = 'copy';
      }
    };

    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault();
      dragCounterRef.current -= 1;
      if (dragCounterRef.current <= 0) {
        dragCounterRef.current = 0;
        setIsDraggingOverWindow(false);
      }
    };

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      dragCounterRef.current = 0;
      setIsDraggingOverWindow(false);

      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        const file = e.dataTransfer.files[0];
        onFileDrop(file);
      }
    };

    window.addEventListener('dragenter', handleDragEnter);
    window.addEventListener('dragover', handleDragOver);
    window.addEventListener('dragleave', handleDragLeave);
    window.addEventListener('drop', handleDrop);

    return () => {
      window.removeEventListener('dragenter', handleDragEnter);
      window.removeEventListener('dragover', handleDragOver);
      window.removeEventListener('dragleave', handleDragLeave);
      window.removeEventListener('drop', handleDrop);
    };
  }, [onFileDrop]);

  if (!isDraggingOverWindow) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1D2023]/70 backdrop-blur-md p-6 animate-fade-in pointer-events-auto">
      <div className="relative w-full max-w-xl p-8 rounded-3xl bg-white border-2 border-dashed border-[#E30613] shadow-2xl flex flex-col items-center text-center animate-scale-up">
        {/* Квадратный логотип МТС */}
        <div className="w-12 h-12 rounded-none bg-[#E30613] p-1.5 grid grid-cols-2 grid-rows-2 text-white select-none shrink-0 shadow-md mb-4">
          <span className="text-xs font-normal leading-none self-start justify-self-start font-mts-extended">М</span>
          <span className="text-xs font-normal leading-none self-start justify-self-end font-mts-extended">Т</span>
          <span />
          <span className="text-xs font-normal leading-none self-end justify-self-end font-mts-extended">С</span>
        </div>

        <div className="w-16 h-16 rounded-2xl bg-red-50 flex items-center justify-center text-[#E30613] mb-4 animate-bounce">
          <UploadCloud className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-bold text-[#1D2023] mb-2 font-mts-extended">
          Отпустите файл обновления здесь
        </h2>

        <p className="text-sm text-[#626C77] max-w-md mb-4">
          Перетащите файл пакета обновления (<span className="font-semibold text-[#1D2023]">.mtsupdate</span> или{' '}
          <span className="font-semibold text-[#1D2023]">.json</span>) в любое место экрана.
        </p>

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F4F5F7] border border-[#EBECEF] text-xs font-medium text-[#1D2023]">
          <FileCheck2 className="w-4 h-4 text-[#0077FF]" />
          <span>Программа автоматически проверит сигнатуру и начнёт установку</span>
        </div>
      </div>
    </div>
  );
};
