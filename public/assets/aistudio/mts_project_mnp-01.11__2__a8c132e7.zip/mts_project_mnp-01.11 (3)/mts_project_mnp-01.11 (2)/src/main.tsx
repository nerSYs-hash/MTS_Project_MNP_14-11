import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Поддержка горячего обновления интерфейса из пакета .mtsupdate
const dynamicJs = typeof window !== 'undefined' ? localStorage.getItem('mts_dynamic_bundle_js') : null;
const dynamicCss = typeof window !== 'undefined' ? localStorage.getItem('mts_dynamic_bundle_css') : null;

if (dynamicCss) {
  try {
    const existing = document.getElementById('mts-dynamic-css');
    if (!existing) {
      const style = document.createElement('style');
      style.id = 'mts-dynamic-css';
      style.textContent = dynamicCss;
      document.head.appendChild(style);
    }
  } catch (e) {
    console.warn('Ошибка подключения динамических стилей обновления:', e);
  }
}

if (dynamicJs && !(window as any).__MTS_HOT_BUNDLE_ACTIVE__) {
  try {
    (window as any).__MTS_HOT_BUNDLE_ACTIVE__ = true;
    const blob = new Blob([dynamicJs], { type: 'application/javascript' });
    const blobUrl = URL.createObjectURL(blob);
    import(/* @vite-ignore */ blobUrl).catch((err) => {
      console.warn('Ошибка загрузки динамического бандла, запуск стандартного ядра:', err);
      createRoot(document.getElementById('root')!).render(<App />);
    });
  } catch (err) {
    console.warn('Сбой запуска динамического бандла:', err);
    createRoot(document.getElementById('root')!).render(<App />);
  }
} else {
  createRoot(document.getElementById('root')!).render(<App />);
}

