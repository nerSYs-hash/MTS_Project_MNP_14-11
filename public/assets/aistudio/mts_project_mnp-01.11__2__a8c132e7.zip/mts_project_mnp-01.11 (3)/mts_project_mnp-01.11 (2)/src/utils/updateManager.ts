/**
 * Менеджер пакетов обновлений для рабочего места оператора МТС (УРМ)
 * Позволяет упаковывать обновления в единый файл .mtsupdate
 * и устанавливать их на ПК перетаскиванием (Drag & Drop) в окно программы.
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * 📜 РЕГЛАМЕНТ И ПРАВИЛА ВЕРСИОНИРОВАНИЯ СИСТЕМЫ (SemVer: X.Y.Z)
 * ══════════════════════════════════════════════════════════════════════════════
 * 1. ТРЕТЬЯ ЦИФРА (Z — Patch, e.g. 2.7.0 -> 2.7.1):
 *    МЕЛКИЕ ОБНОВЛЕНИЯ: исправления багов, точечные доработки UI/UX, анимации,
 *    стили кнопок, правка текстов, мелкие косметические улучшения.
 *
 * 2. ВТОРАЯ ЦИФРА (Y — Minor, e.g. 2.7.x -> 2.8.0):
 *    КРУПНЫЕ ОБНОВЛЕНИЯ: появление новых разделов, новых функциональных блоков,
 *    существенное расширение возможностей (учёт номеров, новые модули очередей).
 *
 * 3. ПЕРВАЯ ЦИФРА (X — Major, e.g. 2.x.x -> 3.0.0):
 *    ГЛОБАЛЬНЫЕ ОБНОВЛЕНИЯ: фундаментальная смена архитектуры, глобальный
 *    редизайн всей дизайн-системы, переход на новую технологическую платформу.
 * ══════════════════════════════════════════════════════════════════════════════
 */

export const MTS_VERSIONING_RULES = {
  patch: 'Мелкое обновление (3-я цифра, e.g. 2.7.1): точечные фиксы, стили, анимации, мелкие правки UI',
  minor: 'Крупное обновление (2-я цифра, e.g. 2.8.0): новые разделы, блоки, системный функционал',
  major: 'Глобальное обновление (1-я цифра, e.g. 3.0.0): глобальный редизайн, новая архитектура платформы',
} as const;

export interface UpdateChangeItem {
  type: 'feature' | 'update' | 'fix' | 'system';
  title: string;
  desc: string;
}

export interface MtsUpdatePackage {
  format: 'mts-urm-update-package';
  formatVersion: number;
  appId: string;
  version: string;
  releaseDate: string;
  releaseDateFormatted: string;
  title: string;
  description: string;
  changes: UpdateChangeItem[];
  bundle?: {
    js?: string;
    css?: string;
  };
  clientPatch?: {
    enableNumbersAccountingDefault?: boolean;
    targetVersion?: string;
    changelogCount?: number;
    [key: string]: unknown;
  };
  checksum?: string;
}

export const CURRENT_APP_VERSION = '2.7.3';
export const CURRENT_RELEASE_DATE = '4 ноября 2026';

export const CURRENT_UPDATE_PACKAGE: MtsUpdatePackage = {
  format: 'mts-urm-update-package',
  formatVersion: 1,
  appId: 'mts-mnp-urm',
  version: CURRENT_APP_VERSION,
  releaseDate: '2026-11-04',
  releaseDateFormatted: CURRENT_RELEASE_DATE,
  title: 'Пакет обновлений v2.7.3 — Горячая подгрузка кода (Hot-Code Push) и гарантированный Drag & Drop',
  description:
    'Точечное обновление системы (v2.7.3): включение встроенного динамического загрузчика бандлов интерфейса прямо из файла .mtsupdate без необходимости распаковки архивов, оптимизация отображения Push-уведомлений и синхронизация показателей смены.',
  changes: [
    {
      type: 'feature',
      title: 'Горячая подгрузка кода (Hot-Code Push)',
      desc: 'Мини-файл .mtsupdate теперь содержит скомпилированный код интерфейса (JS + CSS) и обновляет программу прямо из файла без ручной замены системных папок.',
    },
    {
      type: 'update',
      title: 'Динамический загрузчик бандлов',
      desc: 'Ядро системы автоматически распознаёт свежий бандл в локальном хранилище и монтирует его при перезапуске с полным обходом старых кэшей.',
    },
    {
      type: 'feature',
      title: 'Интерактивное обучение оператора (Туториал)',
      desc: 'Полноценный наглядный тур из 6 листов: контроль показателей смены (KPI), мгновенный учёт и журнал номеров, быстрое заполнение карточек и умный перезвон, тройной контроль напоминаний с живым Пушем.',
    },
    {
      type: 'update',
      title: 'Экранные Push-оповещения МТС',
      desc: 'Выбор из 5 сторон экрана (верхний правый/левый/центр, нижний правый, правый центр), молочный фон #FAF8F5, скругленная серая кнопка со стрелкой и плавной анимацией движения вперед-назад.',
    },
    {
      type: 'system',
      title: 'Полная накопительность обновления (Кумулятивность)',
      desc: 'Пакет v2.7.3 объединяет все наработки версий 2.7.0, 2.7.1, 2.7.2 и 2.7.3. При установке поверх любой предыдущей версии сохраняются все настройки, таймеры и сохраненные номера оператора.',
    },
  ],
  clientPatch: {
    enableNumbersAccountingDefault: true,
    targetVersion: CURRENT_APP_VERSION,
    changelogCount: 48,
  },
  checksum: 'sha256-mts-urm-2.7.3-verified',
};

/**
 * Валидация структуры пакета обновления
 */
export function validateUpdatePackage(data: unknown): { valid: boolean; error?: string; pkg?: MtsUpdatePackage } {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Файл поврежден или имеет неверный формат (ожидается JSON).' };
  }

  const pkg = data as Partial<MtsUpdatePackage>;

  if (pkg.format !== 'mts-urm-update-package' && !pkg.version) {
    return { valid: false, error: 'Файл не является официальным пакетом обновления МТС УРМ.' };
  }

  if (!pkg.version || typeof pkg.version !== 'string') {
    return { valid: false, error: 'В пакете отсутствует номер версии.' };
  }

  return {
    valid: true,
    pkg: {
      format: 'mts-urm-update-package',
      formatVersion: pkg.formatVersion || 1,
      appId: pkg.appId || 'mts-mnp-urm',
      version: pkg.version,
      releaseDate: pkg.releaseDate || new Date().toISOString().slice(0, 10),
      releaseDateFormatted: pkg.releaseDateFormatted || 'Ноябрь 2026',
      title: pkg.title || `Обновление версии ${pkg.version}`,
      description: pkg.description || 'Пакет системных обновлений для УРМ оператора МТС.',
      changes: Array.isArray(pkg.changes) ? pkg.changes : [],
      clientPatch: pkg.clientPatch || {},
      checksum: pkg.checksum || 'sha256-ok',
    },
  };
}

/**
 * Парсинг файла из Drag & Drop или File Input
 */
export async function parseUpdateFile(file: File): Promise<MtsUpdatePackage> {
  const fileName = file.name.toLowerCase();

  if (fileName.endsWith('.asar')) {
    throw new Error(
      `Вы перетащили файл "${file.name}". Файл app.asar не устанавливается перетаскиванием в окно программы! Это системный модуль — его нужно просто скопировать в папку программы: [папка с программой]\\resources\\app.asar.`
    );
  }

  if (fileName.endsWith('.zip') || fileName.endsWith('.rar') || fileName.endsWith('.7z')) {
    throw new Error(
      `Вы перетащили архив "${file.name}". Для обновления перетаскиванием нужен специальный файл с расширением .mtsupdate (1.5 МБ). Скачайте его через красную кнопку в Настройках -> «Центр обновлений».`
    );
  }

  if (fileName.endsWith('.exe')) {
    throw new Error(
      `Вы перетащили файл "${file.name}". Файл .exe — это исполняемый файл программы, его не нужно перетаскивать в окно.`
    );
  }

  const text = await file.text();
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(
      `Не удалось прочитать файл "${file.name}". Убедитесь, что выбран корректный файл обновления с расширением .mtsupdate (1.5 МБ).`
    );
  }

  const validation = validateUpdatePackage(json);
  if (!validation.valid || !validation.pkg) {
    throw new Error(validation.error || 'Ошибка валидации пакета обновления.');
  }

  return validation.pkg;
}

/**
 * Применение пакета обновлений в локальное хранилище УРМ
 */
export function applyUpdatePackageToStorage(pkg: MtsUpdatePackage): { success: boolean; message: string } {
  try {
    // 1. Фиксируем установленную версию
    localStorage.setItem('mts_app_installed_version', pkg.version);
    localStorage.setItem('mts_app_last_update_date', pkg.releaseDate);
    localStorage.setItem('mts_app_last_update_pkg', JSON.stringify(pkg));

    // 2. Если в патче есть настройки по умолчанию, мягко применяем их без стирания данных
    if (pkg.clientPatch) {
      if (pkg.clientPatch.enableNumbersAccountingDefault !== undefined) {
        const storedSettings = localStorage.getItem('mts_timer_settings');
        if (storedSettings) {
          try {
            const parsed = JSON.parse(storedSettings);
            if (parsed.enableNumbersAccounting === undefined) {
              parsed.enableNumbersAccounting = Boolean(pkg.clientPatch.enableNumbersAccountingDefault);
              localStorage.setItem('mts_timer_settings', JSON.stringify(parsed));
            }
          } catch {
            // игнорируем ошибку парсинга
          }
        }
      }
    }

    // 3. Если пакет содержит горячий бандл с кодом (v2.7.2+), сохраняем его в хранилище!
    if (pkg.bundle) {
      if (pkg.bundle.js) {
        localStorage.setItem('mts_dynamic_bundle_js', pkg.bundle.js);
      }
      if (pkg.bundle.css) {
        localStorage.setItem('mts_dynamic_bundle_css', pkg.bundle.css);
      }
    }

    return {
      success: true,
      message: `Пакет версии ${pkg.version} успешно установлен в систему УРМ.`,
    };
  } catch (err) {
    return {
      success: false,
      message: `Ошибка записи обновления: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

/**
 * Получить текущую установленную версию приложения
 */
export function getInstalledAppVersion(): string {
  try {
    const installed = localStorage.getItem('mts_app_installed_version');
    if (installed) return installed;
  } catch {
    //
  }
  return CURRENT_APP_VERSION;
}

/**
 * Скачать текущий файл обновления (1.5 МБ с полным бандлом JS + CSS)
 */
export function downloadUpdateFile(version: string = CURRENT_APP_VERSION): void {
  const link = document.createElement('a');
  link.href = `/update_v${version}.mtsupdate`;
  link.download = `update_v${version}.mtsupdate`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
