/**
 * Типы данных рабочего места оператора группы сохранения клиентов МТС (MNP)
 */

export type CallStatus =
  | 'new'                 // Новый клиент, еще не звонили
  | 'answering_machine'  // Автоответчик (идут попытки 1-3)
  | 'callback'           // Перезвон по договоренности с клиентом
  | 'saved'              // Клиент успешно сохранен в МТС
  | 'refused'            // Отказ от предложения
  | 'unreachable';       // Недозвон (исчерпано 3 попытки автоответчика)

export interface ClientLead {
  id: string;
  uniqueLink: string;
  phone: string;              // Отформатированный +7 (XXX) XXX-XX-XX
  rawPhone: string;           // Чистые цифры 79XXXXXXXXX
  city: string;
  regionName: string;
  timezoneUtc: number;        // Например, 3 (Москва), 5 (Екатеринбург)
  timezoneMsk: number;        // Разница с Москвой: 0, +2, +4 и т.д.
  status: CallStatus;
  attemptCount: number;       // Текущая попытка (1..3)
  maxAttempts: number;        // Максимум попыток (3)
  targetCallbackTime: number | null; // Временная метка Unix ms для перезвона
  timerDurationMinutes: number | null;
  lastCallTime: number | null;
  scheduledByAgreedTime: boolean;    // Запланировано ли на конкретное согласованное время
  notes: string;
  tariffOffer?: string;       // Предложенный тариф/скидка
  competitorOperator?: string;// К какому оператору уходит (Теле2, МегаФон, Билайн, Т-Мобайл и др.)
  isAnsweringMachineForced?: boolean; // Принудительно зафиксирован в блоке Автоответчик (не убирать даже при наличии комментария)
  createdAt: number;
  updatedAt: number;
}

export interface ShiftStats {
  savedCount: number;
  totalCallsCount: number;
  conversionRate: number;     // В процентах, например 50.0
  unreachableCount: number;
  refusedCount: number;
  shiftStartTime: number;
  savedWithoutTpChange?: number; // Сохранен без смены ТП
  savedWithEi?: number;          // ЕИ (Единичный Инцидент)
}

export type PushNotificationPosition =
  | 'top-right'
  | 'top-left'
  | 'top-center'
  | 'bottom-right'
  | 'center-right';

export interface TimerSettings {
  attempt1Minutes: number;    // По умолчанию 30 мин
  attempt2Minutes: number;    // По умолчанию 45 мин
  attempt3Minutes: number;    // По умолчанию 60 мин
  soundEnabled: boolean;
  volume: number;             // 0.0 - 1.0
  browserNotificationsEnabled: boolean;
  collapseDelayMinutes: number; // Время автосворачивания в режим ожидания (0 = выкл)
  formCollapseDelayMinutes?: number;
  standbyDelayMinutes?: number;
  includeWithoutTpInSaved?: boolean; // Учитывать "Без смены ТП" в общем числе сохранений
  includeEiInSaved?: boolean;        // Учитывать "ЕИ" в общем числе сохранений
  enableNumbersAccounting?: boolean; // Тумблер учёта номеров (поле ввода и журнал сохраненных номеров)
  headerCollapseAnimationEnabled?: boolean; // Плавный уезд верхней панели при сворачивании
  kpiFontWeight?: 'normal' | 'medium' | 'semibold' | 'bold'; // Начертание цифр в блоках KPI
  enablePushNotifications?: boolean; // Всплывающие экранные Push-карточки (дублируют блок срочных вызовов)
  pushPosition?: PushNotificationPosition; // Позиция появления push на экране
}

export interface RegionInfo {
  defPrefixes: string[];
  city: string;
  regionName: string;
  utcOffset: number;
  mskOffset: number;
  aliases?: string[];
}

export type SavedClientType = 'MNP' | 'АВТО' | 'По просьбе';

export interface SavedClientRecord {
  id: string;
  phone: string; // Строго 11 цифр слитного написания, например 79293664010
  time: string;  // Формат 00:00 местного времени ПК сотрудника
  type: SavedClientType;
  timestamp: number;
}
