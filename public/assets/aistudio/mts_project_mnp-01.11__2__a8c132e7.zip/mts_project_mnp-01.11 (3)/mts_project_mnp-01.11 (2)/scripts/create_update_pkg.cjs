/**
 * Скрипт сборки единого файла обновления .mtsupdate
 * Запуск: node scripts/create_update_pkg.cjs [версия]
 *
 * ПРАВИЛА ВЕРСИОНИРОВАНИЯ (SemVer X.Y.Z):
 * - 3-я цифра (Z): Мелкие обновления/фиксы (например, 2.7.1)
 * - 2-я цифра (Y): Крупные обновления/новые разделы (например, 2.8.0)
 * - 1-я цифра (X): Глобальные обновления/редизайн (например, 3.0.0)
 */
const fs = require('fs');
const path = require('path');

const version = process.argv[2] || '2.7.3';
const releaseDate = '2026-11-04';
const releaseDateFormatted = '4 ноября 2026';

const updatePackage = {
  format: 'mts-urm-update-package',
  formatVersion: 1,
  appId: 'mts-mnp-urm',
  version: version,
  releaseDate: releaseDate,
  releaseDateFormatted: releaseDateFormatted,
  title: `Пакет обновлений v${version} — Интерактивное обучение (Туториал) и экранные Push-оповещения`,
  description:
    'Свежее комплексное обновление (v2.7.2): полноценное интерактивное обучение оператора (Туториал из 6 листов) с наглядными карточками и разбором ключевых функций, обновленная система Push-уведомлений с выбором из 5 сторон экрана, молочный фон #FAF8F5, анимированная зеленая стрелка и объединенные настройки звука и оповещений.',
  changes: [
    {
      type: 'feature',
      title: 'Интерактивное обучение оператора (Туториал)',
      desc: 'Полноценный наглядный тур из 6 листов: контроль показателей смены (KPI), мгновенный учёт и журнал номеров, быстрое заполнение карточек и умный перезвон, тройной контроль напоминаний с живым Пушем, автоматизация сохранений (ТП/ЕИ) и прямой канал связи с куратором (кнопка в шапке и в настройках).',
    },
    {
      type: 'feature',
      title: 'Система экранных Push-оповещений МТС',
      desc: 'Всплывающие карточки напоминаний о перезвоне поверх всех окон компьютера при наступлении времени звонка. Настройка расположения по 5 сторонам экрана (верхний правый/левый/центр, нижний правый, правый центр) с моментальной проверкой.',
    },
    {
      type: 'update',
      title: 'Фирменный стиль Push-карточки МТС',
      desc: 'Единый молочный фон #FAF8F5 без внутренних плашек и контуров, скругленная серая кнопка «Перейти к карточке» по стандарту МТС с зеленой стрелкой, двигающейся плавной анимацией вперед-назад, и чистый бейдж попытки.',
    },
    {
      type: 'update',
      title: 'Раздел настроек «Оповещения и Push»',
      desc: 'Звуковые сигналы и параметры Push-уведомлений объединены в одном блоке с интерактивной сеткой выбора стороны экрана и кнопкой быстрого тестирования.',
    },
    {
      type: 'system',
      title: 'Полная накопительность обновления (Кумулятивность)',
      desc: 'Пакет v2.7.2 объединяет все наработки версий 2.7.0, 2.7.1 и 2.7.2. При установке поверх любой предыдущей версии сохраняются все настройки, таймеры и сохраненные номера оператора.',
    },
  ],
  clientPatch: {
    enableNumbersAccountingDefault: true,
    targetVersion: version,
    changelogCount: 45,
  },
  checksum: `sha256-mts-urm-${version}-verified`,
};

// Читаем скомпилированный код интерфейса из dist/assets для горячего обновления (Hot-Code Push)
const distAssetsDir = path.join(__dirname, '..', 'dist', 'assets');
if (fs.existsSync(distAssetsDir)) {
  const assetFiles = fs.readdirSync(distAssetsDir);
  const jsFile = assetFiles.find((f) => f.startsWith('index-') && f.endsWith('.js'));
  const cssFile = assetFiles.find((f) => f.startsWith('index-') && f.endsWith('.css'));

  if (jsFile || cssFile) {
    updatePackage.bundle = {};
    if (jsFile) {
      updatePackage.bundle.js = fs.readFileSync(path.join(distAssetsDir, jsFile), 'utf-8');
      console.log(`📦 Встроен JS-бандл интерфейса: ${jsFile} (${(updatePackage.bundle.js.length / 1024).toFixed(1)} КБ)`);
    }
    if (cssFile) {
      updatePackage.bundle.css = fs.readFileSync(path.join(distAssetsDir, cssFile), 'utf-8');
      console.log(`🎨 Встроен CSS-бандл стилей: ${cssFile} (${(updatePackage.bundle.css.length / 1024).toFixed(1)} КБ)`);
    }
  }
}

const jsonContent = JSON.stringify(updatePackage, null, 2);

// 1. Сохраняем в корень проекта
const rootPath = path.join(__dirname, '..', `update_v${version}.mtsupdate`);
fs.writeFileSync(rootPath, jsonContent, 'utf-8');

// 2. Сохраняем в папку public
const publicDir = path.join(__dirname, '..', 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
const publicPath = path.join(publicDir, `update_v${version}.mtsupdate`);
fs.writeFileSync(publicPath, jsonContent, 'utf-8');

console.log(`✅ Пакет обновления успешно собран!`);
console.log(`📁 Файл в корне проекта: ${rootPath}`);
console.log(`📁 Файл в папке public:  ${publicPath}`);
