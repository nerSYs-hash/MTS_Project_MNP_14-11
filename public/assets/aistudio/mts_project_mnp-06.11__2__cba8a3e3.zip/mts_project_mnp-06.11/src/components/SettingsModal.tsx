import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Bell,
  RotateCcw,
  Download,
  Copy,
  Check,
  HelpCircle,
  RotateCw,
  RefreshCw,
  Upload,
  ShieldCheck,
  PackageCheck,
  FileCheck,
  Sliders,
  Database,
} from 'lucide-react';
import { TimerSettings, ShiftStats, ClientLead, PushNotificationPosition } from '../types';
import { playChimeSound, requestNotificationPermission, sendDesktopNotification } from '../utils/audioAlert';
import { generateShiftReportText } from '../utils/storage';
import {
  downloadUpdateFile,
  downloadAsarFile,
  getInstalledAppVersion,
} from '../utils/updateManager';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TimerSettings;
  onSaveSettings: (settings: TimerSettings) => void;
  stats: ShiftStats;
  leads: ClientLead[];
  onResetShift: () => void;
  onRestoreBackup?: () => boolean;
  onImportLeadsText?: (text: string) => number;
  onSelectUpdateFile?: (file: File) => void;
  onOpenGuide?: () => void;
}

type SettingsTab = 'interface' | 'notifications' | 'shift' | 'updates';

// Фирменный переключатель-тумблер МТС
const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}> = ({ checked, onChange, disabled = false }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    disabled={disabled}
    onClick={() => onChange(!checked)}
    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 ease-in-out cursor-pointer focus:outline-none ${
      disabled ? 'opacity-40 cursor-not-allowed' : ''
    } ${checked ? 'bg-[#E30613]' : 'bg-[#D5D8DD]'}`}
  >
    <span
      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
        checked ? 'translate-x-5.5' : 'translate-x-0.5'
      }`}
    />
  </button>
);

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  stats,
  leads,
  onResetShift,
  onRestoreBackup,
  onImportLeadsText,
  onSelectUpdateFile,
}) => {
  const updateFileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<SettingsTab>('interface');

  const [collapseDelay, setCollapseDelay] = useState(
    settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
  );
  const [headerCollapseAnimationEnabled, setHeaderCollapseAnimationEnabled] = useState(
    settings.headerCollapseAnimationEnabled !== false
  );
  const [soundEnabled, setSoundEnabled] = useState(settings.soundEnabled);
  const [volume, setVolume] = useState(settings.volume);
  const [includeWithoutTpInSaved, setIncludeWithoutTpInSaved] = useState(
    settings.includeWithoutTpInSaved !== false
  );
  const [includeEiInSaved, setIncludeEiInSaved] = useState(
    settings.includeEiInSaved !== false
  );
  const [enableNumbersAccounting, setEnableNumbersAccounting] = useState(
    settings.enableNumbersAccounting !== false
  );
  const [kpiFontWeight, setKpiFontWeight] = useState<'normal' | 'medium' | 'semibold' | 'bold'>(
    settings.kpiFontWeight || 'normal'
  );
  const [enablePushNotifications, setEnablePushNotifications] = useState(
    settings.enablePushNotifications !== false
  );
  const [pushPosition, setPushPosition] = useState<PushNotificationPosition>(
    settings.pushPosition || 'top-right'
  );
  const [notificationsGranted, setNotificationsGranted] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission === 'granted';
    }
    return false;
  });

  const [reportCopied, setReportCopied] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [showCollapseTooltip, setShowCollapseTooltip] = useState(false);
  const [showKpiFontTooltip, setShowKpiFontTooltip] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState<string | null>(null);
  const [showImportBox, setShowImportBox] = useState(false);
  const [importText, setImportText] = useState('');
  const [importResultMsg, setImportResultMsg] = useState<string | null>(null);
  const [isDownloadingMts, setIsDownloadingMts] = useState(false);
  const [downloadDone, setDownloadDone] = useState(false);
  const [isDownloadingAsar, setIsDownloadingAsar] = useState(false);

  // Синхронизация полей настроек при открытии модального окна
  useEffect(() => {
    if (isOpen) {
      setCollapseDelay(
        settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
      );
      setHeaderCollapseAnimationEnabled(settings.headerCollapseAnimationEnabled !== false);
      setSoundEnabled(settings.soundEnabled);
      setVolume(settings.volume);
      setIncludeWithoutTpInSaved(settings.includeWithoutTpInSaved !== false);
      setIncludeEiInSaved(settings.includeEiInSaved !== false);
      setEnableNumbersAccounting(settings.enableNumbersAccounting !== false);
      setKpiFontWeight(settings.kpiFontWeight || 'normal');
      setEnablePushNotifications(settings.enablePushNotifications !== false);
      setPushPosition(settings.pushPosition || 'top-right');
      if (typeof window !== 'undefined' && 'Notification' in window) {
        setNotificationsGranted(Notification.permission === 'granted');
      }
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings({
      ...settings,
      collapseDelayMinutes: collapseDelay,
      headerCollapseAnimationEnabled,
      soundEnabled,
      volume,
      includeWithoutTpInSaved,
      includeEiInSaved,
      enableNumbersAccounting,
      kpiFontWeight,
      enablePushNotifications,
      pushPosition,
    });
    onClose();
  };

  const handleTestSound = () => {
    playChimeSound(volume);
  };

  const handleToggleNotifications = async (enable: boolean) => {
    if (enable) {
      const granted = await requestNotificationPermission();
      setNotificationsGranted(granted);
    } else {
      setNotificationsGranted(false);
    }
  };

  const handleCopyReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    navigator.clipboard.writeText(reportText);
    setReportCopied(true);
    setTimeout(() => setReportCopied(false), 2000);
  };

  const handleDownloadReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MTS_MNP_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const triggerTestPush = (targetPos: PushNotificationPosition) => {
    window.dispatchEvent(
      new CustomEvent('mts-set-push-position', {
        detail: { position: targetPos },
      })
    );
    window.dispatchEvent(
      new CustomEvent('mts-inapp-toast', {
        detail: {
          id: 'pos-test-' + Date.now(),
          title: 'Требуется исходящий вызов',
          phone: '+7 (921) 987-65-43',
          attempt: 1,
          maxAttempts: 3,
          region: 'г. Санкт-Петербург и Ленинградская область',
          position: targetPos,
          timestamp: Date.now(),
        },
      })
    );
  };

  const installedVersion = getInstalledAppVersion();

  const weightLabel =
    kpiFontWeight === 'bold'
      ? 'Жирный'
      : kpiFontWeight === 'semibold'
      ? 'П-жирный'
      : kpiFontWeight === 'medium'
      ? 'Средний'
      : 'Обычный';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div className="bg-[#F4F5F7] rounded-3xl max-w-3xl w-full border border-[#EBECEF] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Шапка модального окна */}
        <div className="px-6 py-4 border-b border-[#EBECEF] bg-white shrink-0 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-[#1D2023] font-mts-extended">
              Настройки рабочего места
            </h3>
            <p className="text-xs text-[#626C77] mt-0.5">
              Выберите нужный раздел на карточках ниже для настройки параметров
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full hover:bg-[#F4F5F7] text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Основная область настроек */}
        <div className="overflow-y-auto p-5 flex-1 space-y-4">
          {/* 4 КАРТОЧКИ-ТЕМЫ В СТИЛЕ ГЛАВНОГО ЭКРАНА (только у них круглые иконки и легкое поднятие при наведении) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Карточка темы 1: ИНТЕРФЕЙС */}
            <button
              type="button"
              onClick={() => setActiveTab('interface')}
              className={`text-left rounded-2xl p-3.5 bg-white border transition-all duration-300 ease-out cursor-pointer flex flex-col justify-between min-h-[100px] shadow-mts-card hover:shadow-mts-hover hover:-translate-y-1 ${
                activeTab === 'interface'
                  ? 'border-[#1D2023] ring-1 ring-[#1D2023]/10'
                  : 'border-[#F1F3F5]'
              }`}
            >
              <div className="flex items-center justify-between w-full gap-1">
                <span className="text-[11px] font-bold text-[#1D2023] uppercase tracking-wider truncate">
                  Интерфейс
                </span>
                <div className="w-7 h-7 rounded-full bg-blue-50 text-[#0077FF] flex items-center justify-center shrink-0">
                  <Sliders className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="flex items-baseline gap-1.5 my-1">
                <span className="text-xs font-medium text-[#626C77] font-mts-compact">
                  {collapseDelay > 0 ? `${collapseDelay} мин` : 'Выкл'}
                </span>
                <span className="text-[11px] text-[#8C95A0] truncate">ожидание</span>
              </div>

              <div className="pt-1.5 border-t border-[#F1F3F5] flex items-center justify-between w-full text-[10px] text-[#626C77]">
                <span>Шрифт: <strong className="text-[#1D2023]">{weightLabel}</strong></span>
              </div>
            </button>

            {/* Карточка темы 2: ЗВУК И PUSH */}
            <button
              type="button"
              onClick={() => setActiveTab('notifications')}
              className={`text-left rounded-2xl p-3.5 bg-white border transition-all duration-300 ease-out cursor-pointer flex flex-col justify-between min-h-[100px] shadow-mts-card hover:shadow-mts-hover hover:-translate-y-1 ${
                activeTab === 'notifications'
                  ? 'border-[#1D2023] ring-1 ring-[#1D2023]/10'
                  : 'border-[#F1F3F5]'
              }`}
            >
              <div className="flex items-center justify-between w-full gap-1">
                <span className="text-[11px] font-bold text-[#1D2023] uppercase tracking-wider truncate">
                  Звук и Push
                </span>
                <div className="w-7 h-7 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Bell className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="flex items-baseline gap-1.5 my-1">
                <span className="text-xs font-medium text-[#626C77] font-mts-compact tabular-nums">
                  {soundEnabled ? `${Math.round(volume * 100)}%` : 'Без звука'}
                </span>
                <span className="text-[11px] text-[#8C95A0] truncate">сигнал</span>
              </div>

              <div className="pt-1.5 border-t border-[#F1F3F5] flex items-center justify-between w-full text-[10px] text-[#626C77]">
                <span>
                  Push: <strong className="text-[#1D2023]">{enablePushNotifications ? 'Вкл' : 'Выкл'}</strong>
                </span>
                <span>
                  ОС: <strong className="text-[#1D2023]">{notificationsGranted ? 'Вкл' : 'Выкл'}</strong>
                </span>
              </div>
            </button>

            {/* Карточка темы 3: ДАННЫЕ */}
            <button
              type="button"
              onClick={() => setActiveTab('shift')}
              className={`text-left rounded-2xl p-3.5 bg-white border transition-all duration-300 ease-out cursor-pointer flex flex-col justify-between min-h-[100px] shadow-mts-card hover:shadow-mts-hover hover:-translate-y-1 ${
                activeTab === 'shift'
                  ? 'border-[#1D2023] ring-1 ring-[#1D2023]/10'
                  : 'border-[#F1F3F5]'
              }`}
            >
              <div className="flex items-center justify-between w-full gap-1">
                <span className="text-[11px] font-bold text-[#1D2023] uppercase tracking-wider truncate">
                  Данные
                </span>
                <div className="w-7 h-7 rounded-full bg-rose-50 text-[#E30613] flex items-center justify-center shrink-0">
                  <Database className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="flex items-baseline gap-1.5 my-1">
                <span className="text-xs font-medium text-[#626C77] font-mts-compact tabular-nums">
                  {stats.totalCallsCount} / {stats.savedCount}
                </span>
                <span className="text-[11px] text-[#8C95A0] truncate">сводка</span>
              </div>

              <div className="pt-1.5 border-t border-[#F1F3F5] flex items-center justify-between w-full text-[10px] text-[#626C77]">
                <span>Отчёт смены • Бэкап</span>
              </div>
            </button>

            {/* Карточка темы 4: ОБНОВЛЕНИЯ (иконка с двумя стрелками без анимации) */}
            <button
              type="button"
              onClick={() => setActiveTab('updates')}
              className={`text-left rounded-2xl p-3.5 bg-white border transition-all duration-300 ease-out cursor-pointer flex flex-col justify-between min-h-[100px] shadow-mts-card hover:shadow-mts-hover hover:-translate-y-1 ${
                activeTab === 'updates'
                  ? 'border-[#1D2023] ring-1 ring-[#1D2023]/10'
                  : 'border-[#F1F3F5]'
              }`}
            >
              <div className="flex items-center justify-between w-full gap-1">
                <span className="text-[11px] font-bold text-[#1D2023] uppercase tracking-wider truncate">
                  Обновления
                </span>
                <div className="w-7 h-7 rounded-full bg-gray-100 text-[#1D2023] flex items-center justify-center shrink-0">
                  <RefreshCw className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="flex items-baseline gap-1.5 my-1">
                <span className="text-xs font-medium text-[#626C77] font-mts-compact tabular-nums">
                  v{installedVersion}
                </span>
                <span className="text-[11px] text-emerald-600 font-medium truncate">
                  {installedVersion === '2.7.5' ? 'активна' : 'тест'}
                </span>
              </div>

              <div className="pt-1.5 border-t border-[#F1F3F5] flex items-center justify-between w-full text-[10px] text-[#626C77]">
                <span>.mtsupdate • .asar</span>
              </div>
            </button>
          </div>

          {/* СОДЕРЖИМОЕ РАЗДЕЛОВ (секции статичны, без анимации движения и без круглых иконок) */}
          {/* РАЗДЕЛ 1: ИНТЕРФЕЙС И KPI */}
          {activeTab === 'interface' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Карточка 1: Режим ожидания */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                      Режим ожидания
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowCollapseTooltip((v) => !v)}
                      className="text-[#8C95A0] hover:text-[#1D2023] cursor-pointer transition-colors"
                      title="Как работает автосворачивание"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {showCollapseTooltip && (
                    <div className="mt-2 p-2.5 rounded-xl bg-[#F8F9FA] border border-[#E9ECEF] text-[11px] text-[#626C77] leading-snug">
                      При неактивности очередь плавно сворачивается в центр, а при наступлении звонка 00:00 мгновенно разворачивается обратно.
                    </div>
                  )}
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] space-y-2.5">
                  {/* Тумблер и текст строго на одном уровне по сетке */}
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-[#626C77] font-medium">
                      Автосворачивание в центр при простое
                    </span>
                    <ToggleSwitch
                      checked={collapseDelay > 0}
                      onChange={(enabled) => setCollapseDelay(enabled ? 3 : 0)}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-[#626C77] font-medium">Таймер:</span>
                    {collapseDelay > 0 ? (
                      <div className="flex items-center gap-1 p-0.5 bg-[#F4F5F7] rounded-xl border border-[#EBECEF]">
                        {[1, 2, 3, 5, 10].map((mins) => (
                          <button
                            key={mins}
                            type="button"
                            onClick={() => setCollapseDelay(mins)}
                            className={`h-6 px-2.5 rounded-lg text-[11px] transition-colors cursor-pointer ${
                              collapseDelay === mins
                                ? 'bg-white text-[#1D2023] font-bold shadow-2xs'
                                : 'text-[#626C77] hover:text-[#1D2023] font-semibold'
                            }`}
                          >
                            {mins}м
                          </button>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[11px] font-medium text-[#8C95A0]">Отключено</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Карточка 2: Типографика KPI (пояснение вынесено в иконку вопроса рядом с названием) */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                      Типографика KPI
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowKpiFontTooltip((v) => !v)}
                      className="text-[#8C95A0] hover:text-[#1D2023] cursor-pointer transition-colors"
                      title="Толщина цифр на карточках главного экрана"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {showKpiFontTooltip && (
                    <div className="mt-2 p-2.5 rounded-xl bg-[#F8F9FA] border border-[#E9ECEF] text-[11px] text-[#626C77] leading-snug">
                      Толщина цифр на карточках главного экрана (Звонки, Сохранение, Конверсия, Ожидание).
                    </div>
                  )}
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5]">
                  <div className="grid grid-cols-4 p-1 bg-[#F4F5F7] rounded-xl gap-1 border border-[#EBECEF]">
                    {[
                      { key: 'normal', label: 'Обычный' },
                      { key: 'medium', label: 'Средний' },
                      { key: 'semibold', label: 'П-жирный' },
                      { key: 'bold', label: 'Жирный' },
                    ].map((w) => (
                      <button
                        key={w.key}
                        type="button"
                        onClick={() => setKpiFontWeight(w.key as any)}
                        className={`py-1.5 px-1.5 rounded-lg text-[11px] transition-colors cursor-pointer truncate ${
                          kpiFontWeight === w.key
                            ? 'bg-white text-[#1D2023] shadow-2xs font-bold'
                            : 'text-[#626C77] hover:text-[#1D2023] font-semibold'
                        }`}
                      >
                        {w.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Карточка 3: Формула сохранений (без лишнего подзаголовка) */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Формула сохранений
                  </span>
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] space-y-2.5">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-[#626C77] font-medium">
                      Учитывать «Без смены ТП»
                    </span>
                    <ToggleSwitch
                      checked={includeWithoutTpInSaved}
                      onChange={setIncludeWithoutTpInSaved}
                    />
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-[#626C77] font-medium">
                      Учитывать «ЕИ» (Единичный инцидент)
                    </span>
                    <ToggleSwitch
                      checked={includeEiInSaved}
                      onChange={setIncludeEiInSaved}
                    />
                  </div>
                </div>
              </div>

              {/* Карточка 4: Элементы экрана (без лишнего подзаголовка) */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Элементы экрана
                  </span>
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] space-y-2.5">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-[#626C77] font-medium">
                      Строка и журнал «Учёт номеров»
                    </span>
                    <ToggleSwitch
                      checked={enableNumbersAccounting}
                      onChange={setEnableNumbersAccounting}
                    />
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-[#626C77] font-medium">
                      Анимация скрытия иконок шапки
                    </span>
                    <ToggleSwitch
                      checked={headerCollapseAnimationEnabled}
                      onChange={setHeaderCollapseAnimationEnabled}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* РАЗДЕЛ 2: ЗВУК И PUSH */}
          {activeTab === 'notifications' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Карточка 1: Всплывающие Push-уведомления (без бейджа Дублирование 00:00, без кнопки Проверить Push, серый выбор позиций) */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between sm:col-span-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                      Всплывающие Push-уведомления (Toast)
                    </span>
                    <p className="text-xs text-[#626C77] mt-1">
                      Всплывающая карточка поверх рабочего места при наступлении времени звонка
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={enablePushNotifications}
                    onChange={setEnablePushNotifications}
                  />
                </div>

                {enablePushNotifications && (
                  <div className="pt-3 mt-3 border-t border-[#F1F3F5] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <span className="text-xs font-medium text-[#626C77]">
                      Точка появления на экране:
                    </span>

                    {/* Компактная серая схема выбора направления (5 позиций) */}
                    <div className="inline-flex items-center gap-1 p-1 bg-[#F4F5F7] rounded-xl border border-[#EBECEF]">
                      {[
                        { key: 'top-left', label: 'Сверху слева', short: '↖ Слева' },
                        { key: 'top-center', label: 'По центру сверху', short: '⬆ Центр' },
                        { key: 'top-right', label: 'Сверху справа', short: '↗ Справа' },
                        { key: 'center-right', label: 'Справа по центру', short: '➡ Справа ц.' },
                        { key: 'bottom-right', label: 'Снизу справа', short: '↘ Снизу' },
                      ].map((pos) => {
                        const isSelected = pushPosition === pos.key;
                        return (
                          <button
                            key={pos.key}
                            type="button"
                            title={pos.label}
                            onClick={() => {
                              const newPos = pos.key as PushNotificationPosition;
                              setPushPosition(newPos);
                              triggerTestPush(newPos);
                            }}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] transition-colors cursor-pointer ${
                              isSelected
                                ? 'bg-white text-[#1D2023] font-bold shadow-2xs'
                                : 'text-[#626C77] hover:text-[#1D2023] font-semibold'
                            }`}
                          >
                            {pos.short}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Карточка 2: Звуковой сигнал 00:00 */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                      Звуковой сигнал 00:00
                    </span>
                    <p className="text-xs text-[#626C77] mt-1">
                      Мелодия при наступлении перезвона
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleTestSound}
                      title="Прослушать сигнал"
                      className="h-7 px-2.5 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-[11px] font-bold transition-colors cursor-pointer border border-[#D5D8DD]"
                    >
                      Тест
                    </button>
                    <ToggleSwitch checked={soundEnabled} onChange={setSoundEnabled} />
                  </div>
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] flex items-center gap-3">
                  <span className="text-xs text-[#626C77] font-medium shrink-0">Громкость:</span>
                  <input
                    type="range"
                    min="0.1"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => setVolume(Number(e.target.value))}
                    className="flex-1 accent-[#E30613] cursor-pointer h-1.5 bg-gray-200 rounded-lg"
                  />
                  <span className="text-xs font-bold text-[#1D2023] w-9 text-right tabular-nums shrink-0">
                    {Math.round(volume * 100)}%
                  </span>
                </div>
              </div>

              {/* Карточка 3: Системные уведомления ОС / браузера */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                      Уведомления Windows / ОС
                    </span>
                    <p className="text-xs text-[#626C77] mt-1">
                      Нативные баннеры при свёрнутом окне
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={notificationsGranted}
                    onChange={handleToggleNotifications}
                  />
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] flex items-center justify-between">
                  <span className="text-xs text-[#626C77]">
                    {notificationsGranted ? 'Разрешение активно' : 'Требуется разрешение браузера'}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      sendDesktopNotification({
                        title: 'Требуется исходящий вызов',
                        phone: '+7 (916) 123-45-67',
                        attempt: 1,
                        maxAttempts: 3,
                        region: 'Москва',
                      })
                    }
                    className="h-7 px-2.5 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-[11px] font-bold transition-colors cursor-pointer border border-[#D5D8DD]"
                  >
                    Проверить баннер
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* РАЗДЕЛ 3: СМЕНА И ДАННЫЕ */}
          {activeTab === 'shift' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Карточка 1: Отчёт смены */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Отчёт смены
                  </span>
                  <p className="text-xs text-[#626C77] mt-1">
                    Звонков: {stats.totalCallsCount} • Сохранено: {stats.savedCount} ({stats.conversionRate.toFixed(1)}%)
                  </p>
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyReport}
                    className="flex-1 h-8 px-3 rounded-xl bg-[#F4F5F7] hover:bg-[#E9ECEF] border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {reportCopied ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{reportCopied ? 'Скопировано!' : 'Скопировать отчёт'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadReport}
                    className="h-8 px-3 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-[#D5D8DD]"
                  >
                    <Download className="w-3.5 h-3.5 text-[#626C77]" />
                    <span>.txt</span>
                  </button>
                </div>
              </div>

              {/* Карточка 2: Завершение и сброс смены */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Новая смена
                  </span>
                  <p className="text-xs text-[#626C77] mt-1">
                    Обнуление счётчиков звонков и сохранений
                  </p>
                </div>

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] flex items-center justify-between">
                  {confirmReset ? (
                    <div className="flex items-center justify-between w-full gap-2">
                      <span className="text-xs text-[#E30613] font-bold">Подтвердить сброс?</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            onResetShift();
                            setConfirmReset(false);
                          }}
                          className="h-7 px-3 bg-[#E30613] text-white rounded-lg text-xs font-bold cursor-pointer"
                        >
                          Да, сбросить
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmReset(false)}
                          className="h-7 px-2.5 bg-[#F4F5F7] text-[#626C77] hover:text-[#1D2023] rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Отмена
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmReset(true)}
                      className="w-full h-8 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-[#E30613] border border-rose-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Сбросить счётчики смены</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Карточка 3: Резервные копии и восстановление заявок */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between sm:col-span-2">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Резервные копии и импорт очереди
                  </span>
                  <p className="text-xs text-[#626C77] mt-1">
                    Мгновенный возврат карточек из авто-бэкапа или пакетная загрузка номеров
                  </p>
                </div>

                {restoreFeedback && (
                  <div className="mt-2.5 p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" />
                    <span>{restoreFeedback}</span>
                  </div>
                )}

                {importResultMsg && (
                  <div className="mt-2.5 p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800">
                    {importResultMsg}
                  </div>
                )}

                {showImportBox && (
                  <div className="mt-3 p-3 bg-[#F4F5F7] rounded-2xl border border-[#D5D8DD] space-y-2">
                    <label className="text-[11px] font-bold text-[#1D2023] block">
                      Вставьте номера абонентов (каждый с новой строки или через запятую):
                    </label>
                    <textarea
                      value={importText}
                      onChange={(e) => setImportText(e.target.value)}
                      placeholder="+7 (912) 000-00-00&#10;+79270000000&#10;89991234567..."
                      rows={3}
                      className="w-full p-2 rounded-xl bg-white border border-[#D5D8DD] text-xs font-mono text-[#1D2023] focus:border-[#1D2023] focus:outline-none"
                    />
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] text-[#626C77]">
                        Регионы и таймеры определятся автоматически
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setShowImportBox(false);
                            setImportText('');
                          }}
                          className="px-2.5 py-1 text-xs text-[#626C77] hover:text-[#1D2023] cursor-pointer"
                        >
                          Отмена
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (onImportLeadsText && importText.trim()) {
                              const count = onImportLeadsText(importText);
                              setImportResultMsg(`Успешно добавлено ${count} заявок в очередь!`);
                              setImportText('');
                              setShowImportBox(false);
                              setTimeout(() => setImportResultMsg(null), 3000);
                            }
                          }}
                          className="px-3.5 py-1 rounded-xl bg-[#E30613] hover:bg-[#C40510] text-white text-xs font-bold cursor-pointer"
                        >
                          Импортировать
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="pt-2.5 mt-3 border-t border-[#F1F3F5] flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (onRestoreBackup) {
                        const ok = onRestoreBackup();
                        setRestoreFeedback(
                          ok
                            ? 'Рабочие заявки успешно восстановлены из резервной копии!'
                            : 'Резервная копия пуста или ещё не была создана.'
                        );
                        setTimeout(() => setRestoreFeedback(null), 3500);
                      }
                    }}
                    className="h-8 px-3 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 border border-[#D5D8DD] text-[#1D2023] text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-[#626C77]" />
                    <span>Восстановить из авто-бэкапа</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowImportBox((v) => !v)}
                    className="h-8 px-3 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 border border-[#D5D8DD] text-[#626C77] hover:text-[#1D2023] text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#626C77]" />
                    <span>Импорт номеров списком (Excel / CRM)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* РАЗДЕЛ 4: ОБНОВЛЕНИЯ УРМ */}
          {activeTab === 'updates' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Карточка 1: Скачивание пакетов обновления */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                      Пакеты УРМ
                    </span>
                    <span className="text-[11px] font-semibold text-[#626C77]">
                      v{installedVersion}
                    </span>
                  </div>
                  <p className="text-xs text-[#626C77] mt-1">
                    Скачать файлы для быстрого или авто-обновления
                  </p>
                </div>

                <div className="my-3 space-y-2">
                  <button
                    type="button"
                    disabled={isDownloadingMts}
                    onClick={async () => {
                      setIsDownloadingMts(true);
                      try {
                        await downloadUpdateFile('2.7.5');
                        setDownloadDone(true);
                        setTimeout(() => setDownloadDone(false), 3000);
                      } catch (e) {
                        console.error('Ошибка скачивания обновления:', e);
                      } finally {
                        setIsDownloadingMts(false);
                      }
                    }}
                    className={`w-full h-9 px-3 rounded-xl text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs ${
                      downloadDone
                        ? 'bg-emerald-600 hover:bg-emerald-700'
                        : 'bg-[#E30613] hover:bg-[#C50410]'
                    } ${isDownloadingMts ? 'opacity-70 cursor-wait' : ''}`}
                  >
                    {downloadDone ? (
                      <>
                        <FileCheck className="w-4 h-4 text-white" />
                        <span>Скачано! (1.5 МБ)</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4 text-white" />
                        <span>{isDownloadingMts ? 'Загрузка...' : 'Скачать .mtsupdate (1.5 МБ)'}</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    disabled={isDownloadingAsar}
                    onClick={async () => {
                      setIsDownloadingAsar(true);
                      try {
                        await downloadAsarFile('update.asar');
                      } catch (e) {
                        console.error('Ошибка скачивания update.asar:', e);
                      } finally {
                        setIsDownloadingAsar(false);
                      }
                    }}
                    className={`w-full h-9 px-3 rounded-xl bg-[#1D2023] hover:bg-[#343A40] text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs ${
                      isDownloadingAsar ? 'opacity-70 cursor-wait' : ''
                    }`}
                  >
                    <FileCheck className="w-4 h-4 text-emerald-400" />
                    <span>{isDownloadingAsar ? 'Скачивание...' : 'Скачать update.asar (рядом с .exe)'}</span>
                  </button>
                </div>

                <div className="pt-2 border-t border-[#F1F3F5] flex items-center justify-between text-[11px] text-[#8C95A0]">
                  <span>Автообновление при старте .exe</span>
                  {installedVersion === '2.7.5' && (
                    <button
                      type="button"
                      onClick={() => {
                        localStorage.setItem('mts_app_installed_version', '2.7.4');
                        localStorage.removeItem('mts_dynamic_bundle_js');
                        localStorage.removeItem('mts_dynamic_bundle_css');
                        localStorage.removeItem('mts_app_last_update_pkg');
                        window.location.reload();
                      }}
                      className="text-[11px] text-[#626C77] hover:text-[#E30613] underline cursor-pointer transition-colors"
                      title="Сбросить версию на 2.7.4 для проверки механизма обновления"
                    >
                      Сбросить на 2.7.4 для теста
                    </button>
                  )}
                </div>
              </div>

              {/* Карточка 2: Ручная установка из файла на ПК */}
              <div className="bg-white rounded-3xl p-4 border border-[#F1F3F5] shadow-mts-card flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
                    Установка с компьютера
                  </span>
                  <p className="text-xs text-[#626C77] mt-1">
                    Выбор файла .mtsupdate через Проводник
                  </p>
                </div>

                <div className="my-3 p-3 rounded-2xl bg-[#F8F9FA] border border-[#EBECEF] text-[11px] text-[#626C77] leading-relaxed">
                  Если на УРМ заблокировано перетаскивание мышью (Drag & Drop), положите{' '}
                  <strong className="text-[#1D2023]">update.asar</strong> рядом с{' '}
                  <strong className="text-[#1D2023]">.exe</strong> или выберите файл{' '}
                  <strong className="text-[#1D2023]">.mtsupdate</strong> кнопкой ниже.
                </div>

                <div className="pt-2 border-t border-[#F1F3F5]">
                  <button
                    type="button"
                    onClick={() => updateFileInputRef.current?.click()}
                    className="w-full h-9 px-3 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 border border-[#D5D8DD] text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <PackageCheck className="w-4 h-4 text-[#626C77]" />
                    <span>Выбрать файл .mtsupdate на ПК</span>
                  </button>

                  <input
                    ref={updateFileInputRef}
                    type="file"
                    accept=".mtsupdate,.json,application/json"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file && onSelectUpdateFile) {
                        onSelectUpdateFile(file);
                        onClose();
                      }
                      e.target.value = '';
                    }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Нижняя панель кнопок */}
        <div className="px-6 py-3.5 border-t border-[#EBECEF] flex items-center justify-end gap-2.5 shrink-0 bg-white">
          <button
            type="button"
            onClick={onClose}
            className="h-9 px-5 rounded-xl border border-[#D5D8DD] hover:bg-gray-50 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer"
          >
            Закрыть
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="h-9 px-6 rounded-xl bg-[#E30613] hover:bg-[#C50410] active:scale-[0.98] text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};
