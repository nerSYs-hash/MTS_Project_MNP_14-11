import React from 'react';
import { Plus } from 'lucide-react';

interface BookWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookWorkspaceModal: React.FC<BookWorkspaceModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-x-0 top-18 bottom-0 z-35 bg-[#F4F5F7] p-2.5 sm:p-4 flex flex-col animate-in fade-in duration-200"
      role="region"
      aria-label="Окно книги"
    >
      {/* Пустое окно во всю рабочую площадь от края до края в стиле дизайна МТС */}
      <div className="relative flex-1 w-full h-full bg-white rounded-3xl border border-[#EBECEF] shadow-mts-card overflow-hidden">
        {/* Маленькая жемчужина в правом верхнем углу внутри окна с тем самым крестиком заместо кнопки закрыть */}
        <button
          type="button"
          onClick={onClose}
          title="Закрыть"
          aria-label="Закрыть окно"
          className="pearl-droplet-sphere overflow-hidden border-0 outline-none group absolute top-4 right-4 z-10 w-9 h-9 rounded-full flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        >
          <span className="relative z-10 flex items-center justify-center text-[#56606B] transition-transform duration-500 ease-in-out group-hover:rotate-360">
            <Plus className="w-4 h-4 stroke-[2.2]" />
          </span>
        </button>
      </div>
    </div>
  );
};
