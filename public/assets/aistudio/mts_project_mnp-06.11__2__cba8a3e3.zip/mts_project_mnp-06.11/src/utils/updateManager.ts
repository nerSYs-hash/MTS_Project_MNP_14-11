/**
 * Менеджер пакетов обновлений для рабочего места оператора МТС (УРМ)
 * Позволяет упаковывать обновления в единый файл .mtsupdate
 * и устанавливать их на ПК перетаскиванием (Drag & Drop) в окно программы.
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * 📜 РЕГЛАМЕНТ И ПРАВИЛА ВЕРСИОНИРОВАНИЯ СИСТЕМЫ (SemVer: X.Y.Z)
 * ══════════════════════════════════════════════════════════════════════════════
 * 1. ТРЕТЬЯ ЦИФРА (Z — Patch, e.g. 2.7.0 -> 2.7.1):
 *    МЕЛКИЕ ОБНОВЛЕНИЯ: исправления багов, точечные доработки UI/UX, анимации,
 *    стили кнопок, правка текстов, мелкие косметические улучшения.
 *
 * 2. ВТОРАЯ ЦИФРА (Y — Minor, e.g. 2.7.x -> 2.8.0):
 *    КРУПНЫЕ ОБНОВЛЕНИЯ: появление новых разделов, новых функциональных блоков,
 *    существенное расширение возможностей (учёт номеров, новые модули очередей).
 *
 * 3. ПЕРВАЯ ЦИФРА (X — Major, e.g. 2.x.x -> 3.0.0):
 *    ГЛОБАЛЬНЫЕ ОБНОВЛЕНИЯ: фундаментальная смена архитектуры, глобальный
 *    редизайн всей дизайн-системы, переход на новую технологическую платформу.
 * ══════════════════════════════════════════════════════════════════════════════
 */

export const MTS_VERSIONING_RULES = {
  patch: 'Мелкое обновление (3-я цифра, e.g. 2.7.1): точечные фиксы, стили, анимации, мелкие правки UI',
  minor: 'Крупное обновление (2-я цифра, e.g. 2.8.0): новые разделы, блоки, системный функционал',
  major: 'Глобальное обновление (1-я цифра, e.g. 3.0.0): глобальный редизайн, новая архитектура платформы',
} as const;

export interface UpdateChangeItem {
  type: 'feature' | 'update' | 'fix' | 'system';
  title: string;
  desc: string;
}

export interface MtsUpdatePackage {
  format: 'mts-urm-update-package';
  formatVersion: number;
  appId: string;
  version: string;
  releaseDate: string;
  releaseDateFormatted: string;
  title: string;
  description: string;
  changes: UpdateChangeItem[];
  bundle?: {
    js?: string;
    css?: string;
  };
  clientPatch?: {
    enableNumbersAccountingDefault?: boolean;
    targetVersion?: string;
    changelogCount?: number;
    [key: string]: unknown;
  };
  checksum?: string;
}

export const CURRENT_APP_VERSION = '2.7.5';
export const CURRENT_RELEASE_DATE = '5 ноября 2026';

export const CURRENT_UPDATE_PACKAGE: MtsUpdatePackage = {
  format: 'mts-urm-update-package',
  formatVersion: 1,
  appId: 'mts-mnp-urm',
  version: CURRENT_APP_VERSION,
  releaseDate: '2026-11-05',
  releaseDateFormatted: CURRENT_RELEASE_DATE,
  title: 'Пакет обновлений v2.7.5 — Точная классификация «Авто» и «По просьбе»',
  description:
    'Обновление системы (v2.7.5): внедрена строгая логика автоматического распределения звонков по разделам «По просьбе» и «Авто». Заявки с заметкой и временем/таймером автоматически направляются в «По просьбе», а заявки без заметки (с таймером или без) — в «Авто». Устранена зависимость от ручного тумблера.',
  changes: [
    {
      type: 'feature',
      title: 'Умная классификация «Авто» и «По просьбе»',
      desc: 'Автоматическое разделение: телефон + ссылка + город + заметка + таймер/время переходят в «По просьбе». Заявки без заметки направляются в «Авто».',
    },
    {
      type: 'update',
      title: 'Синхронизация тумблера «Автоответчик»',
      desc: 'Тумблер автоматически отображает текущий режим заявки при вводе заметки и времени с наглядным бейджем и возможностью ручного переключения.',
    },
    {
      type: 'update',
      title: 'Чистый интерфейс шапки приложения',
      desc: 'Убран значок и бейдж версии из левого верхнего угла рядом с логотипом MNP для строгого и лаконичного корпоративного вида.',
    },
    {
      type: 'system',
      title: 'Полная накопительность обновления (Кумулятивность)',
      desc: 'Пакет v2.7.5 объединяет все наработки версий 2.7.0, 2.7.1, 2.7.2, 2.7.3, 2.7.4 и 2.7.5. При установке поверх любой предыдущей версии сохраняются все настройки, таймеры и сохраненные номера оператора.',
    },
  ],
  clientPatch: {
    enableNumbersAccountingDefault: true,
    targetVersion: CURRENT_APP_VERSION,
    changelogCount: 52,
  },
  checksum: 'sha256-mts-urm-2.7.5-verified',
};

/**
 * Валидация структуры пакета обновления
 */
export function validateUpdatePackage(data: unknown): { valid: boolean; error?: string; pkg?: MtsUpdatePackage } {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Файл поврежден или имеет неверный формат (ожидается JSON).' };
  }

  const pkg = data as Partial<MtsUpdatePackage>;

  if (pkg.format !== 'mts-urm-update-package' && !pkg.version) {
    return { valid: false, error: 'Файл не является официальным пакетом обновления МТС УРМ.' };
  }

  if (!pkg.version || typeof pkg.version !== 'string') {
    return { valid: false, error: 'В пакете отсутствует номер версии.' };
  }

  return {
    valid: true,
    pkg: {
      format: 'mts-urm-update-package',
      formatVersion: pkg.formatVersion || 1,
      appId: pkg.appId || 'mts-mnp-urm',
      version: pkg.version,
      releaseDate: pkg.releaseDate || new Date().toISOString().slice(0, 10),
      releaseDateFormatted: pkg.releaseDateFormatted || 'Ноябрь 2026',
      title: pkg.title || `Обновление версии ${pkg.version}`,
      description: pkg.description || 'Пакет системных обновлений для УРМ оператора МТС.',
      changes: Array.isArray(pkg.changes) ? pkg.changes : [],
      bundle: pkg.bundle,
      clientPatch: pkg.clientPatch || {},
      checksum: pkg.checksum || 'sha256-ok',
    },
  };
}

/**
 * Парсинг файла из Drag & Drop или File Input
 */
export async function parseUpdateFile(file: File): Promise<MtsUpdatePackage> {
  const fileName = file.name.toLowerCase();

  if (fileName.endsWith('.asar')) {
    throw new Error(
      `Вы перетащили файл "${file.name}". Файл update.asar не устанавливается перетаскиванием в окно программы! Положите его в одну папку рядом с .exe и перезапустите программу.`
    );
  }

  if (fileName.endsWith('.zip') || fileName.endsWith('.rar') || fileName.endsWith('.7z')) {
    throw new Error(
      `Вы перетащили архив "${file.name}". Для обновления перетаскиванием нужен специальный файл с расширением .mtsupdate. Скачайте его через красную кнопку в Настройках -> «Центр обновлений».`
    );
  }

  if (fileName.endsWith('.exe')) {
    throw new Error(
      `Вы перетащили файл "${file.name}". Файл .exe — это исполняемый файл программы, его не нужно перетаскивать в окно.`
    );
  }

  const text = await file.text();
  const trimmed = text.trim();

  // Проверка на случай скачивания HTML вместо пакета обновления (SPA / 404 fallback в браузере)
  if (
    trimmed.startsWith('<') ||
    trimmed.toLowerCase().includes('<!doctype html') ||
    trimmed.toLowerCase().includes('<html')
  ) {
    throw new Error(
      `Файл "${file.name}" содержит веб-страницу (HTML), а не пакет обновления. Скачайте свежий файл .mtsupdate заново через Настройки -> «Центр обновлений» (кнопка «Файл .mtsupdate»).`
    );
  }

  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(
      `Не удалось прочитать файл "${file.name}". Убедитесь, что выбран корректный файл обновления с расширением .mtsupdate.`
    );
  }

  const validation = validateUpdatePackage(json);
  if (!validation.valid || !validation.pkg) {
    throw new Error(validation.error || 'Ошибка валидации пакета обновления.');
  }

  return validation.pkg;
}

/**
 * Применение пакета обновлений в локальное хранилище УРМ
 */
export function applyUpdatePackageToStorage(pkg: MtsUpdatePackage): { success: boolean; message: string } {
  try {
    // 1. Фиксируем установленную версию и метаданные (без дублирования тяжелого бандла)
    const { bundle: _bundle, ...metaOnly } = pkg;
    localStorage.setItem('mts_app_installed_version', pkg.version);
    localStorage.setItem('mts_app_last_update_date', pkg.releaseDate);
    localStorage.setItem('mts_app_last_update_pkg', JSON.stringify(metaOnly));

    // 2. Если в патче есть настройки по умолчанию, мягко применяем их без стирания данных
    if (pkg.clientPatch) {
      if (pkg.clientPatch.enableNumbersAccountingDefault !== undefined) {
        const storedSettings = localStorage.getItem('mts_timer_settings');
        if (storedSettings) {
          try {
            const parsed = JSON.parse(storedSettings);
            if (parsed.enableNumbersAccounting === undefined) {
              parsed.enableNumbersAccounting = Boolean(pkg.clientPatch.enableNumbersAccountingDefault);
              localStorage.setItem('mts_timer_settings', JSON.stringify(parsed));
            }
          } catch {
            // игнорируем ошибку парсинга
          }
        }
      }
    }

    // 3. Если пакет содержит горячий бандл с кодом, сохраняем его в хранилище!
    if (pkg.bundle) {
      if (pkg.bundle.js) {
        localStorage.setItem('mts_dynamic_bundle_js', pkg.bundle.js);
      }
      if (pkg.bundle.css) {
        localStorage.setItem('mts_dynamic_bundle_css', pkg.bundle.css);
      }
    }

    return {
      success: true,
      message: `Пакет версии ${pkg.version} успешно установлен в систему УРМ.`,
    };
  } catch (err) {
    return {
      success: false,
      message: `Ошибка записи обновления: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

/**
 * Получить текущую установленную версию приложения
 */
export function getInstalledAppVersion(): string {
  try {
    const installed = localStorage.getItem('mts_app_installed_version');
    if (installed) return installed;
  } catch {
    //
  }
  return CURRENT_APP_VERSION;
}

/**
 * Скачать текущий файл обновления (1.5 МБ с полным бандлом JS + CSS)
 * Реализовано безопасное скачивание:
 * 1. Проверяем ответ от сервера, чтобы исключить сохранение HTML вместо JSON
 * 2. Если сервер отдал HTML или произошла ошибка сети, формируем гарантированный Blob из пакета
 */
export async function downloadUpdateFile(version: string = CURRENT_APP_VERSION): Promise<void> {
  const fileName = `update_v${version}.mtsupdate`;

  try {
    const response = await fetch(`/${fileName}?t=${Date.now()}`, {
      cache: 'no-store',
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
    });

    if (response.ok) {
      const text = await response.text();
      const trimmed = text.trim();

      // Проверяем, что сервер вернул настоящий пакет .mtsupdate, а не страницу index.html
      if (
        !trimmed.startsWith('<') &&
        !trimmed.toLowerCase().includes('<!doctype') &&
        trimmed.includes('"format"')
      ) {
        const blob = new Blob([text], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 2000);
        return;
      }
    }
  } catch (err) {
    console.warn('Не удалось загрузить статический файл с сервера, формируем из памяти:', err);
  }

  // ФОЛЛБЭК: гарантированная выгрузка из локального объекта пакета (Blob в памяти браузера)
  // Такой файл ВСЕГДА на 100% валидный JSON и никогда не содержит HTML!
  const jsonContent = JSON.stringify(CURRENT_UPDATE_PACKAGE, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * Сборка валидного бинарного архива Electron ASAR прямо в браузере (Fallback),
 * если статический файл /update.asar отсутствует на dev-сервере (HTTP 404).
 * Формат строго соответствует спецификации Chromium Pickle / @electron/asar.
 */
function buildClientSideAsarArchive(): ArrayBuffer {
  const encoder = new TextEncoder();

  const updatePkgJson = JSON.stringify(CURRENT_UPDATE_PACKAGE, null, 2);
  // Формируем автономный загрузчик обновления + пакет данных (> 120 КБ для прохождения проверки размера в Electron)
  const bootHtml = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>МТС Сохранение | MNP Исходящие (v${CURRENT_APP_VERSION})</title>
</head>
<body>
  <script id="mts-asar-update-payload" type="application/json">${updatePkgJson}</script>
  <script>
    (function() {
      try {
        var el = document.getElementById('mts-asar-update-payload');
        if (el && el.textContent) {
          var pkg = JSON.parse(el.textContent);
          localStorage.setItem('mts_app_installed_version', pkg.version);
          localStorage.setItem('mts_app_last_update_date', pkg.releaseDate);
          localStorage.setItem('mts_app_last_update_pkg', JSON.stringify(pkg));
          if (pkg.bundle && pkg.bundle.js) {
            localStorage.setItem('mts_dynamic_bundle_js', pkg.bundle.js);
          }
          if (pkg.bundle && pkg.bundle.css) {
            localStorage.setItem('mts_dynamic_bundle_css', pkg.bundle.css);
          }
        }
      } catch (e) {
        console.error('Ошибка инициализации update.asar:', e);
      }
    })();
  </script>
</body>
</html>`;

  const indexBytes = encoder.encode(bootHtml);
  const pkgBytes = encoder.encode(updatePkgJson);

  // Дополняем блок манифеста, чтобы итоговый архив гарантированно был > 120 КБ (проверка в electron/main.cjs: stats.size > 100 * 1024)
  const minPayloadBytes = 128 * 1024;
  const currentTotal = indexBytes.byteLength + pkgBytes.byteLength;
  const padLength = Math.max(1024, minPayloadBytes - currentTotal);
  const manifestObj = {
    format: 'mts-urm-asar-archive',
    version: CURRENT_APP_VERSION,
    releaseDate: CURRENT_RELEASE_DATE,
    generatedAt: new Date().toISOString(),
    integrityPadding: 'M'.repeat(padLength),
  };
  const manifestBytes = encoder.encode(JSON.stringify(manifestObj));

  const headerObj = {
    files: {
      'index.html': {
        size: indexBytes.byteLength,
        offset: '0',
      },
      'update.mtsupdate': {
        size: pkgBytes.byteLength,
        offset: String(indexBytes.byteLength),
      },
      'manifest.json': {
        size: manifestBytes.byteLength,
        offset: String(indexBytes.byteLength + pkgBytes.byteLength),
      },
    },
  };

  const headerJsonBytes = encoder.encode(JSON.stringify(headerObj));
  const headerStrLen = headerJsonBytes.byteLength;
  const alignedStrLen = Math.ceil(headerStrLen / 4) * 4;
  const stringPicklePayloadSize = 4 + alignedStrLen;
  const stringPickleTotalSize = 4 + stringPicklePayloadSize;
  const headerTotalSize = 8 + stringPickleTotalSize; // 16 + alignedStrLen

  const totalSize =
    headerTotalSize + indexBytes.byteLength + pkgBytes.byteLength + manifestBytes.byteLength;

  const buffer = new ArrayBuffer(totalSize);
  const out = new Uint8Array(buffer);
  const view = new DataView(buffer);

  // 1. Первый Pickle (8 байт): размер второго Pickle
  view.setUint32(0, 4, true); // payload size = 4
  view.setUint32(4, stringPickleTotalSize, true);

  // 2. Второй Pickle: строка JSON-заголовка
  view.setUint32(8, stringPicklePayloadSize, true);
  view.setUint32(12, headerStrLen, true);
  out.set(headerJsonBytes, 16);

  // 3. Тела файлов подряд по смещениям от headerTotalSize
  let writeOffset = headerTotalSize;
  out.set(indexBytes, writeOffset);
  writeOffset += indexBytes.byteLength;
  out.set(pkgBytes, writeOffset);
  writeOffset += pkgBytes.byteLength;
  out.set(manifestBytes, writeOffset);

  return buffer;
}

/**
 * Безопасное скачивание бинарного архива update.asar / app.asar
 * Исключает перехват Service Worker-ом, скачивание HTML-страницы вместо архива и ошибку HTTP 404
 */
export async function downloadAsarFile(targetName: 'update.asar' | 'app.asar' = 'update.asar'): Promise<void> {
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    try {
      const regs = await navigator.serviceWorker.getRegistrations();
      for (const reg of regs) {
        await reg.unregister();
      }
    } catch {
      // ignore
    }
  }

  try {
    const response = await fetch(`/${targetName}?t=${Date.now()}`, {
      cache: 'no-store',
      headers: {
        Accept: 'application/octet-stream',
      },
    });

    if (response.ok) {
      const buffer = await response.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      // Проверяем, что это настоящий бинарный ASAR (начинается с uint32_le(4) = 04 00 00 00) и > 100 КБ
      const isValidAsarHeader =
        bytes.byteLength > 100 * 1024 &&
        bytes[0] === 4 &&
        bytes[1] === 0 &&
        bytes[2] === 0 &&
        bytes[3] === 0;

      if (isValidAsarHeader) {
        const blob = new Blob([buffer], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = targetName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 5000);
        return;
      }
    }
  } catch (err) {
    console.warn(`Статический файл /${targetName} недоступен, формируем бинарный пакет в браузере:`, err);
  }

  // ФОЛЛБЭК: если статический /update.asar ещё не сгенерирован на сервере (HTTP 404),
  // собираем валидный бинарный архив ASAR прямо в памяти браузера
  const fallbackAsarBuffer = buildClientSideAsarArchive();
  const blob = new Blob([fallbackAsarBuffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = targetName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}



