/**
 * Рабочее место оператора группы сохранения клиентов МТС (MNP)
 * Полная интеграция: таймеры перезвона, часы ПК, автоопределение поясов РФ и расчет конверсии
 */
import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Maximize2, Check } from 'lucide-react';
import { Header } from './components/Header';
import { KpiDashboard } from './components/KpiDashboard';
import { AddClientForm } from './components/AddClientForm';
import { UrgentAlertBanner } from './components/UrgentAlertBanner';
import { ClientQueue } from './components/ClientQueue';
import { SavedClientsTable } from './components/SavedClientsTable';
import { SettingsModal } from './components/SettingsModal';
import { ChangelogModal } from './components/ChangelogModal';
import { DesktopInstallModal } from './components/DesktopInstallModal';
import { UpdateDropOverlay } from './components/UpdateDropOverlay';
import { UpdateInstallModal } from './components/UpdateInstallModal';
import { OnboardingGuideModal } from './components/OnboardingGuideModal';
import { NotificationToastContainer } from './components/NotificationToast';
import { EdgeQuickDock } from './components/EdgeQuickDock';
import { BookWorkspaceModal } from './components/BookWorkspaceModal';
import { parseUpdateFile, MtsUpdatePackage } from './utils/updateManager';
import { useSystemClock } from './hooks/useSystemClock';
import { usePWAInstall } from './hooks/usePWAInstall';
import { ClientLead, CallStatus, ShiftStats, TimerSettings, SavedClientRecord, SavedClientType } from './types';
import {
  loadLeadsFromStorage,
  saveLeadsToStorage,
  loadBackupLeadsFromStorage,
  loadStatsFromStorage,
  saveStatsToStorage,
  loadSettingsFromStorage,
  saveSettingsToStorage,
  loadSavedClientsFromStorage,
  saveSavedClientsToStorage,
  DEFAULT_SETTINGS,
  INITIAL_STATS,
} from './utils/storage';
import {
  cleanPhoneNumber,
  formatPhoneNumber,
  findRegionByPhone,
  cleanToStrictMtsPhone,
} from './data/regionsData';
import { playChimeSound, sendDesktopNotification } from './utils/audioAlert';

export default function App() {
  const clock = useSystemClock();

  // Состояние клиентов, статистики смены и настроек (с автонормализацией активных таймеров)
  const [leads, setLeads] = useState<ClientLead[]>(() => {
    const loaded = loadLeadsFromStorage();
    const now = Date.now();
    return loaded.map((lead) => {
      const isActive =
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable';
      if (isActive && (!lead.targetCallbackTime || lead.targetCallbackTime <= 0)) {
        const duration = lead.timerDurationMinutes || 30;
        return {
          ...lead,
          status: lead.scheduledByAgreedTime ? ('callback' as CallStatus) : ('answering_machine' as CallStatus),
          targetCallbackTime: now + duration * 60 * 1000,
          timerDurationMinutes: duration,
          scheduledByAgreedTime: Boolean(lead.scheduledByAgreedTime),
        };
      }
      // Исправление карточек, которым ранее ошибочно выставлялось 45 мин при 2-й попытке вместо 30 мин по умолчанию
      if (
        isActive &&
        lead.timerDurationMinutes === 45 &&
        lead.targetCallbackTime &&
        lead.targetCallbackTime - now > 30 * 60 * 1000
      ) {
        const elapsedMs = 45 * 60 * 1000 - (lead.targetCallbackTime - now);
        const correctedRemainingMs = Math.max(60 * 1000, 30 * 60 * 1000 - Math.max(0, elapsedMs));
        return {
          ...lead,
          timerDurationMinutes: 30,
          targetCallbackTime: now + correctedRemainingMs,
        };
      }
      return lead;
    });
  });
  const [stats, setStats] = useState<ShiftStats>(() => loadStatsFromStorage());
  const [settings, setSettings] = useState<TimerSettings>(() => loadSettingsFromStorage());

  // Сохраненные клиенты (Журнал сохранений)
  const [savedClients, setSavedClients] = useState<SavedClientRecord[]>(() =>
    loadSavedClientsFromStorage()
  );
  const [isSavedTableExpanded, setIsSavedTableExpanded] = useState<boolean>(() => {
    try {
      return localStorage.getItem('mts_saved_table_expanded') === 'true';
    } catch {
      return false;
    }
  });

  // Состояние модалок и уведомлений
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isChangelogOpen, setIsChangelogOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isBookWindowOpen, setIsBookWindowOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(() => {
    try {
      return localStorage.getItem('mts_urm_onboarding_completed') !== 'true';
    } catch {
      return false;
    }
  });
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Центр обновлений УРМ: Drag & Drop и файловый установщик
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [pendingUpdatePackage, setPendingUpdatePackage] = useState<MtsUpdatePackage | null>(null);
  const [updateError, setUpdateError] = useState<string | null>(null);

  const handleFileSelectedForUpdate = async (file: File) => {
    try {
      setUpdateError(null);
      const pkg = await parseUpdateFile(file);
      setPendingUpdatePackage(pkg);
      setIsUpdateModalOpen(true);
    } catch (err) {
      setPendingUpdatePackage(null);
      setUpdateError(err instanceof Error ? err.message : 'Неизвестная ошибка чтения пакета обновления');
      setIsUpdateModalOpen(true);
    }
  };

  // Режим ожидания АРМ (сворачивает форму и очередь, перемещая 4 KPI блока в центр экрана)
  const [isStandbyMode, setIsStandbyMode] = useState(false);
  const lastActivityRef = useRef<number>(Date.now());
  const [isFormCollapsed, setIsFormCollapsed] = useState(false);
  const [highlightedLeadId, setHighlightedLeadId] = useState<string | null>(null);

  // Состояния пульсации цифр KPI при изменении
  const [isCallsPulsing, setIsCallsPulsing] = useState(false);
  const [isSavedPulsing, setIsSavedPulsing] = useState(false);

  // Десктопная установка PWA
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Множество id лидов, о которых уже проигран звуковой сигнал при истечении таймера
  const notifiedLeadIdsRef = useRef<Set<string>>(new Set());
  const queueSectionRef = useRef<HTMLDivElement>(null);

  // Автосохранение в localStorage при изменениях
  useEffect(() => {
    saveLeadsToStorage(leads);
  }, [leads]);

  useEffect(() => {
    saveStatsToStorage(stats);
  }, [stats]);

  useEffect(() => {
    saveSettingsToStorage(settings);
  }, [settings]);

  useEffect(() => {
    saveSavedClientsToStorage(savedClients);
  }, [savedClients]);

  useEffect(() => {
    try {
      localStorage.setItem('mts_saved_table_expanded', String(isSavedTableExpanded));
    } catch {
      // ignore
    }
  }, [isSavedTableExpanded]);

  // Проверка истекших таймеров каждую секунду при изменении системных часов
  useEffect(() => {
    const expiredList = leads.filter((lead) => {
      const isActive =
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable';
      if (isActive && lead.targetCallbackTime) {
        return lead.targetCallbackTime <= clock.nowTimestamp;
      }
      return false;
    });

    for (const lead of expiredList) {
      if (!notifiedLeadIdsRef.current.has(lead.id)) {
        notifiedLeadIdsRef.current.add(lead.id);

        if (settings.soundEnabled) {
          playChimeSound(settings.volume);
        }

        sendDesktopNotification({
          title: 'Требуется исходящий вызов',
          phone: lead.phone,
          attempt: lead.attemptCount || 1,
          maxAttempts: lead.maxAttempts || 3,
          region: lead.regionName || lead.city || 'Москва',
          leadId: lead.id,
        });
      }
    }
  }, [clock.nowTimestamp, leads, settings.soundEnabled, settings.volume]);

  // Слушатель перехода к карточке абонента из Push/Toast уведомления
  useEffect(() => {
    const handleFocusLead = (e: Event) => {
      const customEvent = e as CustomEvent<{ leadId?: string; phone?: string }>;
      const { leadId, phone } = customEvent.detail || {};

      setIsStandbyMode(false);

      let targetId = leadId;
      if (!targetId && phone) {
        const found = leads.find((l) => l.phone === phone || l.rawPhone === phone);
        if (found) targetId = found.id;
      }

      if (targetId) {
        setHighlightedLeadId(targetId);
        setTimeout(() => {
          const el = document.getElementById(`card-${targetId}`);
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 120);

        setTimeout(() => {
          setHighlightedLeadId((prev) => (prev === targetId ? null : prev));
        }, 4500);
      }
    };

    window.addEventListener('mts-focus-lead', handleFocusLead);
    return () => window.removeEventListener('mts-focus-lead', handleFocusLead);
  }, [leads]);

  // Вычисление конверсии в процентах
  const recalculateStats = (partial: Partial<ShiftStats>) => {
    setStats((prev) => {
      const updated = { ...prev, ...partial };
      const calls = Math.max(0, updated.totalCallsCount);
      const saved = Math.max(0, updated.savedCount);
      const rate = calls > 0 ? Number(((saved / calls) * 100).toFixed(1)) : 0;
      return {
        ...updated,
        totalCallsCount: calls,
        savedCount: saved,
        conversionRate: rate,
      };
    });
  };

  // Быстрые кнопки +1 и -1 для звонков
  const handleAdjustCalls = (delta: number) => {
    recalculateStats({
      totalCallsCount: Math.max(0, stats.totalCallsCount + delta),
    });
    if (delta > 0) {
      setIsCallsPulsing(true);
      setTimeout(() => setIsCallsPulsing(false), 450);
    }
  };

  // Быстрые кнопки +1 и -1 для сохранений
  const handleAdjustSaved = (delta: number) => {
    recalculateStats({
      savedCount: Math.max(0, stats.savedCount + delta),
    });
    if (delta > 0) {
      setIsSavedPulsing(true);
      setTimeout(() => setIsSavedPulsing(false), 450);
    }
  };

  // Добавление нового клиента через «Записать»
  const handleAddClient = (
    newLeadData: Omit<ClientLead, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const id = `lead_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = Date.now();

    // Запись контакта: прибавляем 1 звонок
    recalculateStats({
      totalCallsCount: stats.totalCallsCount + 1,
    });
    setIsCallsPulsing(true);
    setTimeout(() => setIsCallsPulsing(false), 450);

    const isAgreed = Boolean(newLeadData.scheduledByAgreedTime);
    const defaultTimer = settings.attempt1Minutes || 30;
    const duration = newLeadData.timerDurationMinutes ?? defaultTimer;
    const targetTime = newLeadData.targetCallbackTime ?? (now + duration * 60 * 1000);

    const createdLead: ClientLead = {
      ...newLeadData,
      id,
      status: newLeadData.status || (isAgreed ? 'callback' : 'answering_machine'),
      attemptCount: newLeadData.attemptCount || 1,
      maxAttempts: newLeadData.maxAttempts || 3,
      targetCallbackTime: targetTime,
      timerDurationMinutes: duration,
      lastCallTime: newLeadData.lastCallTime || now,
      scheduledByAgreedTime: isAgreed,
      createdAt: now,
      updatedAt: now,
    };

    // Всегда поднимаем новую заполненную заявку первой в списке!
    setLeads((prev) => [createdLead, ...prev]);
  };

  // Обновление статуса звонка существующего клиента
  const handleUpdateStatus = (
    id: string,
    newStatus: CallStatus,
    options?: {
      customTimerMinutes?: number;
      notes?: string;
      isClientAgreed?: boolean;
      attemptCount?: number;
    }
  ) => {
    const now = Date.now();

    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id !== id) return lead;

        notifiedLeadIdsRef.current.delete(lead.id);

        let nextTargetTime: number | null = null;
        let nextDuration: number | null = null;
        let nextAgreed = lead.scheduledByAgreedTime;
        let nextAttempt = lead.attemptCount;

        if (newStatus === 'callback') {
          nextDuration = options?.customTimerMinutes || 30;
          nextTargetTime = now + nextDuration * 60 * 1000;
          nextAgreed = options?.isClientAgreed !== undefined ? options.isClientAgreed : true;

          // Если карточка возвращается в работу из завершенных статусов — корректируем счётчики
          if (lead.status === 'saved') {
            recalculateStats({ savedCount: Math.max(0, stats.savedCount - 1) });
          } else if (lead.status === 'refused') {
            recalculateStats({ refusedCount: Math.max(0, stats.refusedCount - 1) });
          } else if (lead.status === 'unreachable') {
            recalculateStats({ unreachableCount: Math.max(0, (stats.unreachableCount || 0) - 1) });
          }
        } else if (newStatus === 'answering_machine') {
          // Следующая попытка дозвона (автоответчик) — по умолчанию всегда 30 минут
          nextAttempt =
            options?.attemptCount !== undefined
              ? options.attemptCount
              : Math.min(lead.maxAttempts, lead.attemptCount + 1);
          nextDuration = options?.customTimerMinutes || 30;
          nextTargetTime = now + nextDuration * 60 * 1000;
          nextAgreed = false;

          // Если карточка возвращается в работу из завершенных статусов — корректируем счётчики
          if (lead.status === 'saved') {
            recalculateStats({ savedCount: Math.max(0, stats.savedCount - 1) });
          } else if (lead.status === 'refused') {
            recalculateStats({ refusedCount: Math.max(0, stats.refusedCount - 1) });
          } else if (lead.status === 'unreachable') {
            recalculateStats({ unreachableCount: Math.max(0, (stats.unreachableCount || 0) - 1) });
          }
        } else if (newStatus === 'saved') {
          nextTargetTime = null;
          nextDuration = null;
          if (lead.status !== 'saved') {
            const statsUpdates: Partial<ShiftStats> = {
              savedCount: stats.savedCount + 1,
            };
            if (lead.status === 'refused') {
              statsUpdates.refusedCount = Math.max(0, stats.refusedCount - 1);
            } else if (lead.status === 'unreachable') {
              statsUpdates.unreachableCount = Math.max(0, (stats.unreachableCount || 0) - 1);
            }
            recalculateStats(statsUpdates);
            setIsSavedPulsing(true);
            setTimeout(() => setIsSavedPulsing(false), 450);

            // Автоматическое занесение сохранений по АВТО и По просьбе в таблицу
            const rawDigits = cleanToStrictMtsPhone(lead.rawPhone || lead.phone) || cleanPhoneNumber(lead.rawPhone || lead.phone);
            const strictPhone = rawDigits.length === 11 && rawDigits.startsWith('7') ? rawDigits : (rawDigits.length === 10 ? '7' + rawDigits : rawDigits);
            const nowD = new Date();
            const timeStr = `${String(nowD.getHours()).padStart(2, '0')}:${String(nowD.getMinutes()).padStart(2, '0')}`;
            const hasNotes = Boolean(lead.notes && lead.notes.trim().length > 0);
            const isAgreed = hasNotes && !lead.isAnsweringMachineForced && Boolean(lead.scheduledByAgreedTime || lead.status === 'callback');
            const savedType: SavedClientType = isAgreed ? 'По просьбе' : 'АВТО';

            const newRecord: SavedClientRecord = {
              id: `saved_${now}_${Math.random().toString(36).substring(2, 7)}`,
              phone: strictPhone,
              time: timeStr,
              type: savedType,
              timestamp: now,
            };

            setSavedClients((prev) => [newRecord, ...prev]);
          }
        } else if (newStatus === 'refused') {
          nextTargetTime = null;
          nextDuration = null;
          if (lead.status !== 'refused') {
            const statsUpdates: Partial<ShiftStats> = {
              refusedCount: stats.refusedCount + 1,
            };
            if (lead.status === 'saved') {
              statsUpdates.savedCount = Math.max(0, stats.savedCount - 1);
            } else if (lead.status === 'unreachable') {
              statsUpdates.unreachableCount = Math.max(0, (stats.unreachableCount || 0) - 1);
            }
            recalculateStats(statsUpdates);
          }
        } else if (newStatus === 'unreachable') {
          nextTargetTime = null;
          nextDuration = null;
          if (lead.status !== 'unreachable') {
            const statsUpdates: Partial<ShiftStats> = {
              unreachableCount: (stats.unreachableCount || 0) + 1,
            };
            if (lead.status === 'saved') {
              statsUpdates.savedCount = Math.max(0, stats.savedCount - 1);
            } else if (lead.status === 'refused') {
              statsUpdates.refusedCount = Math.max(0, stats.refusedCount - 1);
            }
            recalculateStats(statsUpdates);
          }
        }

        return {
          ...lead,
          status: newStatus,
          attemptCount: options?.attemptCount !== undefined ? options.attemptCount : nextAttempt,
          targetCallbackTime: nextTargetTime,
          timerDurationMinutes: nextDuration,
          scheduledByAgreedTime: nextAgreed,
          lastCallTime: now,
          notes: options?.notes !== undefined ? options.notes : lead.notes,
          updatedAt: now,
        };
      })
    );
  };

  // Удаление клиента
  const handleDeleteLead = (id: string) => {
    notifiedLeadIdsRef.current.delete(id);
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  // Обновление заметок (при добавлении заметки заявка переходит в «По просьбе»)
  const handleUpdateNotes = (id: string, notes: string) => {
    const trimmed = notes.trim();
    const hasNotes = trimmed.length > 0;
    setLeads((prev) =>
      prev.map((l) => {
        if (l.id !== id) return l;
        return {
          ...l,
          notes,
          status: hasNotes
            ? l.status === 'answering_machine'
              ? 'callback'
              : l.status
            : l.isAnsweringMachineForced
            ? 'answering_machine'
            : l.status,
          scheduledByAgreedTime: hasNotes ? true : l.scheduledByAgreedTime,
          isAnsweringMachineForced: hasNotes ? false : l.isAnsweringMachineForced,
          updatedAt: Date.now(),
        };
      })
    );
  };

  // Редактирование данных карточки (номер телефона, ссылка CRM, город)
  const handleUpdateLead = (id: string, updates: Partial<ClientLead>) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates, updatedAt: Date.now() } : l))
    );
  };

  // Быстрое копирование номера (строго чистые 11 цифр: 79XXXXXXXXX)
  const handleCopyPhone = (phone: string) => {
    const cleanDigits = cleanPhoneNumber(phone);
    navigator.clipboard.writeText(cleanDigits);
    setCopiedId(phone);
    setTimeout(() => setCopiedId(null), 1800);
  };

  // Глобальный перехват копирования: если оператор выделяет номер телефона в любом месте проекта
  // (мышкой, двойным кликом, из инпута или карточки) и нажимает Ctrl+C / Копировать —
  // в буфер обмена ВСЕГДА попадает чистый номер без скобок и дефисов: 79XXXXXXXXX
  useEffect(() => {
    const handleGlobalCopy = (e: ClipboardEvent) => {
      const selected = window.getSelection()?.toString()?.trim();
      if (!selected) return;

      const digits = selected.replace(/\D/g, '');
      // Российский номер из 11 цифр (начинается с 7 или 8)
      if (digits.length === 11 && (digits.startsWith('7') || digits.startsWith('8'))) {
        const clean = '7' + digits.slice(1);
        if (e.clipboardData) {
          e.clipboardData.setData('text/plain', clean);
          e.preventDefault();
        }
      } else if (digits.length === 10 && digits.startsWith('9')) {
        const clean = '7' + digits;
        if (e.clipboardData) {
          e.clipboardData.setData('text/plain', clean);
          e.preventDefault();
        }
      }
    };

    document.addEventListener('copy', handleGlobalCopy);
    return () => document.removeEventListener('copy', handleGlobalCopy);
  }, []);

  // Переход к очереди перезвонов при клике на KPI карточку «Ожидание / В очереди»
  const handleFocusDueQueue = () => {
    setIsStandbyMode(false);
    const targetLead = expiredLeads[0] || activeLeads[0];
    if (targetLead) {
      setHighlightedLeadId(targetLead.id);
      const el = document.getElementById(`card-${targetLead.id}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        queueSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
      setTimeout(() => {
        setHighlightedLeadId((curr) => (curr === targetLead.id ? null : curr));
      }, 5000);
    } else {
      queueSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Клик по карточке в срочном баннере мгновенно переходит к ней в очереди и подсвечивает
  const handleSelectLeadFromBanner = (id: string) => {
    setIsStandbyMode(false);
    setHighlightedLeadId(id);
    const el = document.getElementById(`card-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      queueSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
    setTimeout(() => {
      setHighlightedLeadId((curr) => (curr === id ? null : curr));
    }, 5000);
  };

  // Сброс смены (обнуление счетчиков для начала новой смены)
  const handleResetShift = () => {
    setStats({
      savedCount: 0,
      totalCallsCount: 0,
      conversionRate: 0,
      unreachableCount: 0,
      refusedCount: 0,
      savedWithoutTpChange: 0,
      savedWithEi: 0,
      shiftStartTime: Date.now(),
    });
    notifiedLeadIdsRef.current.clear();
  };

  // Изменение счетчика «Без смены ТП»
  const handleAdjustSavedWithoutTpChange = (delta: number) => {
    const currentSub = stats.savedWithoutTpChange || 0;
    const nextSub = Math.max(0, currentSub + delta);
    const diff = nextSub - currentSub;
    const shouldInclude = settings.includeWithoutTpInSaved !== false;
    recalculateStats({
      savedWithoutTpChange: nextSub,
      savedCount: shouldInclude ? Math.max(0, stats.savedCount + diff) : stats.savedCount,
    });
  };

  // Изменение счетчика «ЕИ» (Единый Инструмент)
  const handleAdjustSavedWithEi = (delta: number) => {
    const currentSub = stats.savedWithEi || 0;
    const nextSub = Math.max(0, currentSub + delta);
    const diff = nextSub - currentSub;
    const shouldInclude = settings.includeEiInSaved !== false;
    recalculateStats({
      savedWithEi: nextSub,
      savedCount: shouldInclude ? Math.max(0, stats.savedCount + diff) : stats.savedCount,
    });
  };

  // Ручная отмена по СЗ для «Без смены ТП» (мгновенно отнимает 1 из Сохранений даже при выключенном тумблере)
  const handleManualSzDeductWithoutTp = () => {
    const currentSub = stats.savedWithoutTpChange || 0;
    const nextSub = Math.max(0, currentSub - 1);
    recalculateStats({
      savedWithoutTpChange: nextSub,
      savedCount: Math.max(0, stats.savedCount - 1),
    });
  };

  // Ручной учет по СЗ для «Без смены ТП» (мгновенно прибавляет 1 в Сохранения даже при выключенном тумблере)
  const handleManualSzAddWithoutTp = () => {
    const currentSub = stats.savedWithoutTpChange || 0;
    recalculateStats({
      savedWithoutTpChange: currentSub + 1,
      savedCount: stats.savedCount + 1,
    });
  };

  // Ручная отмена по СЗ для «ЕИ»
  const handleManualSzDeductEi = () => {
    const currentSub = stats.savedWithEi || 0;
    const nextSub = Math.max(0, currentSub - 1);
    recalculateStats({
      savedWithEi: nextSub,
      savedCount: Math.max(0, stats.savedCount - 1),
    });
  };

  // Ручной учет по СЗ для «ЕИ»
  const handleManualSzAddEi = () => {
    const currentSub = stats.savedWithEi || 0;
    recalculateStats({
      savedWithEi: currentSub + 1,
      savedCount: stats.savedCount + 1,
    });
  };

  // Сохранение настроек с мгновенной синхронизацией сохраненных позиций при переключении тумблеров
  const handleSaveSettings = (newSettings: TimerSettings) => {
    let deltaSaved = 0;
    const wasWithoutTp = settings.includeWithoutTpInSaved !== false;
    const nowWithoutTp = newSettings.includeWithoutTpInSaved !== false;
    if (wasWithoutTp && !nowWithoutTp) {
      deltaSaved -= (stats.savedWithoutTpChange || 0);
    } else if (!wasWithoutTp && nowWithoutTp) {
      deltaSaved += (stats.savedWithoutTpChange || 0);
    }

    const wasEi = settings.includeEiInSaved !== false;
    const nowEi = newSettings.includeEiInSaved !== false;
    if (wasEi && !nowEi) {
      deltaSaved -= (stats.savedWithEi || 0);
    } else if (!wasEi && nowEi) {
      deltaSaved += (stats.savedWithEi || 0);
    }

    if (deltaSaved !== 0) {
      recalculateStats({
        savedCount: Math.max(0, stats.savedCount + deltaSaved),
      });
    }

    setSettings(newSettings);
  };

  // Восстановление заявок из автоматической резервной копии
  const handleRestoreBackup = (): boolean => {
    const backup = loadBackupLeadsFromStorage();
    if (backup && backup.length > 0) {
      setLeads(backup);
      return true;
    }
    return false;
  };

  // Быстрый текстовый импорт номеров для восстановления списка (из Excel, CRM, Блокнота)
  const handleImportLeadsText = (text: string): number => {
    if (!text || !text.trim()) return 0;

    // Извлечение последовательностей цифр или номеров
    const rawMatches = text.match(/(?:(?:\+?7|8)[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{2}[-.\s]?[0-9]{2}/g) || [];
    const extractedNumbers: string[] = [];

    // Также пробуем построчно
    const lines = text.split(/[\r\n;,]+/);
    for (const line of lines) {
      const cleaned = cleanPhoneNumber(line);
      if (cleaned.length >= 10) {
        const normalized = cleaned.length === 10 ? '7' + cleaned : (cleaned.startsWith('8') ? '7' + cleaned.slice(1) : cleaned);
        if (normalized.length === 11 && !extractedNumbers.includes(normalized)) {
          extractedNumbers.push(normalized);
        }
      }
    }

    for (const m of rawMatches) {
      const cleaned = cleanPhoneNumber(m);
      const normalized = cleaned.length === 10 ? '7' + cleaned : (cleaned.startsWith('8') ? '7' + cleaned.slice(1) : cleaned);
      if (normalized.length === 11 && !extractedNumbers.includes(normalized)) {
        extractedNumbers.push(normalized);
      }
    }

    if (extractedNumbers.length === 0) return 0;

    const now = Date.now();
    const newLeads: ClientLead[] = extractedNumbers.map((raw, idx) => {
      const reg = findRegionByPhone(raw);
      return {
        id: `restored_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
        phone: formatPhoneNumber(raw),
        rawPhone: raw,
        city: reg?.city || '',
        regionName: reg?.regionName || '',
        uniqueLink: '',
        timezoneUtc: reg?.utcOffset ?? 3,
        timezoneMsk: reg?.mskOffset ?? 0,
        status: 'callback' as CallStatus,
        attemptCount: 1,
        maxAttempts: 3,
        targetCallbackTime: now + 30 * 60 * 1000,
        timerDurationMinutes: 30,
        lastCallTime: null,
        scheduledByAgreedTime: false,
        notes: 'Восстановлен из списка',
        createdAt: now - idx * 1000,
        updatedAt: now,
      };
    });

    setLeads((prev) => [...newLeads, ...prev]);
    return newLeads.length;
  };

  // Добавление сохранения через быстрое поле ввода номера и кнопку MNP
  const handleAddMnpSaved = (rawInput: string): { success: boolean; message?: string } => {
    const strict = cleanToStrictMtsPhone(rawInput);
    if (!strict) {
      return { success: false, message: 'Неверный формат номера (нужно 10-11 цифр)' };
    }

    const now = Date.now();
    const nowD = new Date();
    const timeStr = `${String(nowD.getHours()).padStart(2, '0')}:${String(nowD.getMinutes()).padStart(2, '0')}`;

    // Проверяем: был ли номер в АВТО или ПО просьбе (в очереди активных клиентов)
    const existingActiveLead = leads.find(
      (l) =>
        (l.rawPhone === strict || cleanToStrictMtsPhone(l.phone) === strict) &&
        l.status !== 'saved' &&
        l.status !== 'refused' &&
        l.status !== 'unreachable'
    );

    if (existingActiveLead) {
      // Номер БЫЛ в очереди: переводим в статус saved (звонок уже был учтен при создании)
      handleUpdateStatus(existingActiveLead.id, 'saved');
    } else {
      // Номера НЕ БЫЛО в очереди: прямой звонок клиенту, который сразу согласился на сохранение!
      // Идет +1 в Звонки и +1 в Сохранения:
      recalculateStats({
        totalCallsCount: stats.totalCallsCount + 1,
        savedCount: stats.savedCount + 1,
      });
      setIsCallsPulsing(true);
      setIsSavedPulsing(true);
      setTimeout(() => {
        setIsCallsPulsing(false);
        setIsSavedPulsing(false);
      }, 450);

      // Заносим запись в таблицу сохраненных клиентов с типом MNP
      const newRecord: SavedClientRecord = {
        id: `saved_${now}_${Math.random().toString(36).substring(2, 7)}`,
        phone: strict,
        time: timeStr,
        type: 'MNP',
        timestamp: now,
      };

      setSavedClients((prev) => [newRecord, ...prev]);
    }

    return { success: true };
  };

  // Удаление записи из таблицы сохраненных (количество сохранений в KPI НЕ уменьшается!)
  const handleDeleteSavedRecord = (id: string) => {
    setSavedClients((prev) => prev.filter((r) => r.id !== id));
  };

  // Активные клиенты в очереди (все, кто ожидает звонка)
  const activeLeads = leads.filter(
    (l) => l.status !== 'saved' && l.status !== 'refused' && l.status !== 'unreachable'
  );
  const activeTimersCount = activeLeads.length;
  const isAutoLeadFn = (l: ClientLead) => {
    if (l.isAnsweringMachineForced || l.status === 'answering_machine') return true;
    const hasNotes = Boolean(l.notes && l.notes.trim().length > 0);
    if (!hasNotes) return true;
    return !l.scheduledByAgreedTime && l.status !== 'callback';
  };
  const autoCallbacksCount = activeLeads.filter(isAutoLeadFn).length;
  const clientAgreedCallbacksCount = activeLeads.filter((l) => !isAutoLeadFn(l)).length;

  // Истекшие таймеры (кому подошло время звонить прямо сейчас)
  const expiredLeads = activeLeads.filter((lead) => {
    if (lead.targetCallbackTime) {
      return clock.getRemainingTime(lead.targetCallbackTime).isExpired;
    }
    return false;
  });


  // Отслеживание активности оператора на странице (движение мыши, клики, ввод текста, скролл)
  useEffect(() => {
    const recordUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    window.addEventListener('mousemove', recordUserActivity, { passive: true });
    window.addEventListener('mousedown', recordUserActivity, { passive: true });
    window.addEventListener('keydown', recordUserActivity, { passive: true });
    window.addEventListener('input', recordUserActivity, { passive: true });
    window.addEventListener('wheel', recordUserActivity, { passive: true });
    window.addEventListener('touchstart', recordUserActivity, { passive: true });
    window.addEventListener('scroll', recordUserActivity, { passive: true });

    return () => {
      window.removeEventListener('mousemove', recordUserActivity);
      window.removeEventListener('mousedown', recordUserActivity);
      window.removeEventListener('keydown', recordUserActivity);
      window.removeEventListener('input', recordUserActivity);
      window.removeEventListener('wheel', recordUserActivity);
      window.removeEventListener('touchstart', recordUserActivity);
      window.removeEventListener('scroll', recordUserActivity);
    };
  }, []);

  // Переключение режима ожидания вручную
  const handleToggleStandby = () => {
    lastActivityRef.current = Date.now();
    setIsStandbyMode((prev) => !prev);
  };

  const handleExpandWorkspace = () => {
    lastActivityRef.current = Date.now();
    setIsStandbyMode(false);
  };

  // Автосворачивание рабочего места в центр экрана при неактивности оператора
  useEffect(() => {
    const delayMinutes = settings.collapseDelayMinutes;
    // Если 0 или не задано — автосворачивание полностью выключено
    if (!delayMinutes || delayMinutes <= 0) return;

    const interval = setInterval(() => {
      // Если уже свернуто, открыто модальное окно настроек или есть горящие звонки — не сворачиваем
      if (isStandbyMode || isSettingsOpen || isInstallModalOpen || expiredLeads.length > 0) {
        return;
      }

      // Если оператор прямо сейчас печатает в поле ввода (телефон, город, ссылка, заметки) — не сворачиваем
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
        lastActivityRef.current = Date.now();
        return;
      }

      const elapsed = Date.now() - lastActivityRef.current;
      const thresholdMs = delayMinutes * 60 * 1000;
      if (elapsed >= thresholdMs) {
        setIsStandbyMode(true);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [settings.collapseDelayMinutes, isStandbyMode, isSettingsOpen, isInstallModalOpen, expiredLeads.length]);

  // КОГДА ПРИШЛО ВРЕМЯ ПЕРЕЗВОНА — мгновенно автоматически разворачиваем всё рабочее место!
  useEffect(() => {
    if (expiredLeads.length > 0 && isStandbyMode) {
      lastActivityRef.current = Date.now();
      setIsStandbyMode(false);
    }
  }, [expiredLeads.length, isStandbyMode]);

  return (
    <div className="min-h-screen bg-[#F4F5F7] text-[#1D2023] flex flex-col font-mts-text">
      {/* Шапка МТС */}
      <Header
        localTimeStr={clock.localTimeStr}
        moscowTimeStr={clock.moscowTimeStr}
        currentDateStr={clock.currentDateStr}
        settings={settings}
        onToggleSound={() =>
          setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
        }
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenReport={() => setIsSettingsOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        /* onOpenChangelog временно отключен в данном цикле обновлений */
        onOpenGuide={() => setIsOnboardingOpen(true)}
        isInstalled={isInstalled}
        activeTimersCount={activeTimersCount}
        isStandbyMode={isStandbyMode}
        onToggleStandby={handleToggleStandby}
      />

      {/* Основная рабочая область: в режиме ожидания плавно центрируется чуть ниже центра */}
      <main className={`flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-500 ease-in-out flex flex-col ${
        isStandbyMode ? 'justify-center my-auto py-12 sm:py-16' : 'justify-start py-6'
      }`}>
        {/* 4 ключевых блока KPI (в режиме ожидания комфортно расположены чуть ниже центра экрана) */}
        <div
          className={`w-full transition-all duration-500 ease-in-out ${
            isStandbyMode ? 'pt-12 sm:pt-16 max-w-5xl mx-auto' : 'pt-0'
          }`}
        >
          <KpiDashboard
            stats={stats}
            activeTimersCount={activeTimersCount}
            dueTimersCount={expiredLeads.length}
            autoCallbacksCount={autoCallbacksCount}
            clientAgreedCallbacksCount={clientAgreedCallbacksCount}
            onAdjustCalls={handleAdjustCalls}
            onAdjustSaved={handleAdjustSaved}
            onAdjustSavedWithoutTpChange={handleAdjustSavedWithoutTpChange}
            onAdjustSavedWithEi={handleAdjustSavedWithEi}
            onFocusDueQueue={handleFocusDueQueue}
            kpiFontWeight={settings.kpiFontWeight || 'normal'}
            isCallsPulsing={isCallsPulsing}
            isSavedPulsing={isSavedPulsing}
          />

          {/* В свернутом режиме (ожидание): поле ввода номера и таблица номеров ровно между KPI и кнопкой развернуть */}
          {isStandbyMode && settings.enableNumbersAccounting !== false && (
            <div className="mt-6 max-w-2xl mx-auto w-full animate-in fade-in duration-300">
              <SavedClientsTable
                savedClients={savedClients}
                onAddMnpSaved={handleAddMnpSaved}
                onDeleteRecord={handleDeleteSavedRecord}
                isExpanded={isSavedTableExpanded}
                onToggleExpanded={() => setIsSavedTableExpanded((prev) => !prev)}
                isStandbyMode={true}
              />
            </div>
          )}

          {/* Плашка режима ожидания по центру экрана (плавная анимация без рывков) */}
          <div
            className={`transition-all duration-500 ease-in-out overflow-hidden flex flex-col items-center justify-center text-center ${
              isStandbyMode
                ? 'max-h-48 opacity-100 translate-y-0 mt-6 pointer-events-auto'
                : 'max-h-0 opacity-0 -translate-y-4 pointer-events-none mt-0'
            }`}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white border border-[#E4E7EC] shadow-xs text-xs font-semibold text-[#626C77]">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Режим ожидания • Карточки свернуты • При перезвоне экран откроется автоматически</span>
            </div>
            <button
              type="button"
              onClick={handleExpandWorkspace}
              className="mt-3.5 inline-flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-[#E30613] hover:bg-[#C40510] active:scale-[0.98] text-white text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all cursor-pointer"
              title="Развернуть рабочее место"
            >
              <Maximize2 className="w-4 h-4" />
              <span>Развернуть</span>
            </button>
          </div>
        </div>

        {/* Рабочая область: абсолютно плавное сворачивание/разворачивание через grid-template-rows без рывков */}
        <div
          className={`grid transition-[grid-template-rows,opacity,margin] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${
            isStandbyMode
              ? 'grid-rows-[0fr] opacity-0 pointer-events-none mt-0'
              : 'grid-rows-[1fr] opacity-100 pointer-events-auto mt-5'
          }`}
        >
          <div className={`${isStandbyMode ? 'overflow-hidden' : 'overflow-visible'} space-y-5`}>
            {/* Блок таблицы номеров и исходящих вызовов */}
            {!isStandbyMode && (
              settings.enableNumbersAccounting !== false ? (
                <div className="space-y-5">
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-5 items-start">
                    {/* Таблица номеров: ширина как 2 блока KPI (col-span-2) */}
                    <div className="lg:col-span-2">
                      <SavedClientsTable
                        savedClients={savedClients}
                        onAddMnpSaved={handleAddMnpSaved}
                        onDeleteRecord={handleDeleteSavedRecord}
                        isExpanded={isSavedTableExpanded}
                        onToggleExpanded={() => setIsSavedTableExpanded((prev) => !prev)}
                        isStandbyMode={false}
                      />
                    </div>

                    {/* Правая часть (под двумя другими блоками KPI): плавно появляется/сворачивается при развертывании таблицы */}
                    <div
                      className={`lg:col-span-2 grid transition-[grid-template-rows,opacity] duration-250 ease-[cubic-bezier(0.2,0,0,1)] ${
                        isSavedTableExpanded
                          ? 'grid-rows-[1fr] opacity-100 pointer-events-auto'
                          : 'grid-rows-[0fr] opacity-0 pointer-events-none'
                      }`}
                    >
                      <div className="overflow-hidden space-y-4">
                        {expiredLeads.length > 0 ? (
                          <UrgentAlertBanner
                            expiredLeads={expiredLeads}
                            onCopyPhone={handleCopyPhone}
                            copiedId={copiedId}
                            onSelectLead={handleSelectLeadFromBanner}
                          />
                        ) : (
                          <div className="bg-white border border-[#E2E8F0] rounded-3xl p-4 sm:p-5 shadow-mts-card flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                                <Check className="w-5 h-5" />
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-[#1D2023] font-mts-extended">
                                  Все вызовы в графике
                                </h4>
                                <p className="text-xs text-[#626C77] mt-0.5">
                                  Срочных исходящих звонков прямо сейчас нет
                                </p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={handleFocusDueQueue}
                              className="px-3 py-1.5 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-xs font-bold text-[#1D2023] transition-colors cursor-pointer"
                            >
                              К очереди
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Когда таблица свернута И есть срочные вызовы — показываем их на всю ширину под строкой */}
                  <div
                    className={`grid transition-[grid-template-rows,opacity] duration-250 ease-[cubic-bezier(0.2,0,0,1)] ${
                      !isSavedTableExpanded && expiredLeads.length > 0
                        ? 'grid-rows-[1fr] opacity-100 pointer-events-auto'
                        : 'grid-rows-[0fr] opacity-0 pointer-events-none'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <UrgentAlertBanner
                        expiredLeads={expiredLeads}
                        onCopyPhone={handleCopyPhone}
                        copiedId={copiedId}
                        onSelectLead={handleSelectLeadFromBanner}
                      />
                    </div>
                  </div>
                </div>
              ) : (
                /* Когда учёт номеров выключен — обычный баннер срочных вызовов */
                <UrgentAlertBanner
                  expiredLeads={expiredLeads}
                  onCopyPhone={handleCopyPhone}
                  copiedId={copiedId}
                  onSelectLead={handleSelectLeadFromBanner}
                />
              )
            )}

            {/* Карточка Клиента */}
            <AddClientForm
              onAddClient={handleAddClient}
              defaultAttempt1Minutes={settings.attempt1Minutes || 30}
            />

            {/* Очередь звонков (поиск, фильтры и все карточки абонентов) */}
            <div ref={queueSectionRef}>
              <ClientQueue
                leads={leads}
                onUpdateStatus={handleUpdateStatus}
                onDeleteLead={handleDeleteLead}
                onUpdateNotes={handleUpdateNotes}
                onUpdateLead={handleUpdateLead}
                getRemainingTime={clock.getRemainingTime}
                highlightedLeadId={highlightedLeadId}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Модальное окно настроек и отчета смены */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        stats={stats}
        leads={leads}
        onResetShift={handleResetShift}
        onRestoreBackup={handleRestoreBackup}
        onImportLeadsText={handleImportLeadsText}
        onSelectUpdateFile={handleFileSelectedForUpdate}
        onOpenGuide={() => setIsOnboardingOpen(true)}
      />

      {/* Модальное окно установки на рабочий стол ПК */}
      <DesktopInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        onInstall={install}
      />

      {/* Модальное окно журнала обновлений */}
      <ChangelogModal
        isOpen={isChangelogOpen}
        onClose={() => setIsChangelogOpen(false)}
      />

      {/* Интерактивное руководство оператора (Гайд при первом запуске) */}
      <OnboardingGuideModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
      />

      {/* Полноэкранный оверлей для перетаскивания файла обновления (Drag & Drop) */}
      <UpdateDropOverlay onFileDrop={handleFileSelectedForUpdate} />

      {/* Модальное окно установки обновления из файла */}
      <UpdateInstallModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updatePackage={pendingUpdatePackage}
        errorMessage={updateError}
      />

      {/* Рабочее окно Книги во всю рабочую область (кроме верхней панели управления) */}
      <BookWorkspaceModal
        isOpen={isBookWindowOpen}
        onClose={() => setIsBookWindowOpen(false)}
      />

      {/* Полукруглая кнопка на краю рабочей области с круглыми кнопками (+) */}
      <EdgeQuickDock onOpenBook={() => setIsBookWindowOpen(true)} />

      {/* Всплывающие Push-уведомления поверх экрана */}
      <NotificationToastContainer
        position={settings.pushPosition}
        enabled={settings.enablePushNotifications !== false}
      />
    </div>
  );
}
