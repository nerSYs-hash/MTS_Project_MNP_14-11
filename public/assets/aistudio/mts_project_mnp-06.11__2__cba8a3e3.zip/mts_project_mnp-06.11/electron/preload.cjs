const { contextBridge, ipcRenderer } = require('electron');

// Безопасный IPC мост между десктопной средой и веб-интерфейсом
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,
  showNotification: (title, body) => {
    try {
      ipcRenderer.send('show-notification', { title, body });
    } catch (e) {
      console.warn('IPC showNotification error:', e);
    }
  },
});
