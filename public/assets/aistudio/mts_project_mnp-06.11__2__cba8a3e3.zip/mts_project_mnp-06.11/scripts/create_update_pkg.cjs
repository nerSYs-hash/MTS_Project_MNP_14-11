/**
 * Скрипт сборки единого файла обновления .mtsupdate
 * Запуск: node scripts/create_update_pkg.cjs [версия]
 *
 * ПРАВИЛА ВЕРСИОНИРОВАНИЯ (SemVer X.Y.Z):
 * - 3-я цифра (Z): Мелкие обновления/фиксы (например, 2.7.1)
 * - 2-я цифра (Y): Крупные обновления/новые разделы (например, 2.8.0)
 * - 1-я цифра (X): Глобальные обновления/редизайн (например, 3.0.0)
 */
const fs = require('fs');
const path = require('path');

const version = process.argv[2] || '2.7.5';
const releaseDate = '2026-11-05';
const releaseDateFormatted = '5 ноября 2026';

const updatePackage = {
  format: 'mts-urm-update-package',
  formatVersion: 1,
  appId: 'mts-mnp-urm',
  version: version,
  releaseDate: releaseDate,
  releaseDateFormatted: releaseDateFormatted,
  title: `Пакет обновлений v${version} — Точная классификация «Авто» и «По просьбе»`,
  description:
    `Свежее обновление (v${version}): внедрена строгая логика автоматического распределения звонков по разделам «По просьбе» и «Авто». Заявки с заметкой и временем/таймером автоматически направляются в «По просьбе», а заявки без заметки (с таймером или без) — в «Авто». Устранена зависимость от ручного тумблера.`,
  changes: [
    {
      type: 'feature',
      title: 'Умная классификация «Авто» и «По просьбе»',
      desc: 'Автоматическое разделение: телефон + ссылка + город + заметка + таймер/время переходят в «По просьбе». Заявки без заметки направляются в «Авто».',
    },
    {
      type: 'update',
      title: 'Синхронизация тумблера «Автоответчик»',
      desc: 'Тумблер автоматически отображает текущий режим заявки при вводе заметки и времени с наглядным бейджем и возможностью ручного переключения.',
    },
    {
      type: 'update',
      title: 'Чистый интерфейс шапки приложения',
      desc: 'Убран значок и бейдж версии из левого верхнего угла рядом с логотипом MNP для строгого и лаконичного корпоративного вида.',
    },
    {
      type: 'system',
      title: 'Полная накопительность обновления (Кумулятивность)',
      desc: `Пакет v${version} объединяет все наработки версий 2.7.0, 2.7.1, 2.7.2, 2.7.3, 2.7.4 и ${version}. При установке поверх любой предыдущей версии сохраняются все настройки, таймеры и сохраненные номера оператора.`,
    },
  ],
  clientPatch: {
    enableNumbersAccountingDefault: true,
    targetVersion: version,
    changelogCount: 52,
  },
  checksum: `sha256-mts-urm-${version}-verified`,
};

// Читаем скомпилированный код интерфейса из dist/assets для горячего обновления (Hot-Code Push)
const distAssetsDir = path.join(__dirname, '..', 'dist', 'assets');
if (fs.existsSync(distAssetsDir)) {
  const assetFiles = fs.readdirSync(distAssetsDir);
  const jsFile = assetFiles.find((f) => f.startsWith('index-') && f.endsWith('.js'));
  const cssFile = assetFiles.find((f) => f.startsWith('index-') && f.endsWith('.css'));

  if (jsFile || cssFile) {
    updatePackage.bundle = {};
    if (jsFile) {
      updatePackage.bundle.js = fs.readFileSync(path.join(distAssetsDir, jsFile), 'utf-8');
      console.log(`📦 Встроен JS-бандл интерфейса: ${jsFile} (${(updatePackage.bundle.js.length / 1024).toFixed(1)} КБ)`);
    }
    if (cssFile) {
      updatePackage.bundle.css = fs.readFileSync(path.join(distAssetsDir, cssFile), 'utf-8');
      console.log(`🎨 Встроен CSS-бандл стилей: ${cssFile} (${(updatePackage.bundle.css.length / 1024).toFixed(1)} КБ)`);
    }
  }
}

const jsonContent = JSON.stringify(updatePackage, null, 2);

// Сохраняем в папку public
const publicDir = path.join(__dirname, '..', 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
const publicPath = path.join(publicDir, `update_v${version}.mtsupdate`);
fs.writeFileSync(publicPath, jsonContent, 'utf-8');

// Также генерируем бинарный архив public/update.asar из папки dist (если dist собран)
const distDir = path.join(__dirname, '..', 'dist');
if (fs.existsSync(distDir)) {
  try {
    // Удаляем из dist старые копии update.asar и .mtsupdate, чтобы они не упаковывались рекурсивно внутрь нового update.asar
    for (const f of fs.readdirSync(distDir)) {
      if (f.endsWith('.asar') || f.endsWith('.mtsupdate')) {
        fs.unlinkSync(path.join(distDir, f));
      }
    }

    const asar = require('@electron/asar');
    const asarDest = path.join(publicDir, 'update.asar');
    asar
      .createPackage(distDir, asarDest)
      .then(() => {
        const sizeMb = (fs.statSync(asarDest).size / (1024 * 1024)).toFixed(2);
        console.log(`📦 Сформирован бинарный архив автообновления: ${asarDest} (${sizeMb} МБ)`);
      })
      .catch((err) => {
        console.warn('Не удалось упаковать update.asar:', err);
      });
  } catch (err) {
    console.warn('Модуль @electron/asar не найден, пропуск сборки update.asar:', err);
  }
}

console.log(`✅ Пакет обновления успешно собран в папке public: ${publicPath}`);

