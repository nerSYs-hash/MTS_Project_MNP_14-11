/**
 * Рабочее место оператора группы сохранения клиентов МТС (MNP)
 * Полная интеграция: таймеры перезвона, часы ПК, автоопределение поясов РФ и расчет конверсии
 */
import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Maximize2 } from 'lucide-react';
import { Header } from './components/Header';
import { KpiDashboard } from './components/KpiDashboard';
import { AddClientForm } from './components/AddClientForm';
import { UrgentAlertBanner } from './components/UrgentAlertBanner';
import { ClientQueue } from './components/ClientQueue';
import { SettingsModal } from './components/SettingsModal';
import { ChangelogModal } from './components/ChangelogModal';
import { DesktopInstallModal } from './components/DesktopInstallModal';
import { useSystemClock } from './hooks/useSystemClock';
import { usePWAInstall } from './hooks/usePWAInstall';
import { ClientLead, CallStatus, ShiftStats, TimerSettings } from './types';
import {
  loadLeadsFromStorage,
  saveLeadsToStorage,
  loadBackupLeadsFromStorage,
  loadStatsFromStorage,
  saveStatsToStorage,
  loadSettingsFromStorage,
  saveSettingsToStorage,
  DEFAULT_SETTINGS,
  INITIAL_STATS,
} from './utils/storage';
import {
  cleanPhoneNumber,
  formatPhoneNumber,
  findRegionByPhone,
} from './data/regionsData';
import { playChimeSound, sendDesktopNotification } from './utils/audioAlert';

export default function App() {
  const clock = useSystemClock();

  // Состояние клиентов, статистики смены и настроек (с автонормализацией активных таймеров)
  const [leads, setLeads] = useState<ClientLead[]>(() => {
    const loaded = loadLeadsFromStorage();
    const now = Date.now();
    return loaded.map((lead) => {
      const isActive =
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable';
      if (isActive && (!lead.targetCallbackTime || lead.targetCallbackTime <= 0)) {
        const duration = lead.timerDurationMinutes || 30;
        return {
          ...lead,
          status: lead.scheduledByAgreedTime ? ('callback' as CallStatus) : ('answering_machine' as CallStatus),
          targetCallbackTime: now + duration * 60 * 1000,
          timerDurationMinutes: duration,
          scheduledByAgreedTime: Boolean(lead.scheduledByAgreedTime),
        };
      }
      return lead;
    });
  });
  const [stats, setStats] = useState<ShiftStats>(() => loadStatsFromStorage());
  const [settings, setSettings] = useState<TimerSettings>(() => loadSettingsFromStorage());

  // Состояние модалок и уведомлений
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isChangelogOpen, setIsChangelogOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Режим ожидания АРМ (сворачивает форму и очередь, перемещая 4 KPI блока в центр экрана)
  const [isStandbyMode, setIsStandbyMode] = useState(false);
  const lastActivityRef = useRef<number>(Date.now());
  const [isFormCollapsed, setIsFormCollapsed] = useState(false);
  const [highlightedLeadId, setHighlightedLeadId] = useState<string | null>(null);

  // Десктопная установка PWA
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Множество id лидов, о которых уже проигран звуковой сигнал при истечении таймера
  const notifiedLeadIdsRef = useRef<Set<string>>(new Set());
  const queueSectionRef = useRef<HTMLDivElement>(null);

  // Автосохранение в localStorage при изменениях
  useEffect(() => {
    saveLeadsToStorage(leads);
  }, [leads]);

  useEffect(() => {
    saveStatsToStorage(stats);
  }, [stats]);

  useEffect(() => {
    saveSettingsToStorage(settings);
  }, [settings]);

  // Проверка истекших таймеров каждую секунду при изменении системных часов
  useEffect(() => {
    const expiredList = leads.filter((lead) => {
      const isActive =
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable';
      if (isActive && lead.targetCallbackTime) {
        return lead.targetCallbackTime <= clock.nowTimestamp;
      }
      return false;
    });

    for (const lead of expiredList) {
      if (!notifiedLeadIdsRef.current.has(lead.id)) {
        notifiedLeadIdsRef.current.add(lead.id);

        if (settings.soundEnabled) {
          playChimeSound(settings.volume);
        }

        sendDesktopNotification(
          '🔔 Пора перезвонить клиенту!',
          `${lead.phone} (${lead.city})`
        );
      }
    }
  }, [clock.nowTimestamp, leads, settings.soundEnabled, settings.volume]);

  // Вычисление конверсии в процентах
  const recalculateStats = (partial: Partial<ShiftStats>) => {
    setStats((prev) => {
      const updated = { ...prev, ...partial };
      const calls = Math.max(0, updated.totalCallsCount);
      const saved = Math.max(0, updated.savedCount);
      const rate = calls > 0 ? Number(((saved / calls) * 100).toFixed(1)) : 0;
      return {
        ...updated,
        totalCallsCount: calls,
        savedCount: saved,
        conversionRate: rate,
      };
    });
  };

  // Быстрые кнопки +1 и -1 для звонков (с возможностью отмены ошибки)
  const handleAdjustCalls = (delta: number) => {
    recalculateStats({
      totalCallsCount: Math.max(0, stats.totalCallsCount + delta),
    });
  };

  // Быстрые кнопки +1 и -1 для сохранений
  const handleAdjustSaved = (delta: number) => {
    recalculateStats({
      savedCount: Math.max(0, stats.savedCount + delta),
    });
  };

  // Добавление нового клиента через «Записать»
  const handleAddClient = (
    newLeadData: Omit<ClientLead, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const id = `lead_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = Date.now();

    // Запись контакта: добавляем +1 к общему числу исходящих вызовов
    recalculateStats({
      totalCallsCount: stats.totalCallsCount + 1,
    });

    const isAgreed = Boolean(newLeadData.scheduledByAgreedTime);
    const defaultTimer = settings.attempt1Minutes || 30;
    const duration = newLeadData.timerDurationMinutes ?? defaultTimer;
    const targetTime = newLeadData.targetCallbackTime ?? (now + duration * 60 * 1000);

    const createdLead: ClientLead = {
      ...newLeadData,
      id,
      status: newLeadData.status || (isAgreed ? 'callback' : 'answering_machine'),
      attemptCount: newLeadData.attemptCount || 1,
      maxAttempts: newLeadData.maxAttempts || 3,
      targetCallbackTime: targetTime,
      timerDurationMinutes: duration,
      lastCallTime: newLeadData.lastCallTime || now,
      scheduledByAgreedTime: isAgreed,
      createdAt: now,
      updatedAt: now,
    };

    // Всегда поднимаем новую заполненную заявку первой в списке!
    setLeads((prev) => [createdLead, ...prev]);
  };

  // Обновление статуса звонка существующего клиента
  const handleUpdateStatus = (
    id: string,
    newStatus: CallStatus,
    options?: {
      customTimerMinutes?: number;
      notes?: string;
      isClientAgreed?: boolean;
      attemptCount?: number;
    }
  ) => {
    const now = Date.now();

    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id !== id) return lead;

        notifiedLeadIdsRef.current.delete(lead.id);

        let nextTargetTime: number | null = null;
        let nextDuration: number | null = null;
        let nextAgreed = lead.scheduledByAgreedTime;
        let nextAttempt = lead.attemptCount;

        if (newStatus === 'callback') {
          nextDuration = options?.customTimerMinutes || (lead.timerDurationMinutes ?? 30);
          nextTargetTime = now + nextDuration * 60 * 1000;
          nextAgreed = options?.isClientAgreed !== undefined ? options.isClientAgreed : true;
        } else if (newStatus === 'answering_machine') {
          // Следующая попытка дозвона
          nextAttempt = Math.min(lead.maxAttempts, lead.attemptCount + 1);
          const attemptMinutes =
            nextAttempt === 2
              ? settings.attempt2Minutes || 45
              : nextAttempt >= 3
              ? settings.attempt3Minutes || 60
              : settings.attempt1Minutes || 30;
          nextDuration = options?.customTimerMinutes || attemptMinutes;
          nextTargetTime = now + nextDuration * 60 * 1000;
          nextAgreed = false;
        } else if (newStatus === 'saved') {
          nextTargetTime = null;
          nextDuration = null;
          if (lead.status !== 'saved') {
            recalculateStats({ savedCount: stats.savedCount + 1 });
          }
        } else if (newStatus === 'refused') {
          nextTargetTime = null;
          nextDuration = null;
          if (lead.status !== 'refused') {
            recalculateStats({ refusedCount: stats.refusedCount + 1 });
          }
        } else if (newStatus === 'unreachable') {
          nextTargetTime = null;
          nextDuration = null;
          recalculateStats({ unreachableCount: (stats.unreachableCount || 0) + 1 });
        }

        return {
          ...lead,
          status: newStatus,
          attemptCount: options?.attemptCount !== undefined ? options.attemptCount : nextAttempt,
          targetCallbackTime: nextTargetTime,
          timerDurationMinutes: nextDuration,
          scheduledByAgreedTime: nextAgreed,
          lastCallTime: now,
          notes: options?.notes !== undefined ? options.notes : lead.notes,
          updatedAt: now,
        };
      })
    );
  };

  // Удаление клиента
  const handleDeleteLead = (id: string) => {
    notifiedLeadIdsRef.current.delete(id);
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  // Обновление заметок
  const handleUpdateNotes = (id: string, notes: string) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, notes, updatedAt: Date.now() } : l))
    );
  };

  // Редактирование данных карточки (номер телефона, ссылка CRM, город)
  const handleUpdateLead = (id: string, updates: Partial<ClientLead>) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates, updatedAt: Date.now() } : l))
    );
  };

  // Быстрое копирование номера
  const handleCopyPhone = (phone: string) => {
    navigator.clipboard.writeText(phone);
    setCopiedId(phone);
    setTimeout(() => setCopiedId(null), 1800);
  };

  // Переход к очереди перезвонов при клике на KPI карточку
  const handleFocusDueQueue = () => {
    setIsStandbyMode(false);
    setTimeout(() => {
      queueSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 60);
  };

  // Скрин 10 & 11: Клик по карточке в срочном баннере мгновенно переходит к ней в очереди и подсвечивает
  const handleSelectLeadFromBanner = (id: string) => {
    setIsStandbyMode(false);
    setHighlightedLeadId(id);
    const el = document.getElementById(`card-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      queueSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
    setTimeout(() => {
      setHighlightedLeadId((curr) => (curr === id ? null : curr));
    }, 3500);
  };

  // Сброс смены
  const handleResetShift = () => {
    setStats({
      ...INITIAL_STATS,
      shiftStartTime: Date.now(),
    });
    notifiedLeadIdsRef.current.clear();
  };

  // Изменение счетчика «Без смены ТП»
  const handleAdjustSavedWithoutTpChange = (delta: number) => {
    const currentSub = stats.savedWithoutTpChange || 0;
    const nextSub = Math.max(0, currentSub + delta);
    const diff = nextSub - currentSub;
    const shouldInclude = settings.includeWithoutTpInSaved !== false;
    recalculateStats({
      savedWithoutTpChange: nextSub,
      savedCount: shouldInclude ? Math.max(0, stats.savedCount + diff) : stats.savedCount,
    });
  };

  // Изменение счетчика «ЕИ» (Единый Инструмент)
  const handleAdjustSavedWithEi = (delta: number) => {
    const currentSub = stats.savedWithEi || 0;
    const nextSub = Math.max(0, currentSub + delta);
    const diff = nextSub - currentSub;
    const shouldInclude = settings.includeEiInSaved !== false;
    recalculateStats({
      savedWithEi: nextSub,
      savedCount: shouldInclude ? Math.max(0, stats.savedCount + diff) : stats.savedCount,
    });
  };

  // Восстановление заявок из автоматической резервной копии
  const handleRestoreBackup = (): boolean => {
    const backup = loadBackupLeadsFromStorage();
    if (backup && backup.length > 0) {
      setLeads(backup);
      return true;
    }
    return false;
  };

  // Быстрый текстовый импорт номеров для восстановления списка (из Excel, CRM, Блокнота)
  const handleImportLeadsText = (text: string): number => {
    if (!text || !text.trim()) return 0;

    // Извлечение последовательностей цифр или номеров
    const rawMatches = text.match(/(?:(?:\+?7|8)[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{2}[-.\s]?[0-9]{2}/g) || [];
    const extractedNumbers: string[] = [];

    // Также пробуем построчно
    const lines = text.split(/[\r\n;,]+/);
    for (const line of lines) {
      const cleaned = cleanPhoneNumber(line);
      if (cleaned.length >= 10) {
        const normalized = cleaned.length === 10 ? '7' + cleaned : (cleaned.startsWith('8') ? '7' + cleaned.slice(1) : cleaned);
        if (normalized.length === 11 && !extractedNumbers.includes(normalized)) {
          extractedNumbers.push(normalized);
        }
      }
    }

    for (const m of rawMatches) {
      const cleaned = cleanPhoneNumber(m);
      const normalized = cleaned.length === 10 ? '7' + cleaned : (cleaned.startsWith('8') ? '7' + cleaned.slice(1) : cleaned);
      if (normalized.length === 11 && !extractedNumbers.includes(normalized)) {
        extractedNumbers.push(normalized);
      }
    }

    if (extractedNumbers.length === 0) return 0;

    const now = Date.now();
    const newLeads: ClientLead[] = extractedNumbers.map((raw, idx) => {
      const reg = findRegionByPhone(raw);
      return {
        id: `restored_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
        phone: formatPhoneNumber(raw),
        rawPhone: raw,
        city: reg?.city || '',
        regionName: reg?.regionName || '',
        uniqueLink: '',
        timezoneUtc: reg?.utcOffset ?? 3,
        timezoneMsk: reg?.mskOffset ?? 0,
        status: 'callback' as CallStatus,
        attemptCount: 1,
        maxAttempts: 3,
        targetCallbackTime: now + 30 * 60 * 1000,
        timerDurationMinutes: 30,
        lastCallTime: null,
        scheduledByAgreedTime: false,
        notes: 'Восстановлен из списка',
        createdAt: now - idx * 1000,
        updatedAt: now,
      };
    });

    setLeads((prev) => [...newLeads, ...prev]);
    return newLeads.length;
  };

  // Активные клиенты в очереди (все, кто ожидает звонка)
  const activeLeads = leads.filter(
    (l) => l.status !== 'saved' && l.status !== 'refused' && l.status !== 'unreachable'
  );
  const activeTimersCount = activeLeads.length;
  const autoCallbacksCount = activeLeads.filter((l) => !l.scheduledByAgreedTime).length;
  const clientAgreedCallbacksCount = activeLeads.filter((l) => Boolean(l.scheduledByAgreedTime)).length;

  // Истекшие таймеры (кому подошло время звонить прямо сейчас)
  const expiredLeads = activeLeads.filter((lead) => {
    if (lead.targetCallbackTime) {
      return clock.getRemainingTime(lead.targetCallbackTime).isExpired;
    }
    return false;
  });


  // Отслеживание активности оператора на странице (движение мыши, клики, ввод текста, скролл)
  useEffect(() => {
    const recordUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    window.addEventListener('mousemove', recordUserActivity, { passive: true });
    window.addEventListener('mousedown', recordUserActivity, { passive: true });
    window.addEventListener('keydown', recordUserActivity, { passive: true });
    window.addEventListener('input', recordUserActivity, { passive: true });
    window.addEventListener('wheel', recordUserActivity, { passive: true });
    window.addEventListener('touchstart', recordUserActivity, { passive: true });
    window.addEventListener('scroll', recordUserActivity, { passive: true });

    return () => {
      window.removeEventListener('mousemove', recordUserActivity);
      window.removeEventListener('mousedown', recordUserActivity);
      window.removeEventListener('keydown', recordUserActivity);
      window.removeEventListener('input', recordUserActivity);
      window.removeEventListener('wheel', recordUserActivity);
      window.removeEventListener('touchstart', recordUserActivity);
      window.removeEventListener('scroll', recordUserActivity);
    };
  }, []);

  // Переключение режима ожидания вручную
  const handleToggleStandby = () => {
    lastActivityRef.current = Date.now();
    setIsStandbyMode((prev) => !prev);
  };

  const handleExpandWorkspace = () => {
    lastActivityRef.current = Date.now();
    setIsStandbyMode(false);
  };

  // Автосворачивание рабочего места в центр экрана при неактивности оператора
  useEffect(() => {
    const delayMinutes = settings.collapseDelayMinutes;
    // Если 0 или не задано — автосворачивание полностью выключено
    if (!delayMinutes || delayMinutes <= 0) return;

    const interval = setInterval(() => {
      // Если уже свернуто, открыто модальное окно настроек или есть горящие звонки — не сворачиваем
      if (isStandbyMode || isSettingsOpen || isInstallModalOpen || expiredLeads.length > 0) {
        return;
      }

      // Если оператор прямо сейчас печатает в поле ввода (телефон, город, ссылка, заметки) — не сворачиваем
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
        lastActivityRef.current = Date.now();
        return;
      }

      const elapsed = Date.now() - lastActivityRef.current;
      const thresholdMs = delayMinutes * 60 * 1000;
      if (elapsed >= thresholdMs) {
        setIsStandbyMode(true);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [settings.collapseDelayMinutes, isStandbyMode, isSettingsOpen, isInstallModalOpen, expiredLeads.length]);

  // КОГДА ПРИШЛО ВРЕМЯ ПЕРЕЗВОНА — мгновенно автоматически разворачиваем всё рабочее место!
  useEffect(() => {
    if (expiredLeads.length > 0 && isStandbyMode) {
      lastActivityRef.current = Date.now();
      setIsStandbyMode(false);
    }
  }, [expiredLeads.length, isStandbyMode]);

  return (
    <div className="min-h-screen bg-[#F4F5F7] text-[#1D2023] flex flex-col font-['Manrope']">
      {/* Шапка МТС */}
      <Header
        localTimeStr={clock.localTimeStr}
        moscowTimeStr={clock.moscowTimeStr}
        currentDateStr={clock.currentDateStr}
        settings={settings}
        onToggleSound={() =>
          setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
        }
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenReport={() => setIsSettingsOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isInstalled={isInstalled}
        activeTimersCount={activeTimersCount}
        isStandbyMode={isStandbyMode}
        onToggleStandby={handleToggleStandby}
      />

      {/* Основная рабочая область: в режиме ожидания плавно центрируется */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 transition-all duration-500 ease-in-out flex flex-col justify-start">
        {/* 4 ключевых блока KPI (в режиме ожидания плавно центрируются в поле зрения) */}
        <div
          className={`w-full transition-all duration-500 ease-in-out ${
            isStandbyMode ? 'pt-16 sm:pt-24 max-w-5xl mx-auto' : 'pt-0'
          }`}
        >
          <KpiDashboard
            stats={stats}
            activeTimersCount={activeTimersCount}
            dueTimersCount={expiredLeads.length}
            autoCallbacksCount={autoCallbacksCount}
            clientAgreedCallbacksCount={clientAgreedCallbacksCount}
            onAdjustCalls={handleAdjustCalls}
            onAdjustSaved={handleAdjustSaved}
            onAdjustSavedWithoutTpChange={handleAdjustSavedWithoutTpChange}
            onAdjustSavedWithEi={handleAdjustSavedWithEi}
            onFocusDueQueue={handleFocusDueQueue}
          />

          {/* Плашка режима ожидания по центру экрана (плавная анимация без рывков) */}
          <div
            className={`transition-all duration-500 ease-in-out overflow-hidden flex flex-col items-center justify-center text-center ${
              isStandbyMode
                ? 'max-h-48 opacity-100 translate-y-0 mt-8 pointer-events-auto'
                : 'max-h-0 opacity-0 -translate-y-4 pointer-events-none mt-0'
            }`}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white border border-[#E4E7EC] shadow-xs text-xs font-semibold text-[#626C77]">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Режим ожидания • Карточки свернуты • При перезвоне экран откроется автоматически</span>
            </div>
            <button
              type="button"
              onClick={handleExpandWorkspace}
              className="mt-3 group flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-[#E30613] hover:bg-[#C40510] text-white font-bold text-sm shadow-xs hover:shadow-md transition-all cursor-pointer active:scale-95"
              title="Развернуть всё рабочее место"
            >
              <Maximize2 className="w-4 h-4" />
              <span>Развернуть</span>
            </button>
          </div>
        </div>

        {/* Рабочая область: плавно сворачивается/разворачивается с сохранением DOM-элементов */}
        <div
          className={`w-full transition-all duration-500 ease-in-out overflow-hidden ${
            isStandbyMode
              ? 'max-h-0 opacity-0 pointer-events-none -translate-y-4'
              : 'max-h-[8000px] opacity-100 pointer-events-auto translate-y-0 space-y-5 mt-5'
          }`}
        >
          {/* Срочный баннер (клик по заявке мгновенно открывает и подсвечивает ее в очереди) */}
          <UrgentAlertBanner
            expiredLeads={expiredLeads}
            onCopyPhone={handleCopyPhone}
            copiedId={copiedId}
            onSelectLead={handleSelectLeadFromBanner}
          />

          {/* Карточка Клиента */}
          <AddClientForm
            onAddClient={handleAddClient}
            defaultAttempt1Minutes={settings.attempt1Minutes || 30}
          />

          {/* Очередь звонков (поиск, фильтры и все карточки абонентов) */}
          <div ref={queueSectionRef}>
            <ClientQueue
              leads={leads}
              onUpdateStatus={handleUpdateStatus}
              onDeleteLead={handleDeleteLead}
              onUpdateNotes={handleUpdateNotes}
              onUpdateLead={handleUpdateLead}
              getRemainingTime={clock.getRemainingTime}
              highlightedLeadId={highlightedLeadId}
            />
          </div>
        </div>
      </main>

      {/* Модальное окно настроек и отчета смены */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={setSettings}
        stats={stats}
        leads={leads}
        onResetShift={handleResetShift}
        onRestoreBackup={handleRestoreBackup}
        onImportLeadsText={handleImportLeadsText}
      />

      {/* Модальное окно установки на рабочий стол ПК */}
      <DesktopInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        onInstall={install}
      />
    </div>
  );
}
