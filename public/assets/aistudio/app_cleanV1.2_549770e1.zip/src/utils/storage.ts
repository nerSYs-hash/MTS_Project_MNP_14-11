/**
 * Локальное хранилище данных смены, настроек и списка клиентов
 */
import { ClientLead, ShiftStats, TimerSettings } from '../types';

const LEADS_STORAGE_KEY = 'mts_retention_leads_v1';
const STATS_STORAGE_KEY = 'mts_retention_stats_v1';
const SETTINGS_STORAGE_KEY = 'mts_retention_settings_v1';

export const DEFAULT_SETTINGS: TimerSettings = {
  attempt1Minutes: 30,
  attempt2Minutes: 45,
  attempt3Minutes: 60,
  soundEnabled: true,
  volume: 0.8,
  browserNotificationsEnabled: false,
  collapseDelayMinutes: 3,
  formCollapseDelayMinutes: 0,
  standbyDelayMinutes: 3,
  includeWithoutTpInSaved: true,
  includeEiInSaved: true,
};

const BACKUP_STORAGE_KEY = 'mts_retention_leads_backup_v1';

export const INITIAL_STATS: ShiftStats = {
  savedCount: 0,
  totalCallsCount: 0,
  conversionRate: 0,
  unreachableCount: 0,
  refusedCount: 0,
  shiftStartTime: Date.now(),
  savedWithoutTpChange: 0,
  savedWithEi: 0,
};

export function loadLeadsFromStorage(): ClientLead[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(LEADS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Ошибка загрузки клиентов из localStorage:', e);
    return [];
  }
}

export function saveLeadsToStorage(leads: ClientLead[]): void {
  if (typeof window === 'undefined') return;
  try {
    // Если в текущем списке больше 0 записей, обновляем резервную копию
    if (leads.length > 0) {
      localStorage.setItem(BACKUP_STORAGE_KEY, JSON.stringify(leads));
    }
    localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(leads));
  } catch (e) {
    console.error('Ошибка сохранения клиентов в localStorage:', e);
  }
}

export function loadBackupLeadsFromStorage(): ClientLead[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(BACKUP_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function loadStatsFromStorage(): ShiftStats {
  if (typeof window === 'undefined') return INITIAL_STATS;
  try {
    const raw = localStorage.getItem(STATS_STORAGE_KEY);
    if (!raw) return INITIAL_STATS;
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_STATS,
      ...parsed,
      savedWithoutTpChange: parsed.savedWithoutTpChange || 0,
      savedWithEi: parsed.savedWithEi || 0,
      conversionRate:
        parsed.totalCallsCount > 0
          ? Number(((parsed.savedCount / parsed.totalCallsCount) * 100).toFixed(1))
          : 0,
    };
  } catch (e) {
    console.error('Ошибка загрузки статистики из localStorage:', e);
    return INITIAL_STATS;
  }
}

export function saveStatsToStorage(stats: ShiftStats): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Ошибка сохранения статистики в localStorage:', e);
  }
}

export function loadSettingsFromStorage(): TimerSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      formCollapseDelayMinutes:
        parsed.formCollapseDelayMinutes !== undefined
          ? parsed.formCollapseDelayMinutes
          : parsed.collapseDelayMinutes ?? 3,
      standbyDelayMinutes:
        parsed.standbyDelayMinutes !== undefined ? parsed.standbyDelayMinutes : 5,
    };
  } catch (e) {
    console.error('Ошибка загрузки настроек из localStorage:', e);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettingsToStorage(settings: TimerSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Ошибка сохранения настроек в localStorage:', e);
  }
}

/**
 * Сформировать текстовый отчёт о смене оператора
 */
export function generateShiftReportText(stats: ShiftStats, leads: ClientLead[]): string {
  const dateStr = new Date(stats.shiftStartTime).toLocaleDateString('ru-RU');
  const durationHours = ((Date.now() - stats.shiftStartTime) / (1000 * 60 * 60)).toFixed(1);

  const activeLeads = leads.filter(
    (l) => l.status !== 'saved' && l.status !== 'refused' && l.status !== 'unreachable'
  );
  const autoCount = activeLeads.filter((l) => !l.scheduledByAgreedTime).length;
  const clientAgreedCount = activeLeads.filter((l) => Boolean(l.scheduledByAgreedTime)).length;

  let text = `📊 ОТЧЁТ О СМЕНЕ: ГРУППА СОХРАНЕНИЯ КЛИЕНТОВ МТС (MNP)\n`;
  text += `Дата смены: ${dateStr} (в работе: ~${durationHours} ч.)\n`;
  text += `--------------------------------------------------\n`;
  text += `• Сохранено клиентов: ${stats.savedCount}\n`;
  if ((stats.savedWithoutTpChange || 0) > 0 || (stats.savedWithEi || 0) > 0) {
    text += `  - Без смены ТП: ${stats.savedWithoutTpChange || 0}\n`;
    text += `  - ЕИ (Единый Инструмент): ${stats.savedWithEi || 0}\n`;
  }
  text += `• Всего исходящих звонков: ${stats.totalCallsCount}\n`;
  text += `• Конверсия смены: ${stats.conversionRate.toFixed(1)}%\n`;
  text += `• В очереди перезвонов: ${activeLeads.length} (Авто: ${autoCount}, По просьбе: ${clientAgreedCount})\n`;
  text += `• Недозвонов (после 3 попыток): ${stats.unreachableCount}\n`;
  text += `• Отказов: ${stats.refusedCount}\n`;
  text += `• Всего записей в базе: ${leads.length}\n`;
  text += `--------------------------------------------------\n`;

  const savedLeads = leads.filter((l) => l.status === 'saved');
  if (savedLeads.length > 0) {
    text += `\nСписок сохраненных абонентов:\n`;
    savedLeads.forEach((l, i) => {
      text += `${i + 1}. ${l.phone} (${l.city}) - попытка ${l.attemptCount}/3 ${l.tariffOffer ? `[${l.tariffOffer}]` : ''}\n`;
    });
  }

  return text;
}
