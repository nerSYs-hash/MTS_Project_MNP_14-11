import React, { useState, useEffect } from 'react';
import {
  Phone,
  Copy,
  Check,
  ExternalLink,
  Clock,
  Trash2,
  PhoneOff,
  PhoneForwarded,
  RotateCw,
  CalendarClock,
  Pencil,
  X,
  MessageSquare,
} from 'lucide-react';
import { ClientLead, CallStatus } from '../types';
import {
  getClientLocalTime,
  calculateTargetCallbackTimeByClientHour,
  cleanPhoneNumber,
  formatPhoneNumber,
  findRegionByCity,
  findRegionByPhone,
} from '../data/regionsData';

interface ClientCardProps {
  lead: ClientLead;
  onUpdateStatus: (
    id: string,
    newStatus: CallStatus,
    options?: {
      customTimerMinutes?: number;
      notes?: string;
      isClientAgreed?: boolean;
      attemptCount?: number;
    }
  ) => void;
  onDeleteLead: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onUpdateLead?: (id: string, updates: Partial<ClientLead>) => void;
  remainingTime: {
    totalSeconds: number;
    isExpired: boolean;
    formatted: string;
    isOverdue: boolean;
  };
  isMostUrgent?: boolean;
  isHighlighted?: boolean;
}

export const ClientCard: React.FC<ClientCardProps> = ({
  lead,
  onUpdateStatus,
  onDeleteLead,
  onUpdateNotes,
  onUpdateLead,
  remainingTime,
  isMostUrgent = false,
  isHighlighted = false,
}) => {
  const [copied, setCopied] = useState(false);
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [notesText, setNotesText] = useState(lead.notes);
  const [showSchedulePanel, setShowSchedulePanel] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const QUICK_CITIES = ['Москва', 'СПб', 'Самара', 'Екатеринбург', 'Новосибирск', 'Краснодар'];

  // Состояние редактирования данных карточки (номер телефона, ссылка, город)
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [editPhone, setEditPhone] = useState(lead.phone);
  const [editLink, setEditLink] = useState(lead.uniqueLink || '');
  const [editCity, setEditCity] = useState(lead.city || '');
  const [copiedLink, setCopiedLink] = useState(false);

  // Синхронизация полей при смене лида
  useEffect(() => {
    if (!isEditingInfo) {
      setEditPhone(lead.phone);
      setEditLink(lead.uniqueLink || '');
      setEditCity(lead.city || '');
    }
  }, [lead.phone, lead.uniqueLink, lead.city, isEditingInfo]);

  // Копирование ссылки CRM
  const handleCopyLink = () => {
    if (!editLink) return;
    navigator.clipboard.writeText(editLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 1600);
  };

  // Автоопределение города и региона при изменении номера в режиме редактирования
  const handleEditPhoneChange = (val: string) => {
    const formatted = formatPhoneNumber(val);
    setEditPhone(formatted);
    const matched = findRegionByPhone(val);
    if (matched) {
      setEditCity(matched.city);
    }
  };

  // Быстрый выбор региона
  const handleSelectQuickCity = (city: string) => {
    setEditCity(city);
  };

  // Сохранить отредактированные данные карточки
  const handleSaveInfo = () => {
    const cleaned = cleanPhoneNumber(editPhone);
    const formattedPhone = cleaned.length >= 11 ? formatPhoneNumber(cleaned) : editPhone.trim();
    const cityTrimmed = editCity.trim() || lead.city;
    const region = findRegionByCity(cityTrimmed);

    const updates: Partial<ClientLead> = {
      phone: formattedPhone,
      rawPhone: cleaned || lead.rawPhone,
      uniqueLink: editLink.trim(),
      city: cityTrimmed,
      regionName: region ? region.regionName : lead.regionName,
      timezoneUtc: region ? region.utcOffset : lead.timezoneUtc,
      timezoneMsk: region ? region.mskOffset : lead.timezoneMsk,
    };

    onUpdateLead?.(lead.id, updates);
    setIsEditingInfo(false);
  };

  // Режим планирования перезвона: по времени клиента или через интервал
  const [scheduleMode, setScheduleMode] = useState<'client_time' | 'interval'>('client_time');
  const [clientTargetHour, setClientTargetHour] = useState<string>('18');
  const [clientTargetMinute, setClientTargetMinute] = useState<string>('00');

  // Поля ввода интервала часов и минут
  const [hoursInput, setHoursInput] = useState<string>('0');
  const [minutesInput, setMinutesInput] = useState<string>('30');

  // Местное время клиента
  const clientClock = getClientLocalTime(lead.timezoneUtc);

  // Копирование номера БЕЗ СКОБОК (например: "+7 912 345-67-89")
  const handleCopy = () => {
    const phoneWithoutBrackets = lead.phone.replace(/[()]/g, '').trim();
    navigator.clipboard.writeText(phoneWithoutBrackets);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  // Удаление карточки с плавной быстрой анимацией свайпа вправо (300мс)
  const handleDeleteWithSwipe = () => {
    setIsDeleting(true);
    setTimeout(() => {
      onDeleteLead(lead.id);
    }, 280);
  };

  // Сохранить заметку
  const handleSaveNotes = () => {
    onUpdateNotes(lead.id, notesText);
    setIsEditingNotes(false);
  };

  // Установка перезвона через интервал (час + мин)
  const handleApplyCallbackTime = () => {
    const h = Math.max(0, parseInt(hoursInput, 10) || 0);
    const m = Math.max(0, parseInt(minutesInput, 10) || 0);
    const totalMinutes = h * 60 + m;

    if (totalMinutes > 0) {
      onUpdateStatus(lead.id, 'callback', {
        customTimerMinutes: totalMinutes,
        isClientAgreed: true,
      });
    }
    setShowSchedulePanel(false);
  };

  // Установка перезвона ко времени клиента (например в 18:00 по его часам)
  const handleApplyClientTargetTime = (targetH?: number, targetM?: number) => {
    const h = targetH !== undefined ? targetH : Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 0));
    const m = targetM !== undefined ? targetM : Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
    const preview = calculateTargetCallbackTimeByClientHour(lead.timezoneUtc, h, m);
    if (preview.minutesFromNow > 0) {
      onUpdateStatus(lead.id, 'callback', {
        customTimerMinutes: preview.minutesFromNow,
        isClientAgreed: true,
      });
    }
    setShowSchedulePanel(false);
  };

  // Быстрый выбор часа клиента (например кнопка 18:00)
  const handleQuickClientHour = (h: number, m: number = 0) => {
    setClientTargetHour(String(h));
    setClientTargetMinute(String(m).padStart(2, '0'));
    handleApplyClientTargetTime(h, m);
  };

  // Быстрые пресеты интервала
  const handleQuickPreset = (h: number, m: number) => {
    setHoursInput(String(h));
    setMinutesInput(String(m));
    const total = h * 60 + m;
    onUpdateStatus(lead.id, 'callback', {
      customTimerMinutes: total,
      isClientAgreed: true,
    });
    setShowSchedulePanel(false);
  };

  // Отрисовка панели «Когда перезвонить ?» с двумя логичными режимами:
  // 1) По времени клиента (например в 18:00 по его часам)
  // 2) Через интервал (+30м, +1ч и т.д.)
  const renderSchedulePanel = () => {
    const clientHourNum = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 0));
    const clientMinNum = Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
    const clientSchedulePreview = calculateTargetCallbackTimeByClientHour(
      lead.timezoneUtc,
      clientHourNum,
      clientMinNum
    );

    return (
      <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-3 animate-in fade-in duration-150">
        {/* Переключатель режимов: «По часам клиента» vs «Через интервал» */}
        <div className="flex items-center justify-between gap-2 flex-wrap pb-1.5 border-b border-blue-200/60">
          <div className="inline-flex rounded-xl bg-white p-0.5 border border-blue-200">
            <button
              type="button"
              onClick={() => setScheduleMode('client_time')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                scheduleMode === 'client_time'
                  ? 'bg-[#0077FF] text-white shadow-xs'
                  : 'text-[#626C77] hover:text-[#1D2023]'
              }`}
            >
              🕒 По часам клиента (в 18:00)
            </button>
            <button
              type="button"
              onClick={() => setScheduleMode('interval')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                scheduleMode === 'interval'
                  ? 'bg-[#0077FF] text-white shadow-xs'
                  : 'text-[#626C77] hover:text-[#1D2023]'
              }`}
            >
              ⏱️ Через интервал (+30м, +1ч)
            </button>
          </div>

          <div className="text-[11px] font-bold text-[#626C77]">
            У клиента сейчас: <span className="text-[#1D2023] font-extrabold">{clientClock.formattedTime}</span>
          </div>
        </div>

        {scheduleMode === 'client_time' ? (
          /* РЕЖИМ 1: По времени клиента */
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-bold text-[#1D2023] mr-1">
                Быстрый час абонента:
              </span>
              {[10, 12, 14, 16, 17, 18, 19, 20].map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => handleQuickClientHour(h, 0)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                    clientHourNum === h && clientMinNum === 0
                      ? 'bg-[#0077FF] text-white border-[#0077FF]'
                      : 'bg-white hover:bg-blue-100 text-[#0077FF] border-blue-200'
                  }`}
                >
                  {h}:00
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between gap-3 pt-1 border-t border-blue-200/60 flex-wrap">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1D2023]">
                <span>Перезвонить в:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="23"
                    value={clientTargetHour}
                    onChange={(e) => setClientTargetHour(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleApplyClientTargetTime();
                      }
                    }}
                    placeholder="18"
                    className="w-12 h-8 px-1.5 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <span>:</span>
                  <input
                    type="number"
                    min="0"
                    max="59"
                    value={clientTargetMinute}
                    onChange={(e) => setClientTargetMinute(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleApplyClientTargetTime();
                      }
                    }}
                    placeholder="00"
                    className="w-12 h-8 px-1.5 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                </div>
                <span className="text-[#626C77] text-xs font-normal">
                  ({clientSchedulePreview.isTomorrow ? 'завтра' : 'сегодня'}, через{' '}
                  {Math.floor(clientSchedulePreview.minutesFromNow / 60) > 0
                    ? `${Math.floor(clientSchedulePreview.minutesFromNow / 60)}ч `
                    : ''}
                  {clientSchedulePreview.minutesFromNow % 60}мин)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyClientTargetTime()}
                  className="h-8 px-3.5 rounded-xl bg-[#0077FF] hover:bg-[#0055CC] text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Установить на {clientSchedulePreview.formattedTargetTime}
                </button>
                <button
                  type="button"
                  onClick={() => setShowSchedulePanel(false)}
                  className="h-8 px-2 rounded-lg text-[#626C77] text-xs font-medium hover:text-[#1D2023] transition-colors cursor-pointer"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* РЕЖИМ 2: Через интервал */
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-bold text-[#1D2023] mr-1">
                Через сколько:
              </span>
              {[
                { label: '+15м', h: 0, m: 15 },
                { label: '+30м', h: 0, m: 30 },
                { label: '+1ч', h: 1, m: 0 },
                { label: '+2ч', h: 2, m: 0 },
                { label: '+3ч', h: 3, m: 0 },
              ].map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => handleQuickPreset(p.h, p.m)}
                  className="px-2 py-0.5 rounded-md bg-white hover:bg-blue-100 text-xs font-semibold text-[#0077FF] border border-blue-200 transition-colors cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between gap-3 pt-1 border-t border-blue-200/60 flex-wrap">
              <div className="flex items-center gap-3 text-xs font-bold text-[#1D2023]">
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    max="48"
                    value={hoursInput}
                    onChange={(e) => setHoursInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleApplyCallbackTime();
                      }
                    }}
                    placeholder="0"
                    className="w-14 h-8 px-2 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <span className="text-[#626C77] text-xs">час.</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    max="59"
                    value={minutesInput}
                    onChange={(e) => setMinutesInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleApplyCallbackTime();
                      }
                    }}
                    placeholder="30"
                    className="w-14 h-8 px-2 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <span className="text-[#626C77] text-xs">мин.</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleApplyCallbackTime}
                  className="h-8 px-4 rounded-xl bg-[#0077FF] hover:bg-[#0055CC] text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Установить
                </button>
                <button
                  type="button"
                  onClick={() => setShowSchedulePanel(false)}
                  className="h-8 px-2 rounded-lg text-[#626C77] text-xs font-medium hover:text-[#1D2023] transition-colors cursor-pointer"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const isSaved = lead.status === 'saved';
  const isRefused = lead.status === 'refused';
  const isCompleted = isSaved || isRefused;

  // =========================================================================
  // Панель редактирования данных абонента (соответствует карточке клиента:
  // 1. Телефон с автоопределением региона
  // 2. Город / Регион
  // 3. Ссылка на предложение с удобным копированием
  // + Быстрый выбор частых городов РФ)
  // =========================================================================
  const renderEditInfoPanel = () => (
    <div className="mt-2.5 p-3 bg-blue-50/70 rounded-2xl border border-blue-200">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {/* 1. Телефон (с автоопределением города) */}
        <div>
          <label className="text-[10px] font-bold text-[#626C77] uppercase block mb-1">
            Телефон
          </label>
          <input
            type="text"
            value={editPhone}
            onChange={(e) => handleEditPhoneChange(e.target.value)}
            placeholder="+7 (999) 000-00-00"
            className="w-full h-8 px-2.5 rounded-lg bg-white border border-[#CBD5E1] text-xs font-bold text-[#1D2023] focus:border-[#0077FF] focus:outline-none"
          />
        </div>

        {/* 2. Город / Регион */}
        <div>
          <label className="text-[10px] font-bold text-[#626C77] uppercase block mb-1">
            Город / Регион
          </label>
          <input
            type="text"
            value={editCity}
            onChange={(e) => setEditCity(e.target.value)}
            placeholder="Москва"
            className="w-full h-8 px-2.5 rounded-lg bg-white border border-[#CBD5E1] text-xs text-[#1D2023] focus:border-[#0077FF] focus:outline-none"
          />
        </div>

        {/* 3. Ссылка на предложение (с удобным копированием) */}
        <div>
          <label className="text-[10px] font-bold text-[#626C77] uppercase block mb-1">
            Ссылка на предложение
          </label>
          <div className="relative">
            <input
              type="text"
              value={editLink}
              onChange={(e) => setEditLink(e.target.value)}
              placeholder="https://crm.mts.ru/..."
              className="w-full h-8 px-2.5 pr-8 rounded-lg bg-white border border-[#CBD5E1] text-xs text-[#1D2023] focus:border-[#0077FF] focus:outline-none"
            />
            {editLink && (
              <button
                type="button"
                onClick={handleCopyLink}
                title="Скопировать ссылку CRM"
                className="absolute right-1 top-1 w-6 h-6 rounded-md bg-[#F4F5F7] hover:bg-blue-100 text-[#0077FF] flex items-center justify-center transition-colors cursor-pointer"
              >
                {copiedLink ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Быстрый доступ для частых городов РФ */}
      <div className="mt-2.5 pt-2 border-t border-blue-200/60 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#626C77]">
          <span className="font-semibold text-[#1D2023] text-[11px]">Частые:</span>
          {QUICK_CITIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => handleSelectQuickCity(c)}
              className="px-2 py-0.5 rounded-md bg-white hover:bg-blue-50 hover:text-[#0077FF] text-[#1D2023] font-medium text-[11px] border border-gray-200 transition-colors cursor-pointer"
            >
              {c}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <button
            type="button"
            onClick={() => setIsEditingInfo(false)}
            className="h-7 px-3 rounded-lg text-xs font-medium text-[#626C77] hover:bg-white transition-colors cursor-pointer"
          >
            Отмена
          </button>
          <button
            type="button"
            onClick={handleSaveInfo}
            className="h-7 px-3.5 rounded-lg bg-[#0077FF] hover:bg-[#0055CC] text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
          >
            <Check className="w-3.5 h-3.5" />
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );

  // =========================================================================
  // Завершённый абонент (Сохранен / Отказ)
  // =========================================================================
  if (isCompleted) {
    return (
      <div
        id={`card-${lead.id}`}
        className={`bg-white rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 border border-[#F1F3F5] shadow-mts-card transition-all duration-300 ease-out ${
          isDeleting ? 'translate-x-[110%] opacity-0 pointer-events-none' : 'translate-x-0 opacity-100'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                isSaved ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-[#626C77]'
              }`}
            >
              {isSaved ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <PhoneOff className="w-4 h-4 text-[#626C77]" />
              )}
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-base sm:text-lg font-bold text-[#1D2023] tracking-tight">
                {lead.phone}
              </span>

              {/* Кнопка 1: Редактирование (Карандаш) */}
              <button
                type="button"
                onClick={() => setIsEditingInfo(!isEditingInfo)}
                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                  isEditingInfo ? 'bg-blue-100 text-[#0077FF]' : 'bg-[#F4F5F7] hover:bg-blue-50 text-[#626C77] hover:text-[#0077FF]'
                }`}
                title="Редактировать номер, город или ссылку"
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>

              {/* Кнопка 2: Копирование номера */}
              <button
                type="button"
                onClick={handleCopy}
                className="w-7 h-7 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
                title="Скопировать номер (без скобок)"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>

              {/* Кнопка 3: Ссылка на предложение */}
              {lead.uniqueLink && (
                <a
                  href={lead.uniqueLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-7 h-7 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0077FF] flex items-center justify-center transition-colors cursor-pointer"
                  title="Открыть предложение клиенту в CRM"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              <span className="text-gray-300">•</span>
              <span className="text-xs text-[#626C77]">{lead.city}</span>
              {lead.notes && (
                <>
                  <span className="text-gray-300">•</span>
                  <span className="text-xs text-slate-600 max-w-[260px] truncate">{lead.notes}</span>
                </>
              )}
            </div>
          </div>

          {/* Статус и кнопка удаления со свайпом */}
          <div className="flex items-center gap-2 ml-auto">
            {isSaved ? (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                Сохранен
              </span>
            ) : (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-[#626C77] border border-gray-200">
                Отказ
              </span>
            )}

            <button
              type="button"
              onClick={handleDeleteWithSwipe}
              title="Удалить карточку"
              className="w-8 h-8 rounded-lg text-slate-400 hover:text-[#FF0032] hover:bg-[#FEF2F2] flex items-center justify-center transition-colors cursor-pointer shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Инлайн-панель редактирования */}
        {isEditingInfo && renderEditInfoPanel()}
      </div>
    );
  }

  // =========================================================================
  // Лаконичная карточка в очереди:
  // - Строка 1: Абонент, Карандаш, Копировать, Ссылка CRM, Город | Отказ, Сохранен, Удалить
  //   (Без лишних мелких бейджей «Перезвон» и без часов клиента)
  // - Строка 2: Таймер, «Когда перезвонить ?» (кнопка без текста), «Звонков» (стиль МТС) | Заметка
  // =========================================================================
  const hasActiveTimer =
    lead.status !== 'saved' &&
    lead.status !== 'refused' &&
    lead.status !== 'unreachable' &&
    lead.targetCallbackTime !== null;

  return (
    <div
      id={`card-${lead.id}`}
      className={`bg-white rounded-2xl sm:rounded-3xl p-3 sm:p-4 border border-[#F1F3F5] shadow-mts-card transition-all duration-300 ease-out ${
        isDeleting ? 'translate-x-[110%] opacity-0 pointer-events-none' : 'translate-x-0 opacity-100'
      } ${isHighlighted ? 'ring-2 ring-[#0077FF]/50' : ''}`}
    >
      {/* СТРОКА 1: Данные клиента + Быстрые действия завершения */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        {/* Левая группа: Телефон, кнопки, город */}
        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
          <div className="w-8 h-8 rounded-xl bg-red-50 text-[#E30613] flex items-center justify-center font-bold shrink-0">
            <Phone className="w-4 h-4 text-[#E30613]" />
          </div>

          <span className="text-base sm:text-lg font-extrabold text-[#1D2023] tracking-tight">
            {lead.phone}
          </span>

          {/* Кнопка 1: Редактирование (Карандаш) */}
          <button
            type="button"
            onClick={() => setIsEditingInfo(!isEditingInfo)}
            className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
              isEditingInfo
                ? 'bg-blue-100 text-[#0077FF]'
                : 'bg-[#F4F5F7] hover:bg-blue-50 text-[#626C77] hover:text-[#0077FF]'
            }`}
            title="Редактировать номер, город или ссылку"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>

          {/* Кнопка 2: Копирование номера */}
          <button
            type="button"
            onClick={handleCopy}
            className="w-7 h-7 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#626C77] hover:text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
            title="Скопировать номер (без скобок)"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Кнопка 3: Ссылка CRM */}
          {lead.uniqueLink && (
            <a
              href={lead.uniqueLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-7 h-7 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0077FF] flex items-center justify-center transition-colors cursor-pointer"
              title="Открыть предложение клиенту в CRM"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}

          <span className="text-gray-300 hidden sm:inline">•</span>

          <span className="text-xs text-[#626C77] font-medium">{lead.city}</span>
        </div>

        {/* Правая группа: Отказ, Клиент Сохранен, Корзина */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            type="button"
            onClick={() => onUpdateStatus(lead.id, 'refused')}
            className="h-8 px-3 rounded-xl border border-[#D5D8DD] hover:border-gray-400 hover:bg-gray-50 text-[#626C77] hover:text-[#1D2023] text-xs font-bold transition-all cursor-pointer"
          >
            Отказ
          </button>

          <button
            type="button"
            onClick={() => onUpdateStatus(lead.id, 'saved')}
            className="h-8 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shadow-sm"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Сохранен! (+1)</span>
          </button>

          <button
            type="button"
            onClick={handleDeleteWithSwipe}
            title="Удалить карточку"
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-[#FF0032] hover:bg-[#FEF2F2] flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Инлайн-панель редактирования */}
      {isEditingInfo && renderEditInfoPanel()}

      {/* СТРОКА 2: Таймер, «Когда перезвонить ?» (без текста), «Звонков» (в стиле МТС без фона и обводки) и Заметка */}
      <div className="mt-2.5 pt-2.5 border-t border-[#F1F3F5] flex flex-wrap items-center justify-between gap-2">
        {/* Левая группа: Таймер + управление очередью */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
          {hasActiveTimer && (
            <div
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-extrabold tabular-nums ${
                remainingTime.isExpired
                  ? isMostUrgent
                    ? 'bg-[#E30613] text-white animate-pulse'
                    : 'bg-[#E30613] text-white'
                  : 'bg-[#F4F5F7] text-[#1D2023] border border-[#E2E8F0]'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{remainingTime.formatted}</span>
            </div>
          )}

          {/* Кнопка настройки времени перезвона (БЕЗ ТЕКСТА) */}
          <button
            type="button"
            onClick={() => setShowSchedulePanel(!showSchedulePanel)}
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
              showSchedulePanel
                ? 'bg-blue-100 text-[#0077FF]'
                : 'bg-[#F4F5F7] hover:bg-blue-50 text-[#626C77] hover:text-[#0077FF]'
            }`}
            title="Когда перезвонить ? (настроить точное время)"
          >
            <PhoneForwarded className="w-3.5 h-3.5" />
          </button>

          {/* Кнопка «Звонков» в строгом стиле МТС: без оранжевого фона, без оранжевой обводки, серые/черные буквы */}
          <button
            type="button"
            onClick={() => {
              if (lead.attemptCount >= lead.maxAttempts) {
                onUpdateStatus(lead.id, 'unreachable');
              } else {
                onUpdateStatus(lead.id, 'answering_machine', { isClientAgreed: false });
              }
            }}
            className="h-7 sm:h-8 px-2.5 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#2A2F37] hover:text-[#1D2023] text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
            title="Зафиксировать попытку звонка (автодозвон)"
          >
            <RotateCw className="w-3.5 h-3.5 text-[#626C77]" />
            <span>
              {lead.attemptCount >= lead.maxAttempts
                ? 'Звонков: 3/3 (завершить)'
                : `Звонков (${lead.attemptCount}/${lead.maxAttempts})`}
            </span>
          </button>
        </div>

        {/* Правая группа: Компактная заметка */}
        <div className="flex items-center gap-1.5 text-xs text-[#626C77] ml-auto">
          {lead.notes ? (
            <button
              type="button"
              onClick={() => setIsEditingNotes(true)}
              className="inline-flex items-center gap-1 max-w-[200px] sm:max-w-[320px] truncate text-left hover:text-[#0077FF] transition-colors cursor-pointer font-medium"
              title="Нажмите, чтобы изменить заметку"
            >
              <MessageSquare className="w-3.5 h-3.5 shrink-0 text-[#0077FF]" />
              <span className="truncate">{lead.notes}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setIsEditingNotes(true)}
              className="text-xs text-[#626C77] hover:text-[#0077FF] font-medium transition-colors cursor-pointer flex items-center gap-1"
            >
              <MessageSquare className="w-3 h-3" />
              <span>+ Заметка</span>
            </button>
          )}
        </div>
      </div>

      {/* Инлайн-панель настройки перезвона (раскрывается по кнопке с телефонной трубкой) */}
      {showSchedulePanel && (
        <div className="mt-2.5">
          {renderSchedulePanel()}
        </div>
      )}

      {/* Инлайн-редактор заметки */}
      {isEditingNotes && (
        <div className="mt-2.5 p-2.5 bg-gray-50 rounded-xl border border-gray-200 space-y-2">
          <textarea
            value={notesText}
            onChange={(e) => setNotesText(e.target.value)}
            placeholder="Добавьте причину ухода, скидку, предложенный тариф..."
            rows={2}
            className="w-full p-2 rounded-lg border border-[#D5D8DD] text-xs text-[#1D2023] focus:border-[#0077FF] focus:outline-none bg-white"
          />
          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setNotesText(lead.notes);
                setIsEditingNotes(false);
              }}
              className="px-2.5 py-1 text-xs text-[#626C77] hover:text-[#1D2023]"
            >
              Отмена
            </button>
            <button
              type="button"
              onClick={handleSaveNotes}
              className="px-3 py-1 rounded-lg bg-[#1D2023] text-white text-xs font-bold hover:bg-black transition-colors cursor-pointer"
            >
              Сохранить
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
