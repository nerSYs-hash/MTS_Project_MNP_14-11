import React from 'react';
import { Volume2, VolumeX, Settings, Monitor, Maximize2, Minimize2, Wrench } from 'lucide-react';
import { TimerSettings } from '../types';

interface HeaderProps {
  localTimeStr: string;
  moscowTimeStr: string;
  currentDateStr: string;
  settings: TimerSettings;
  onToggleSound: () => void;
  onOpenSettings: () => void;
  onOpenReport: () => void;
  onOpenInstallModal: () => void;
  onOpenChangelog?: () => void;
  isInstalled: boolean;
  activeTimersCount: number;
  isStandbyMode?: boolean;
  onToggleStandby?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  localTimeStr,
  moscowTimeStr,
  currentDateStr,
  settings,
  onToggleSound,
  onOpenSettings,
  onOpenInstallModal,
  onOpenChangelog,
  isInstalled,
  isStandbyMode = false,
  onToggleStandby,
}) => {
  return (
    <header className="bg-white border-b border-[#F1F3F5] sticky top-0 z-30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Левая часть: Квадратный логотип МТС с буквами по углам и строго только MNP */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Фирменный квадратный логотип МТС с буквами М Т С по углам */}
          <div
            className="w-11 h-11 rounded-2xl bg-[#E30613] p-1.5 grid grid-cols-2 grid-rows-2 text-white select-none shadow-mts-red shrink-0"
            title="МТС"
          >
            <span className="text-[12px] font-black leading-none self-start justify-self-start">М</span>
            <span className="text-[12px] font-black leading-none self-start justify-self-end">Т</span>
            <span className="text-[12px] font-black leading-none self-end justify-self-start">С</span>
            <span className="w-1.5 h-1.5 rounded-full bg-white/40 self-end justify-self-end mr-0.5 mb-0.5" />
          </div>

          <span className="text-xl sm:text-2xl font-black text-[#1D2023] tracking-wide uppercase font-['Manrope']">
            MNP
          </span>
        </div>

        {/* Центр: Дата и системные часы ПК / МСК (строго по центру экрана) */}
        <div className="hidden md:flex items-center justify-center flex-1">
          <div className="bg-[#F4F5F7] px-3.5 py-1.5 rounded-2xl flex items-center gap-3 text-xs border border-[#EBECEF] shadow-2xs">
            <div className="text-right">
              <div className="font-extrabold text-[#1D2023] text-sm tabular-nums tracking-wide">
                {localTimeStr}
              </div>
              <div className="text-[11px] text-[#626C77] font-medium uppercase tracking-tight">
                ПК ({currentDateStr})
              </div>
            </div>
            <div className="h-6 w-px bg-[#D5D8DD]" />
            <div>
              <div className="font-bold text-[#1D2023] text-sm tabular-nums tracking-wide">
                {moscowTimeStr}
              </div>
              <div className="text-[11px] text-[#626C77] font-medium uppercase tracking-tight">
                МСК (UTC+3)
              </div>
            </div>
          </div>
        </div>

        {/* Правая часть: Кнопки действий в заданном порядке */}
        <div className="flex items-center gap-2 shrink-0">
          {/* 1. Кнопка «На рабочий стол» (только иконка/эмодзи, без текста, рядом со звуком) */}
          {!isInstalled && (
            <button
              type="button"
              onClick={onOpenInstallModal}
              className="w-10 h-10 rounded-2xl bg-white border border-[#D5D8DD] hover:border-[#0077FF] text-[#1D2023] hover:text-[#0077FF] flex items-center justify-center transition-all cursor-pointer shadow-xs"
              title="Установить как десктопное приложение на рабочий стол ПК"
            >
              <Monitor className="w-5 h-5 text-[#0077FF]" />
            </button>
          )}

          {/* 2. Звуковое оповещение */}
          <button
            type="button"
            onClick={onToggleSound}
            title={settings.soundEnabled ? 'Звук включен (нажмите, чтобы выключить)' : 'Звук выключен'}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
              settings.soundEnabled
                ? 'bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023]'
                : 'bg-red-50 hover:bg-red-100 text-[#E30613]'
            }`}
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-5 h-5 text-[#1D2023]" />
            ) : (
              <VolumeX className="w-5 h-5 text-[#E30613]" />
            )}
          </button>

          {/* 3. Свернуть и развернуть (расположена после кнопки звука) */}
          {onToggleStandby && (
            <button
              type="button"
              onClick={onToggleStandby}
              title={isStandbyMode ? 'Развернуть форму и очередь' : 'Свернуть рабочее место в центр (режим ожидания)'}
              className={`flex items-center gap-1.5 h-10 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isStandbyMode
                  ? 'bg-[#E30613] text-white shadow-mts-red'
                  : 'bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023]'
              }`}
            >
              {isStandbyMode ? (
                <>
                  <Maximize2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Развернуть</span>
                </>
              ) : (
                <>
                  <Minimize2 className="w-4 h-4 text-[#626C77]" />
                  <span className="hidden sm:inline">Свернуть в центр</span>
                </>
              )}
            </button>
          )}

          {/* 4. Кнопка обновлений (с гаечным ключом и без слова ОБНОВЛЕНИЯ, рядом с настройками) */}
          <button
            type="button"
            onClick={onOpenChangelog}
            title="Журнал обновлений (патч-ноут)"
            className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
          >
            <Wrench className="w-5 h-5 text-[#1D2023]" />
          </button>

          {/* 5. Настройки рабочего места */}
          <button
            type="button"
            onClick={onOpenSettings}
            title="Настройки рабочего места и отчет смены"
            className="w-10 h-10 rounded-2xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] flex items-center justify-center transition-colors cursor-pointer"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
