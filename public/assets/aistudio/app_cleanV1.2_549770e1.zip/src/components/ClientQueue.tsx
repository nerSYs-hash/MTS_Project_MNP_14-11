import React, { useState } from 'react';
import { Search, PhoneCall, CheckCircle2, Clock, PhoneOff } from 'lucide-react';
import { ClientLead, CallStatus } from '../types';
import { ClientCard } from './ClientCard';

interface ClientQueueProps {
  leads: ClientLead[];
  onUpdateStatus: (
    id: string,
    newStatus: CallStatus,
    options?: {
      customTimerMinutes?: number;
      notes?: string;
      isClientAgreed?: boolean;
      attemptCount?: number;
    }
  ) => void;
  onDeleteLead: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onUpdateLead?: (id: string, updates: Partial<ClientLead>) => void;
  getRemainingTime: (targetTimestamp: number | null) => {
    totalSeconds: number;
    isExpired: boolean;
    formatted: string;
    isOverdue: boolean;
  };
  highlightedLeadId?: string | null;
}

type TabType = 'all' | 'due' | 'auto' | 'callback' | 'saved' | 'refused';

export const ClientQueue: React.FC<ClientQueueProps> = ({
  leads,
  onUpdateStatus,
  onDeleteLead,
  onUpdateNotes,
  onUpdateLead,
  getRemainingTime,
  highlightedLeadId,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Сортировка очереди:
  // - Завершенные (сохранен/отказ) уходят в конец общего списка
  // - В табе «Пора звонить» первыми идут самые срочные
  // - Новая заполненная заявка (авто или перезвон) ВСЕГДА ПОДНИМАЕТСЯ ПЕРВОЙ НАВЕРХ!
  const sortedLeads = [...leads].sort((a, b) => {
    const isDoneA = a.status === 'saved' || a.status === 'refused' || a.status === 'unreachable';
    const isDoneB = b.status === 'saved' || b.status === 'refused' || b.status === 'unreachable';
    if (isDoneA && !isDoneB) return 1;
    if (!isDoneA && isDoneB) return -1;

    if (activeTab === 'due') {
      const timeA = a.targetCallbackTime || Number.MAX_SAFE_INTEGER;
      const timeB = b.targetCallbackTime || Number.MAX_SAFE_INTEGER;
      return timeA - timeB;
    }

    // Новые заявки всегда первой в списке (по дате добавления)
    return (b.createdAt || 0) - (a.createdAt || 0);
  });

  // Активные клиенты в очереди (ожидающие звонка)
  const activeLeads = leads.filter(
    (l) => l.status !== 'saved' && l.status !== 'refused' && l.status !== 'unreachable'
  );
  const autoLeads = activeLeads.filter((l) => !l.scheduledByAgreedTime);
  const callbackLeads = activeLeads.filter((l) => Boolean(l.scheduledByAgreedTime));

  const dueLeads = activeLeads.filter((l) => {
    if (l.targetCallbackTime) {
      return getRemainingTime(l.targetCallbackTime).isExpired;
    }
    return false;
  });

  // Точный подсчет количества по табам: auto + callback = activeLeads.length
  const counts = {
    all: leads.length,
    due: dueLeads.length,
    auto: autoLeads.length,
    callback: callbackLeads.length,
    saved: leads.filter((l) => l.status === 'saved').length,
    refused: leads.filter((l) => l.status === 'refused').length,
  };

  // Фильтрация
  const filteredLeads = sortedLeads.filter((lead) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchPhone = lead.phone.toLowerCase().includes(q) || lead.rawPhone.includes(q);
      const matchCity = lead.city.toLowerCase().includes(q);
      const matchNotes = lead.notes.toLowerCase().includes(q);
      if (!matchPhone && !matchCity && !matchNotes) return false;
    }

    if (activeTab === 'all') return true;
    if (activeTab === 'due') {
      if (lead.targetCallbackTime) {
        return getRemainingTime(lead.targetCallbackTime).isExpired;
      }
      return false;
    }
    if (activeTab === 'auto') {
      return (
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable' &&
        !lead.scheduledByAgreedTime
      );
    }
    if (activeTab === 'callback') {
      return (
        lead.status !== 'saved' &&
        lead.status !== 'refused' &&
        lead.status !== 'unreachable' &&
        Boolean(lead.scheduledByAgreedTime)
      );
    }
    if (activeTab === 'saved') return lead.status === 'saved';
    if (activeTab === 'refused') return lead.status === 'refused';

    return true;
  });

  return (
    <section className="space-y-4">
      {/* Панель табов и поиска */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3 sm:p-4 rounded-3xl border border-[#F1F3F5] shadow-mts-card">
        {/* Две понятные вкладки: Автоответчик и Перезвон (вместо непонятного Ждут звонка) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === 'all'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
          >
            Все ({counts.all})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('due')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'due'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : counts.due > 0
                ? 'bg-rose-100 text-[#E30613] hover:bg-rose-200'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
          >
            <span>Пора звонить</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                counts.due > 0
                  ? 'bg-[#E30613] text-white font-extrabold'
                  : 'bg-gray-300 text-gray-700'
              }`}
            >
              {counts.due}
            </span>
          </button>

          {/* Вкладка 1: Автоответчик */}
          <button
            type="button"
            onClick={() => setActiveTab('auto')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'auto'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
            title="Автоматические перезвоны (попытки дозвона 1-3)"
          >
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block shrink-0" />
            <span>Автоответчик ({counts.auto})</span>
          </button>

          {/* Вкладка 2: Перезвон (по просьбе клиента) */}
          <button
            type="button"
            onClick={() => setActiveTab('callback')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'callback'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
            title="Перезвоны по просьбе / договоренности с клиентом"
          >
            <span className="w-2 h-2 rounded-full bg-[#0077FF] inline-block shrink-0" />
            <span>Перезвон ({counts.callback})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === 'saved'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
          >
            Сохраненные ({counts.saved})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('refused')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === 'refused'
                ? 'bg-[#1D2023] text-white shadow-sm'
                : 'bg-[#F4F5F7] text-[#2A2F37] hover:bg-gray-200'
            }`}
          >
            Отказы ({counts.refused})
          </button>
        </div>

        {/* Быстрый поиск (синяя 2px обводка при фокусе) */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-[#8C95A0] absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Поиск по номеру, городу..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') e.currentTarget.blur();
            }}
            className="w-full h-10 pl-9 pr-3.5 rounded-xl border border-[#D5D8DD] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none text-xs text-[#1D2023] bg-white placeholder-[#8C95A0]"
          />
        </div>
      </div>

      {/* Список карточек клиентов */}
      {filteredLeads.length > 0 ? (
        <div className="space-y-3">
          {filteredLeads.map((lead, index) => {
            const timeInfo = getRemainingTime(lead.targetCallbackTime);
            const isMostUrgent = index === 0 && timeInfo.isExpired;
            const isHighlighted = highlightedLeadId === lead.id;

            return (
              <ClientCard
                key={lead.id}
                lead={lead}
                onUpdateStatus={onUpdateStatus}
                onDeleteLead={onDeleteLead}
                onUpdateNotes={onUpdateNotes}
                onUpdateLead={onUpdateLead}
                remainingTime={timeInfo}
                isMostUrgent={isMostUrgent}
                isHighlighted={isHighlighted}
              />
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-10 border border-[#F1F3F5] shadow-mts-card text-center">
          <div className="w-14 h-14 rounded-2xl bg-[#F4F5F7] text-[#626C77] flex items-center justify-center mx-auto mb-3">
            <PhoneCall className="w-6 h-6 text-[#8C95A0]" />
          </div>
          <h3 className="text-base font-bold text-[#1D2023]">В этой вкладке пока нет заявок</h3>
          <p className="text-xs text-[#626C77] font-normal mt-1 max-w-md mx-auto">
            {searchQuery
              ? 'По запросу ничего не найдено.'
              : 'Внесите номер абонента в Карточку Клиента выше, чтобы записать звонок.'}
          </p>
        </div>
      )}
    </section>
  );
};
