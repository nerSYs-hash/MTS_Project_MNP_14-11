import React, { useState, useEffect, useRef, useId } from 'react';
import {
  Clock,
  ClipboardPaste,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Check,
  PhoneForwarded,
} from 'lucide-react';
import {
  formatPhoneNumber,
  findRegionByPhone,
  findRegionByCity,
  getClientLocalTime,
  calculateTargetCallbackTimeByClientHour,
  cleanPhoneNumber,
  RUSSIAN_REGIONS,
} from '../data/regionsData';
import { ClientLead } from '../types';

interface AddClientFormProps {
  onAddClient: (newLead: Omit<ClientLead, 'id' | 'createdAt' | 'updatedAt'>) => void;
  collapseDelayMinutes?: number;
  isCollapsed?: boolean;
  onToggleCollapse?: (collapsed: boolean) => void;
  defaultAttempt1Minutes?: number;
}

const DEFAULT_CITIES = ['Москва', 'СПб', 'Екатеринбург', 'Самара', 'Новосибирск', 'Краснодар'];
const CITY_USAGE_STORAGE_KEY = 'mts_city_usage_frequency';

export const AddClientForm: React.FC<AddClientFormProps> = ({
  onAddClient,
  defaultAttempt1Minutes = 30,
}) => {
  const [phoneInput, setPhoneInput] = useState('');
  const [cityInput, setCityInput] = useState('');
  const [linkInput, setLinkInput] = useState('');
  const [notesInput, setNotesInput] = useState('');
  const [detectedUtcOffset, setDetectedUtcOffset] = useState<number>(3);
  const [detectedMskOffset, setDetectedMskOffset] = useState<number>(0);
  const [detectedRegionName, setDetectedRegionName] = useState<string>('Москва и Московская область');
  const [isAutoDetected, setIsAutoDetected] = useState(false);
  const [pastedFeedback, setPastedFeedback] = useState(false);

  // Мягкая подсветка ошибок
  const [phoneHasError, setPhoneHasError] = useState(false);
  const [cityHasError, setCityHasError] = useState(false);

  // Выпадающее меню автодополнения городов
  const [showCityDropdown, setShowCityDropdown] = useState(false);
  const [citySuggestions, setCitySuggestions] = useState<typeof RUSSIAN_REGIONS>([]);

  // Тултипы
  const [showHelpTooltip, setShowHelpTooltip] = useState(false);
  const [showCityHelpTooltip, setShowCityHelpTooltip] = useState(false);

  // Панель «Когда перезвонить ?»
  const [showSchedulePanel, setShowSchedulePanel] = useState(false);
  const [scheduledMinutes, setScheduledMinutes] = useState<number | null>(null);
  const [scheduleMode, setScheduleMode] = useState<'client_time' | 'interval'>('client_time');
  const [clientTargetHour, setClientTargetHour] = useState('18');
  const [clientTargetMinute, setClientTargetMinute] = useState('00');
  const [hoursInput, setHoursInput] = useState('0');
  const [minutesInput, setMinutesInput] = useState('30');

  // Динамические частые города по частоте использования
  const [cityUsage, setCityUsage] = useState<Record<string, number>>(() => {
    try {
      const stored = localStorage.getItem(CITY_USAGE_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return { Москва: 10, СПб: 8, Екатеринбург: 6, Самара: 5, Новосибирск: 4, Краснодар: 4 };
  });

  const phoneRef = useRef<HTMLInputElement>(null);
  const cityInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const lastActivityRef = useRef<number>(Date.now());

  const phoneInputId = useId();
  const cityInputId = useId();
  const linkInputId = useId();
  const notesInputId = useId();

  const handleUserActivity = () => {
    lastActivityRef.current = Date.now();
  };

  // Закрытие выпадающего списка городов при клике вне
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node) &&
        cityInputRef.current &&
        !cityInputRef.current.contains(e.target as Node)
      ) {
        setShowCityDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Регистрация частоты использования города
  const recordCityUsage = (city: string) => {
    const trimmed = city.trim();
    if (!trimmed) return;
    setCityUsage((prev) => {
      const updated = { ...prev, [trimmed]: (prev[trimmed] || 0) + 1 };
      try {
        localStorage.setItem(CITY_USAGE_STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // storage disabled
      }
      return updated;
    });
  };

  // Получение топ-6 частых городов
  const frequentCities = (() => {
    const combined = Array.from(new Set([...Object.keys(cityUsage), ...DEFAULT_CITIES]));
    return combined
      .sort((a, b) => (cityUsage[b] || 0) - (cityUsage[a] || 0))
      .slice(0, 6);
  })();

  // Обработка ввода номера телефона
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleUserActivity();
    const rawVal = e.target.value;
    const formatted = formatPhoneNumber(rawVal);
    setPhoneInput(formatted);
    setPhoneHasError(false);

    const matchedRegion = findRegionByPhone(rawVal);
    if (matchedRegion) {
      if (!cityInput || isAutoDetected) {
        setCityInput(matchedRegion.city);
        setCityHasError(false);
      }
      setDetectedRegionName(matchedRegion.regionName);
      setDetectedUtcOffset(matchedRegion.utcOffset);
      setDetectedMskOffset(matchedRegion.mskOffset);
      setIsAutoDetected(true);
    }
  };

  // Обработка клавиш в поле телефона: удаление без застревания на скобках и пробелах
  const handlePhoneKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    handleUserActivity();
    if (e.key === 'Backspace') {
      const input = phoneRef.current;
      if (!input) return;
      const { selectionStart, selectionEnd } = input;
      // Если выделен фрагмент текста, даем браузеру стандартно удалить выделение
      if (selectionStart !== selectionEnd || selectionStart === null) {
        return;
      }

      const val = phoneInput;
      // Если курсор сразу после +7
      if (selectionStart <= 3 && val.startsWith('+7')) {
        e.preventDefault();
        setPhoneInput('');
        setPhoneHasError(false);
        return;
      }

      const charBefore = val[selectionStart - 1];
      // Если символ перед курсором не цифра (например ')', ' ', '-', '(')
      if (charBefore && !/\d/.test(charBefore)) {
        e.preventDefault();
        // Ищем ближайшую цифру слева от курсора
        let prevDigitIndex = -1;
        for (let i = selectionStart - 1; i >= 0; i--) {
          if (/\d/.test(val[i])) {
            prevDigitIndex = i;
            break;
          }
        }

        if (prevDigitIndex > 1) {
          const newRaw = val.slice(0, prevDigitIndex) + val.slice(selectionStart);
          const digits = cleanPhoneNumber(newRaw);
          if (digits.length <= 1) {
            setPhoneInput(digits.length === 1 ? '+7' : '');
          } else {
            setPhoneInput(formatPhoneNumber(newRaw));
          }
          setPhoneHasError(false);
        } else {
          setPhoneInput('');
          setPhoneHasError(false);
        }
      }
    }
  };

  // Обработка ручного ввода города с выпадающим списком подсказок
  const handleCityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleUserActivity();
    const val = e.target.value;
    setCityInput(val);
    setCityHasError(false);

    if (val.trim().length > 0) {
      const q = val.trim().toLowerCase();
      const matches = RUSSIAN_REGIONS.filter(
        (r) =>
          r.city.toLowerCase().startsWith(q) ||
          r.city.toLowerCase().includes(q) ||
          r.regionName.toLowerCase().includes(q) ||
          (r.aliases && r.aliases.some((a) => a.toLowerCase().includes(q)))
      ).slice(0, 8);
      setCitySuggestions(matches);
      setShowCityDropdown(matches.length > 0);
    } else {
      setShowCityDropdown(false);
    }

    const matched = findRegionByCity(val);
    if (matched) {
      setDetectedRegionName(matched.regionName);
      setDetectedUtcOffset(matched.utcOffset);
      setDetectedMskOffset(matched.mskOffset);
      setIsAutoDetected(true);
    }
  };

  const handleSelectSuggestedCity = (region: (typeof RUSSIAN_REGIONS)[0]) => {
    handleUserActivity();
    setCityInput(region.city);
    setDetectedRegionName(region.regionName);
    setDetectedUtcOffset(region.utcOffset);
    setDetectedMskOffset(region.mskOffset);
    setIsAutoDetected(true);
    setCityHasError(false);
    setShowCityDropdown(false);
    recordCityUsage(region.city);
  };

  const handleSelectQuickCity = (city: string) => {
    handleUserActivity();
    recordCityUsage(city);
    const matched = findRegionByCity(city);
    if (matched) {
      setCityInput(matched.city);
      setDetectedRegionName(matched.regionName);
      setDetectedUtcOffset(matched.utcOffset);
      setDetectedMskOffset(matched.mskOffset);
      setIsAutoDetected(true);
      setCityHasError(false);
    } else {
      setCityInput(city);
    }
    setShowCityDropdown(false);
  };

  // Вставка ссылки из буфера
  const handlePasteLink = async () => {
    handleUserActivity();
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setLinkInput(text);
        setPastedFeedback(true);
        setTimeout(() => setPastedFeedback(false), 1500);
      }
    } catch {
      // буфер недоступен
    }
  };

  // Быстрые пресеты для перезвона
  const handleQuickPreset = (h: number, m: number) => {
    handleUserActivity();
    setHoursInput(String(h));
    setMinutesInput(String(m));
    setScheduledMinutes(h * 60 + m);
  };

  // Быстрый выбор часа перезвона по времени клиента (например в 18:00)
  const handleQuickClientHour = (h: number, m: number = 0) => {
    handleUserActivity();
    setClientTargetHour(String(h));
    setClientTargetMinute(String(m).padStart(2, '0'));
    const preview = calculateTargetCallbackTimeByClientHour(detectedUtcOffset, h, m);
    setScheduledMinutes(preview.minutesFromNow);
  };

  // Переключение панели перезвона с автоинициализацией времени
  const handleToggleSchedulePanel = () => {
    handleUserActivity();
    if (!showSchedulePanel) {
      setShowSchedulePanel(true);
      if (scheduledMinutes === null) {
        if (scheduleMode === 'client_time') {
          const h = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 18));
          const m = Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
          const preview = calculateTargetCallbackTimeByClientHour(detectedUtcOffset, h, m);
          setScheduledMinutes(preview.minutesFromNow);
        } else {
          const h = Math.max(0, parseInt(hoursInput, 10) || 0);
          const m = Math.max(0, parseInt(minutesInput, 10) || 30);
          setScheduledMinutes(h * 60 + m);
        }
      }
    } else {
      setShowSchedulePanel(false);
    }
  };

  // Местное время клиента
  const clientClock = getClientLocalTime(detectedUtcOffset);

  // Валидация и отправка формы: кнопка «Записать»
  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    handleUserActivity();

    const cleaned = cleanPhoneNumber(phoneInput);
    let hasErr = false;

    if (cleaned.length < 11) {
      setPhoneHasError(true);
      hasErr = true;
    }

    // Проверяем город: должен быть указан и найден в регионах
    const trimmedCity = cityInput.trim();
    const matched = findRegionByCity(trimmedCity);
    if (!trimmedCity || !matched) {
      setCityHasError(true);
      hasErr = true;
    }

    if (hasErr) {
      return;
    }

    const city = matched ? matched.city : trimmedCity;
    recordCityUsage(city);

    const rawLink = linkInput.trim();
    const uniqueLink = rawLink
      ? rawLink.startsWith('http')
        ? rawLink
        : `https://${rawLink}`
      : `https://crm.mts.ru/lead/${cleaned.slice(-6)}`;

    const now = Date.now();
    let finalScheduledMinutes = scheduledMinutes;
    if (showSchedulePanel && (finalScheduledMinutes === null || finalScheduledMinutes <= 0)) {
      if (scheduleMode === 'client_time') {
        const h = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 18));
        const m = Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
        const preview = calculateTargetCallbackTimeByClientHour(
          matched ? matched.utcOffset : detectedUtcOffset,
          h,
          m
        );
        finalScheduledMinutes = preview.minutesFromNow;
      } else {
        const h = Math.max(0, parseInt(hoursInput, 10) || 0);
        const m = Math.max(0, parseInt(minutesInput, 10) || 30);
        finalScheduledMinutes = h * 60 + m;
      }
    }
    const hasScheduled = finalScheduledMinutes !== null && finalScheduledMinutes > 0;
    const autoMinutes = defaultAttempt1Minutes || 30;
    const assignedDuration = hasScheduled ? (finalScheduledMinutes as number) : autoMinutes;

    onAddClient({
      phone: formatPhoneNumber(cleaned),
      rawPhone: cleaned,
      city,
      regionName: matched ? matched.regionName : detectedRegionName,
      uniqueLink,
      timezoneUtc: matched ? matched.utcOffset : detectedUtcOffset,
      timezoneMsk: matched ? matched.mskOffset : detectedMskOffset,
      status: hasScheduled ? 'callback' : 'answering_machine',
      attemptCount: 1,
      maxAttempts: 3,
      targetCallbackTime: now + assignedDuration * 60 * 1000,
      timerDurationMinutes: assignedDuration,
      lastCallTime: now,
      scheduledByAgreedTime: hasScheduled,
      notes: notesInput.trim(),
    });

    // Очистить форму
    setPhoneInput('');
    setCityInput('');
    setLinkInput('');
    setNotesInput('');
    setIsAutoDetected(false);
    setPhoneHasError(false);
    setCityHasError(false);
    setShowSchedulePanel(false);
    setScheduledMinutes(null);
    setScheduleMode('client_time');
    setClientTargetHour('18');
    setClientTargetMinute('00');
    setHoursInput('0');
    setMinutesInput('30');
    setShowCityDropdown(false);
  };

  // Enter в любом месте формы отправляет карточку в очередь
  useEffect(() => {
    const handleGlobalEnter = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        const activeModal = document.querySelector('[role="dialog"]');
        if (activeModal) return;

        // Если открыт список автодополнения городов и пользователь нажал Enter
        if (showCityDropdown && citySuggestions.length > 0) {
          e.preventDefault();
          handleSelectSuggestedCity(citySuggestions[0]);
          return;
        }

        const cleaned = cleanPhoneNumber(phoneInput);
        if (cleaned.length >= 11 && cityInput.trim().length >= 2) {
          e.preventDefault();
          handleSubmit();
        } else if (cleaned.length < 11 || !cityInput.trim()) {
          // Мягко подсветить незаполненные поля
          if (cleaned.length < 11) setPhoneHasError(true);
          if (!cityInput.trim()) setCityHasError(true);
        }
      }
    };

    window.addEventListener('keydown', handleGlobalEnter);
    return () => window.removeEventListener('keydown', handleGlobalEnter);
  }, [
    phoneInput,
    cityInput,
    linkInput,
    notesInput,
    scheduledMinutes,
    detectedUtcOffset,
    detectedMskOffset,
    detectedRegionName,
    showCityDropdown,
    citySuggestions,
    showSchedulePanel,
    scheduleMode,
    clientTargetHour,
    clientTargetMinute,
    hoursInput,
    minutesInput,
  ]);

  return (
    <div
      onMouseMove={handleUserActivity}
      onClick={handleUserActivity}
      className="bg-white rounded-3xl p-5 sm:p-6 border border-[#F1F3F5] shadow-mts-card transition-all duration-200 outline-none"
    >
      {/* Шапка формы */}
      <div className="flex items-center justify-between pb-3.5 border-b border-[#F1F3F5] gap-3">
        <div className="flex items-center gap-2">
          <h2 className="text-base sm:text-lg font-bold text-[#1D2023]">
            Карточка Клиента
          </h2>

          <div className="relative inline-block">
            <button
              type="button"
              onMouseEnter={() => setShowHelpTooltip(true)}
              onMouseLeave={() => setShowHelpTooltip(false)}
              onClick={() => setShowHelpTooltip(!showHelpTooltip)}
              className="text-[#8C95A0] hover:text-[#1D2023] transition-colors p-0.5 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {showHelpTooltip && (
              <div className="absolute left-0 top-full mt-1.5 w-64 p-2.5 rounded-xl bg-[#1D2023] text-white text-xs font-normal leading-relaxed shadow-lg z-30 pointer-events-none">
                Авторасчёт часового пояса и местного времени абонента по коду номера и городу РФ
              </div>
            )}
          </div>
        </div>

        {/* Время клиента */}
        <div className="flex items-center gap-3">
          <div className="text-xs font-bold text-[#1D2023] flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-[#626C77]" />
            <span>Время клиента: {clientClock.formattedTime}</span>
          </div>
        </div>
      </div>

      {/* Поля ввода (высота h-10, метки h-5, синяя 1px обводка при фокусе) */}
      <form onSubmit={handleSubmit} className="mt-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5 items-start">
          {/* Поле 1: Телефон (без эмодзи/иконки) */}
          <div className="md:col-span-4">
            <label
              htmlFor={phoneInputId}
              className="h-5 flex items-center text-[11px] font-bold text-[#1D2023] mb-1.5 uppercase tracking-wider"
            >
              Телефон
            </label>
            <input
              ref={phoneRef}
              id={phoneInputId}
              type="tel"
              placeholder="+7 (912) 000-00-00"
              value={phoneInput}
              onChange={handlePhoneChange}
              onKeyDown={handlePhoneKeyDown}
              autoComplete="off"
              className={`w-full h-10 px-3.5 rounded-xl border text-sm font-semibold transition-all placeholder-[#8C95A0] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none ${
                phoneHasError
                  ? 'bg-rose-50 border-rose-300 text-rose-900'
                  : 'border-[#D5D8DD] bg-white text-[#1D2023]'
              }`}
            />
          </div>

          {/* Поле 2: Город / Регион (без эмодзи, с выпадающим меню и (?) подсказкой) */}
          <div className="md:col-span-4 relative">
            <div className="flex items-center gap-1.5 mb-1.5 h-5">
              <label
                htmlFor={cityInputId}
                className="text-[11px] font-bold text-[#1D2023] uppercase tracking-wider cursor-pointer"
              >
                Город / Регион
              </label>

              {/* Вопросик с подсказкой про выбор точного города */}
              <div className="relative inline-block">
                <button
                  type="button"
                  onMouseEnter={() => setShowCityHelpTooltip(true)}
                  onMouseLeave={() => setShowCityHelpTooltip(false)}
                  onClick={() => setShowCityHelpTooltip(!showCityHelpTooltip)}
                  className="text-[#8C95A0] hover:text-[#1D2023] transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                </button>

                {showCityHelpTooltip && (
                  <div className="absolute left-0 bottom-full mb-2 w-60 p-2.5 rounded-xl bg-[#1D2023] text-white text-[11px] font-normal leading-tight shadow-xl z-30 pointer-events-none">
                    Введите полное название города РФ или выберите из списка. По полуслову карточка не создается, чтобы точно рассчитать часовой пояс абонента.
                  </div>
                )}
              </div>
            </div>

            <div className="relative">
              <input
                ref={cityInputRef}
                id={cityInputId}
                type="text"
                placeholder="г. Москва, Самара..."
                value={cityInput}
                onChange={handleCityChange}
                onFocus={() => {
                  if (citySuggestions.length > 0) setShowCityDropdown(true);
                }}
                autoComplete="off"
                className={`w-full h-10 px-3.5 rounded-xl border text-sm transition-all placeholder-[#8C95A0] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none ${
                  cityHasError
                    ? 'bg-rose-50 border-rose-300 text-rose-900'
                    : 'border-[#D5D8DD] bg-white text-[#1D2023]'
                }`}
              />

              {/* Выпадающий список автодополнения городов */}
              {showCityDropdown && citySuggestions.length > 0 && (
                <div
                  ref={dropdownRef}
                  className="absolute left-0 right-0 top-full mt-1 bg-white border border-[#D5D8DD] rounded-2xl shadow-xl z-40 max-h-56 overflow-y-auto py-1.5"
                >
                  {citySuggestions.map((item) => (
                    <button
                      key={`${item.city}-${item.regionName}`}
                      type="button"
                      onClick={() => handleSelectSuggestedCity(item)}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 text-xs transition-colors flex items-center justify-between cursor-pointer"
                    >
                      <span className="font-bold text-[#1D2023]">{item.city}</span>
                      <span className="text-[11px] text-[#626C77]">
                        {item.regionName} (МСК{item.mskOffset >= 0 ? `+${item.mskOffset}` : item.mskOffset})
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Поле 3: Ссылка на предложение (без эмодзи) */}
          <div className="md:col-span-4">
            <label
              htmlFor={linkInputId}
              className="h-5 flex items-center text-[11px] font-bold text-[#1D2023] mb-1.5 uppercase tracking-wider"
            >
              Ссылка на предложение
            </label>
            <div className="relative">
              <input
                id={linkInputId}
                type="text"
                placeholder="https://crm.mts.ru/leads/..."
                value={linkInput}
                onChange={(e) => {
                  handleUserActivity();
                  setLinkInput(e.target.value);
                }}
                className="w-full h-10 px-3.5 pr-11 rounded-xl border border-[#D5D8DD] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none text-sm text-[#1D2023] transition-all bg-white placeholder-[#8C95A0]"
              />
              <button
                type="button"
                onClick={handlePasteLink}
                title="Вставить из буфера обмена"
                className="absolute right-1.5 top-1.5 w-7 h-7 rounded-lg bg-[#F4F5F7] hover:bg-gray-200 text-[#0077FF] flex items-center justify-center transition-colors cursor-pointer"
              >
                {pastedFeedback ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <ClipboardPaste className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Быстрые подсказки городов */}
        <div className="mt-2.5 flex flex-wrap items-center gap-1.5 text-xs text-[#626C77]">
          <span className="font-semibold text-[#1D2023] text-[11px]">Частые:</span>
          {frequentCities.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => handleSelectQuickCity(c)}
              className="px-2 py-0.5 rounded-lg bg-[#F4F5F7] hover:bg-blue-50 hover:text-[#0077FF] text-[#1D2023] font-medium text-[11px] transition-colors cursor-pointer"
            >
              {c}
            </button>
          ))}
          {isAutoDetected && (
            <span className="ml-auto text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              {detectedRegionName}
            </span>
          )}
        </div>

        {/* Комментарий */}
        <div className="mt-3">
          <label
            htmlFor={notesInputId}
            className="h-5 flex items-center text-[11px] font-bold text-[#626C77] mb-1.5 uppercase tracking-wider"
          >
            Комментарий к заявке
          </label>
          <input
            id={notesInputId}
            type="text"
            placeholder="Причина ухода, скидка, тариф, пожелания клиента..."
            value={notesInput}
            onChange={(e) => {
              handleUserActivity();
              setNotesInput(e.target.value);
            }}
            className="w-full h-10 px-3.5 rounded-xl border border-[#D5D8DD] focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none text-xs text-[#1D2023] transition-all bg-white placeholder-[#8C95A0]"
          />
        </div>

        {/* Панель «Когда перезвонить ?» с двумя логичными режимами:
            1) По часам клиента (в 18:00 по его местному времени)
            2) Через интервал (+15м, +30м, +1ч и т.д.) */}
        {showSchedulePanel && (
          <div className="mt-3.5 p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-3 animate-in fade-in duration-150">
            {/* Переключатель режимов */}
            <div className="flex items-center justify-between gap-2 flex-wrap pb-1.5 border-b border-blue-200/60">
              <div className="inline-flex rounded-xl bg-white p-0.5 border border-blue-200">
                <button
                  type="button"
                  onClick={() => {
                    handleUserActivity();
                    setScheduleMode('client_time');
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    scheduleMode === 'client_time'
                      ? 'bg-[#0077FF] text-white shadow-xs'
                      : 'text-[#626C77] hover:text-[#1D2023]'
                  }`}
                >
                  🕒 По часам клиента (в 18:00)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleUserActivity();
                    setScheduleMode('interval');
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    scheduleMode === 'interval'
                      ? 'bg-[#0077FF] text-white shadow-xs'
                      : 'text-[#626C77] hover:text-[#1D2023]'
                  }`}
                >
                  ⏱️ Через интервал (+30м, +1ч)
                </button>
              </div>

              <div className="text-[11px] font-bold text-[#626C77]">
                У клиента сейчас: <span className="text-[#1D2023] font-extrabold">{clientClock.formattedTime}</span>
              </div>
            </div>

            {scheduleMode === 'client_time' ? (
              /* РЕЖИМ 1: По времени клиента */
              <div className="space-y-2.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-bold text-[#1D2023] mr-1">
                    Быстрый час абонента:
                  </span>
                  {[10, 12, 14, 16, 17, 18, 19, 20].map((h) => {
                    const clientHourNum = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 0));
                    const isSelected = clientHourNum === h && (parseInt(clientTargetMinute, 10) || 0) === 0;
                    return (
                      <button
                        key={h}
                        type="button"
                        onClick={() => handleQuickClientHour(h, 0)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                          isSelected && scheduledMinutes !== null
                            ? 'bg-[#0077FF] text-white border-[#0077FF]'
                            : 'bg-white hover:bg-blue-100 text-[#0077FF] border-blue-200'
                        }`}
                      >
                        {h}:00
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between gap-3 pt-1 border-t border-blue-200/60 flex-wrap">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#1D2023]">
                    <span>Перезвонить в:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="0"
                        max="23"
                        value={clientTargetHour}
                        onChange={(e) => {
                          handleUserActivity();
                          setClientTargetHour(e.target.value);
                          const h = Math.min(23, Math.max(0, parseInt(e.target.value, 10) || 0));
                          const m = Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
                          const preview = calculateTargetCallbackTimeByClientHour(detectedUtcOffset, h, m);
                          setScheduledMinutes(preview.minutesFromNow);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSubmit();
                          }
                        }}
                        placeholder="18"
                        className="w-12 h-8 px-1.5 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <span>:</span>
                      <input
                        type="number"
                        min="0"
                        max="59"
                        value={clientTargetMinute}
                        onChange={(e) => {
                          handleUserActivity();
                          setClientTargetMinute(e.target.value);
                          const h = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 0));
                          const m = Math.min(59, Math.max(0, parseInt(e.target.value, 10) || 0));
                          const preview = calculateTargetCallbackTimeByClientHour(detectedUtcOffset, h, m);
                          setScheduledMinutes(preview.minutesFromNow);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSubmit();
                          }
                        }}
                        placeholder="00"
                        className="w-12 h-8 px-1.5 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                    </div>

                    {(() => {
                      const h = Math.min(23, Math.max(0, parseInt(clientTargetHour, 10) || 0));
                      const m = Math.min(59, Math.max(0, parseInt(clientTargetMinute, 10) || 0));
                      const preview = calculateTargetCallbackTimeByClientHour(detectedUtcOffset, h, m);
                      return (
                        <span className="text-[#626C77] text-xs font-normal">
                          ({preview.isTomorrow ? 'завтра' : 'сегодня'}, через{' '}
                          {Math.floor(preview.minutesFromNow / 60) > 0
                            ? `${Math.floor(preview.minutesFromNow / 60)}ч `
                            : ''}
                          {preview.minutesFromNow % 60}мин)
                        </span>
                      );
                    })()}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
                      <Check className="w-3.5 h-3.5" />
                      Выбрано
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        handleUserActivity();
                        setShowSchedulePanel(false);
                        setScheduledMinutes(null);
                      }}
                      className="h-8 px-2.5 rounded-lg text-[#626C77] text-xs font-medium hover:text-[#FF0032] hover:bg-red-50 transition-colors cursor-pointer"
                    >
                      Сброс
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* РЕЖИМ 2: Через интервал */
              <div className="space-y-2.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-bold text-[#1D2023] mr-1">
                    Через сколько:
                  </span>
                  {[
                    { label: '+15м', h: 0, m: 15 },
                    { label: '+30м', h: 0, m: 30 },
                    { label: '+1ч', h: 1, m: 0 },
                    { label: '+2ч', h: 2, m: 0 },
                    { label: '+3ч', h: 3, m: 0 },
                  ].map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => handleQuickPreset(p.h, p.m)}
                      className={`px-2 py-0.5 rounded-md text-xs font-semibold transition-colors cursor-pointer border ${
                        scheduledMinutes === p.h * 60 + p.m
                          ? 'bg-[#0077FF] text-white border-[#0077FF]'
                          : 'bg-white hover:bg-blue-100 text-[#0077FF] border-blue-200'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center justify-between gap-3 pt-1 border-t border-blue-200/60 flex-wrap">
                  <div className="flex items-center gap-3 text-xs font-bold text-[#1D2023]">
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min="0"
                        max="48"
                        value={hoursInput}
                        onChange={(e) => {
                          setHoursInput(e.target.value);
                          const h = Math.max(0, parseInt(e.target.value, 10) || 0);
                          const m = Math.max(0, parseInt(minutesInput, 10) || 0);
                          setScheduledMinutes(h * 60 + m);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSubmit();
                          }
                        }}
                        placeholder="0"
                        className="w-14 h-8 px-2 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <span className="text-[#626C77] text-xs">час.</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min="0"
                        max="59"
                        value={minutesInput}
                        onChange={(e) => {
                          setMinutesInput(e.target.value);
                          const h = Math.max(0, parseInt(hoursInput, 10) || 0);
                          const m = Math.max(0, parseInt(e.target.value, 10) || 0);
                          setScheduledMinutes(h * 60 + m);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSubmit();
                          }
                        }}
                        placeholder="30"
                        className="w-14 h-8 px-2 rounded-lg bg-white border border-[#CBD5E1] text-center font-bold text-sm focus:border-[#0077FF] focus:ring-1 focus:ring-[#0077FF]/30 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <span className="text-[#626C77] text-xs">мин.</span>
                    </div>

                    {scheduledMinutes && scheduledMinutes > 0 ? (
                      <span className="text-emerald-700 text-xs font-bold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        +{scheduledMinutes} мин
                      </span>
                    ) : null}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        handleUserActivity();
                        setShowSchedulePanel(false);
                        setScheduledMinutes(null);
                      }}
                      className="h-8 px-2.5 rounded-lg text-[#626C77] text-xs font-medium hover:text-[#FF0032] hover:bg-red-50 transition-colors cursor-pointer"
                    >
                      Сброс
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Нижний ряд: Кнопка «Когда перезвонить ?» слева, «Записать» справа */}
        <div className="mt-4 pt-3.5 border-t border-[#F1F3F5] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleToggleSchedulePanel}
            className={`h-10 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              scheduledMinutes && scheduledMinutes > 0
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 hover:bg-blue-100 text-[#0077FF]'
            }`}
          >
            <PhoneForwarded className="w-3.5 h-3.5" />
            <span>
              {scheduledMinutes && scheduledMinutes > 0
                ? scheduleMode === 'client_time'
                  ? `Перезвон: в ${clientTargetHour.padStart(2, '0')}:${clientTargetMinute.padStart(2, '0')}`
                  : `Перезвон: +${scheduledMinutes}м`
                : 'Когда перезвонить ?'}
            </span>
          </button>

          <button
            type="submit"
            className="h-11 px-7 rounded-2xl bg-[#E30613] hover:bg-[#C50410] active:scale-[0.98] text-white text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2"
          >
            <span>Записать</span>
            <kbd className="px-1.5 py-0.5 rounded-md bg-black/20 text-white text-[10px] font-mono">
              Enter
            </kbd>
          </button>
        </div>
      </form>
    </div>
  );
};
