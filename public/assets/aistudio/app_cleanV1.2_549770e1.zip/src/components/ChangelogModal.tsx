import React, { useState } from 'react';
import { X, Wrench, Sparkles, RefreshCw, Bug, Trash2, CheckCircle2 } from 'lucide-react';
import { CHANGELOG_ITEMS, ChangelogCategory } from '../data/changelogData';

interface ChangelogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChangelogModal: React.FC<ChangelogModalProps> = ({ isOpen, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<ChangelogCategory | 'all'>('all');

  if (!isOpen) return null;

  const filteredItems = selectedCategory === 'all'
    ? CHANGELOG_ITEMS
    : CHANGELOG_ITEMS.filter((item) => item.category === selectedCategory);

  const getCategoryBadge = (category: ChangelogCategory) => {
    switch (category) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <Sparkles className="w-3 h-3" />
            <span>Новое</span>
          </span>
        );
      case 'update':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-[#0077FF] border border-blue-200">
            <RefreshCw className="w-3 h-3" />
            <span>Обновление</span>
          </span>
        );
      case 'fix':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <Bug className="w-3 h-3" />
            <span>Исправление</span>
          </span>
        );
      case 'remove':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-50 text-[#E30613] border border-red-200">
            <Trash2 className="w-3 h-3" />
            <span>Удалено</span>
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 border border-[#F1F3F5] shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
        {/* Шапка модального окна */}
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F5]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gray-100 text-[#1D2023] flex items-center justify-center shadow-2xs">
              <Wrench className="w-5 h-5 text-[#1D2023]" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#1D2023]">Журнал обновлений АРМ</h3>
              <p className="text-xs text-[#626C77]">
                Патч-ноут улучшений, исправлений и новых функций
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl hover:bg-gray-100 text-[#626C77] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Фильтры по категориям */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#1D2023] text-white shadow-2xs'
                : 'bg-[#F4F5F7] hover:bg-gray-200 text-[#626C77]'
            }`}
          >
            Все ({CHANGELOG_ITEMS.length})
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('new')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === 'new'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Новое</span>
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('update')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === 'update'
                ? 'bg-[#0077FF] text-white shadow-2xs'
                : 'bg-blue-50 hover:bg-blue-100 text-[#0077FF]'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Обновление</span>
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('fix')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === 'fix'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-700'
            }`}
          >
            <Bug className="w-3.5 h-3.5" />
            <span>Исправление</span>
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('remove')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === 'remove'
                ? 'bg-[#E30613] text-white shadow-2xs'
                : 'bg-red-50 hover:bg-red-100 text-[#E30613]'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Удалено</span>
          </button>
        </div>

        {/* Список изменений */}
        <div className="space-y-2.5 pt-2">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF] hover:border-[#D6DAE0] transition-colors"
            >
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  {getCategoryBadge(item.category)}
                  <span className="text-xs font-extrabold text-[#1D2023] leading-snug">
                    {item.title}
                  </span>
                </div>
                <span className="text-[10px] font-bold text-[#8C95A0] shrink-0 tabular-nums">
                  v{item.version}
                </span>
              </div>
              <p className="text-xs text-[#4F5B66] leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Нижняя кнопка закрытия */}
        <div className="pt-3 border-t border-[#F1F3F5] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-6 rounded-xl bg-[#1D2023] hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
