import React from 'react';
import { Bell, Copy, ExternalLink, Check, ChevronDown } from 'lucide-react';
import { ClientLead } from '../types';

interface UrgentAlertBannerProps {
  expiredLeads: ClientLead[];
  onCopyPhone: (phone: string) => void;
  copiedId: string | null;
  onSelectLead?: (leadId: string) => void;
}

export const UrgentAlertBanner: React.FC<UrgentAlertBannerProps> = ({
  expiredLeads,
  onCopyPhone,
  copiedId,
  onSelectLead,
}) => {
  if (expiredLeads.length === 0) return null;

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-3xl p-4 sm:p-5 shadow-mts-card transition-all animate-in fade-in duration-300">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-[#F1F3F5]">
        <div className="flex items-center gap-2.5">
          {/* Скрин 7: Колокольчик без bounce, красный в сером кружке */}
          <div className="w-8 h-8 rounded-full bg-[#F4F5F7] text-[#E30613] flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-[#1D2023] leading-tight">
              ПОРА ПЕРЕЗВОНИТЬ КЛИЕНТУ!
            </h3>
            <p className="text-xs text-[#626C77] font-normal mt-0.5">
              Синхронизировано с часами компьютера: подошло время звонка ({expiredLeads.length})
            </p>
          </div>
        </div>
      </div>

      <div className="mt-3 space-y-2.5">
        {expiredLeads.map((lead, idx) => (
          <div
            key={lead.id}
            onClick={() => onSelectLead?.(lead.id)}
            className="bg-[#F8F9FA] hover:bg-[#F1F3F5] rounded-2xl p-3 border border-[#EBECEF] flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              {/* Пульсирующая точка активна только на самой первой (срочной) карточке */}
              {idx === 0 ? (
                <span className="w-2.5 h-2.5 rounded-full bg-[#E30613] animate-ping shrink-0" />
              ) : (
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-[#1D2023] tracking-tight group-hover:text-[#0077FF] transition-colors">
                    {lead.phone}
                  </span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-50 text-[#E30613]">
                    Попытка {lead.attemptCount}/{lead.maxAttempts}
                  </span>
                </div>
                <div className="text-xs text-[#626C77] flex items-center gap-2 mt-0.5">
                  <span>{lead.city}</span>
                  {lead.notes && (
                    <>
                      <span>•</span>
                      <span className="truncate max-w-[200px]">{lead.notes}</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Кнопки действий */}
            <div
              className="flex items-center gap-2 shrink-0"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => onCopyPhone(lead.phone)}
                className="h-9 px-3 rounded-xl bg-white border border-[#D5D8DD] hover:bg-gray-50 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                title="Скопировать номер"
              >
                {copiedId === lead.phone ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Скопировано</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-[#626C77]" />
                    <span>Копировать</span>
                  </>
                )}
              </button>

              {lead.uniqueLink && (
                <a
                  href={lead.uniqueLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-9 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#0077FF] text-xs font-bold transition-colors flex items-center gap-1.5"
                  title="Открыть предложение клиенту в CRM"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Предложение</span>
                </a>
              )}

              {onSelectLead && (
                <button
                  type="button"
                  onClick={() => onSelectLead(lead.id)}
                  title="Перейти к карточке в очереди"
                  className="h-9 px-2.5 rounded-xl bg-[#F4F5F7] hover:bg-blue-50 hover:text-[#0077FF] text-[#626C77] text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">В очереди</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
