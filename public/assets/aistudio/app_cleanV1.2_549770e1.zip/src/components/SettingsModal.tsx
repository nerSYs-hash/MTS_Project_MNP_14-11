import React, { useState, useEffect } from 'react';
import { X, Volume2, Bell, RotateCcw, Download, Copy, Check, HelpCircle, RotateCw, Upload, ShieldCheck, Minus, Plus } from 'lucide-react';
import { TimerSettings, ShiftStats, ClientLead } from '../types';
import { playChimeSound, requestNotificationPermission } from '../utils/audioAlert';
import { generateShiftReportText } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TimerSettings;
  onSaveSettings: (settings: TimerSettings) => void;
  stats: ShiftStats;
  leads: ClientLead[];
  onResetShift: () => void;
  onRestoreBackup?: () => boolean;
  onImportLeadsText?: (text: string) => number;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  stats,
  leads,
  onResetShift,
  onRestoreBackup,
  onImportLeadsText,
}) => {
  const [collapseDelay, setCollapseDelay] = useState(
    settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
  );
  const [soundEnabled, setSoundEnabled] = useState(settings.soundEnabled);
  const [volume, setVolume] = useState(settings.volume);
  const [includeWithoutTpInSaved, setIncludeWithoutTpInSaved] = useState(
    settings.includeWithoutTpInSaved !== false
  );
  const [includeEiInSaved, setIncludeEiInSaved] = useState(
    settings.includeEiInSaved !== false
  );
  const [reportCopied, setReportCopied] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [showCollapseTooltip, setShowCollapseTooltip] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState<string | null>(null);
  const [showImportBox, setShowImportBox] = useState(false);
  const [importText, setImportText] = useState('');
  const [importResultMsg, setImportResultMsg] = useState<string | null>(null);

  // Синхронизация полей настроек при каждом открытии модального окна
  useEffect(() => {
    if (isOpen) {
      setCollapseDelay(
        settings.collapseDelayMinutes !== undefined ? settings.collapseDelayMinutes : 3
      );
      setSoundEnabled(settings.soundEnabled);
      setVolume(settings.volume);
      setIncludeWithoutTpInSaved(settings.includeWithoutTpInSaved !== false);
      setIncludeEiInSaved(settings.includeEiInSaved !== false);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings({
      ...settings,
      collapseDelayMinutes: collapseDelay,
      soundEnabled,
      volume,
      includeWithoutTpInSaved,
      includeEiInSaved,
    });
    onClose();
  };

  const handleTestSound = () => {
    playChimeSound(volume);
  };

  const handleRequestNotifications = async () => {
    const granted = await requestNotificationPermission();
    if (granted) {
      alert('Всплывающие уведомления браузера успешно включены!');
    } else {
      alert('Уведомления не разрешены в настройках браузера.');
    }
  };

  const handleCopyReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    navigator.clipboard.writeText(reportText);
    setReportCopied(true);
    setTimeout(() => setReportCopied(false), 2000);
  };

  const handleDownloadReport = () => {
    const reportText = generateShiftReportText(stats, leads);
    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MTS_MNP_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 border border-[#F1F3F5] shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto overflow-x-hidden">
        {/* Шапка модалки */}
        <div className="flex items-center justify-between pb-3.5 border-b border-[#F1F3F5]">
          <div>
            <h3 className="text-lg font-bold text-[#1D2023]">Настройки рабочего места</h3>
            <p className="text-xs text-[#626C77] font-normal mt-0.5">
              Сворачивание рабочего места, звук оповещений и отчет смены
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl hover:bg-gray-100 text-[#626C77] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. Блок: Режим ожидания и автосворачивание АРМ в центр */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider">
                Режим ожидания (сворачивание в центр)
              </span>

              <button
                type="button"
                onClick={() => setShowCollapseTooltip((v) => !v)}
                className={`p-1 rounded-lg transition-colors cursor-pointer ${
                  showCollapseTooltip ? 'bg-blue-50 text-[#0077FF]' : 'text-[#8C95A0] hover:text-[#1D2023]'
                }`}
                title="Справка по режиму ожидания (нажмите)"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
            </div>

            {/* Быстрый переключатель Вкл / Выкл */}
            <button
              type="button"
              onClick={() => {
                if (collapseDelay > 0) {
                  setCollapseDelay(0);
                } else {
                  setCollapseDelay(3);
                }
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                collapseDelay > 0
                  ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                  : 'bg-[#F4F5F7] text-[#626C77] hover:bg-gray-200'
              }`}
            >
              {collapseDelay > 0 ? 'Включен' : 'Выключен'}
            </button>
          </div>

          {/* Информационная подсказка без тряски */}
          {showCollapseTooltip && (
            <div className="p-3 rounded-2xl bg-blue-50/80 border border-blue-100 text-[#1D2023] text-xs leading-relaxed flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#0077FF] mt-1.5 shrink-0" />
              <span>
                При неактивности оператора карточка клиента и очередь плавно сворачиваются, а 4 блока KPI перемещаются в центр экрана. При наступлении времени любого перезвона всё автоматически мгновенно разворачивается!
              </span>
            </div>
          )}

          {/* Состояние когда включено: точная регулировка по минутам */}
          {collapseDelay > 0 ? (
            <div className="space-y-2.5 p-3 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF]">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#626C77] font-medium">Время до сворачивания:</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setCollapseDelay((prev) => Math.max(1, prev - 1))}
                    disabled={collapseDelay <= 1}
                    className="w-8 h-8 rounded-xl bg-white hover:bg-gray-100 disabled:opacity-40 text-[#1D2023] border border-gray-200 flex items-center justify-center font-bold text-sm transition-colors cursor-pointer"
                    title="Уменьшить на 1 минуту"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-xl border border-gray-200">
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={collapseDelay}
                      onChange={(e) => {
                        const v = parseInt(e.target.value, 10);
                        if (!isNaN(v)) {
                          setCollapseDelay(Math.min(60, Math.max(1, v)));
                        }
                      }}
                      className="w-8 text-center font-extrabold text-[#1D2023] text-sm focus:outline-none"
                    />
                    <span className="text-xs font-bold text-[#626C77]">мин</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCollapseDelay((prev) => Math.min(60, prev + 1))}
                    disabled={collapseDelay >= 60}
                    className="w-8 h-8 rounded-xl bg-white hover:bg-gray-100 disabled:opacity-40 text-[#1D2023] border border-gray-200 flex items-center justify-center font-bold text-sm transition-colors cursor-pointer"
                    title="Увеличить на 1 минуту"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Быстрые кнопки выбора минут */}
              <div className="grid grid-cols-5 gap-1.5 pt-1 border-t border-[#E9ECEF]">
                {[1, 2, 3, 5, 10].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setCollapseDelay(mins)}
                    className={`h-7 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center ${
                      collapseDelay === mins
                        ? 'bg-[#1D2023] text-white shadow-2xs'
                        : 'bg-white hover:bg-gray-100 text-[#626C77] hover:text-[#1D2023] border border-gray-200'
                    }`}
                  >
                    {mins} мин
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF] flex items-center justify-between">
              <span className="text-xs text-[#626C77]">Автосворачивание отключено — рабочее место всегда открыто</span>
              <button
                type="button"
                onClick={() => setCollapseDelay(3)}
                className="px-3 py-1 rounded-xl bg-[#1D2023] text-white text-xs font-bold transition-all cursor-pointer hover:bg-gray-800"
              >
                Включить (3 мин)
              </button>
            </div>
          )}
        </div>

        {/* 2. Блок: Настройки шторки детализации (ТП • ЕИ) */}
        <div className="pt-3 border-t border-[#F1F3F5] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
              Учёт детализации (шторка ТП • ЕИ)
            </span>
            <span className="text-[11px] text-[#626C77] font-medium">
              Карточка «Сохранено»
            </span>
          </div>

          <div className="space-y-2 p-3 rounded-2xl bg-[#F8F9FA] border border-[#E9ECEF]">
            {/* Чекбокс 1: Без смены ТП */}
            <div
              onClick={() => setIncludeWithoutTpInSaved(!includeWithoutTpInSaved)}
              className="flex items-start gap-2.5 cursor-pointer select-none group"
            >
              <div
                className={`w-5 h-5 rounded-lg border mt-0.5 shrink-0 flex items-center justify-center transition-all ${
                  includeWithoutTpInSaved
                    ? 'bg-[#E30613] border-[#E30613] text-white shadow-xs'
                    : 'bg-white border-[#D5D8DD] group-hover:border-[#0077FF]'
                }`}
              >
                {includeWithoutTpInSaved && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
              <div className="text-xs">
                <div className="font-bold text-[#1D2023]">
                  Учитывать «1) Без смены ТП» в общем числе сохранений
                </div>
                <div className="text-[#626C77] text-[11px] mt-0.5">
                  При включении добавление сохранений без смены ТП засчитывается в общий счетчик «Сохранено клиентов» и конверсию смены
                </div>
              </div>
            </div>

            {/* Чекбокс 2: ЕИ */}
            <div
              onClick={() => setIncludeEiInSaved(!includeEiInSaved)}
              className="flex items-start gap-2.5 cursor-pointer select-none group pt-2 border-t border-[#E9ECEF]"
            >
              <div
                className={`w-5 h-5 rounded-lg border mt-0.5 shrink-0 flex items-center justify-center transition-all ${
                  includeEiInSaved
                    ? 'bg-[#E30613] border-[#E30613] text-white shadow-xs'
                    : 'bg-white border-[#D5D8DD] group-hover:border-[#0077FF]'
                }`}
              >
                {includeEiInSaved && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
              <div className="text-xs">
                <div className="font-bold text-[#1D2023]">
                  Учитывать «2) ЕИ» в общем числе сохранений
                </div>
                <div className="text-[#626C77] text-[11px] mt-0.5">
                  При включении каждое сохранение по ЕИ засчитывается в общий счетчик «Сохранено клиентов» и конверсию смены
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Блок: Звуковые сигналы (фирменная галочка МТС, единый дизайн кнопок) */}
        <div className="pt-3 border-t border-[#F1F3F5] space-y-3">
          <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
            Звуковые сигналы
          </span>

          <div className="flex items-center justify-between gap-3">
            {/* Фирменный чекбокс МТС Red */}
            <div
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="flex items-center gap-2.5 cursor-pointer select-none group"
            >
              <div
                className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                  soundEnabled
                    ? 'bg-[#E30613] border-[#E30613] text-white shadow-xs'
                    : 'bg-white border-[#D5D8DD] group-hover:border-[#0077FF]'
                }`}
              >
                {soundEnabled && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
              <span className="text-xs text-[#1D2023] font-semibold">
                Воспроизводить звуковой сигнал МТС при 00:00
              </span>
            </div>

            {/* Кнопка Тест звука в фирменном стиле */}
            <button
              type="button"
              onClick={handleTestSound}
              className="h-8 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#0077FF] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Тест звука</span>
            </button>
          </div>

          {/* Ползунок громкости в фирменном красном МТС */}
          <div className="flex items-center gap-3">
            <span className="text-xs text-[#626C77]">Громкость:</span>
            <input
              type="range"
              min="0.1"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="flex-1 accent-[#E30613] cursor-pointer h-1.5 bg-gray-200 rounded-lg"
            />
            <span className="text-xs font-bold text-[#1D2023] w-9 text-right tabular-nums">
              {Math.round(volume * 100)}%
            </span>
          </div>

          <button
            type="button"
            onClick={handleRequestNotifications}
            className="w-full h-9 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-xs font-bold text-[#1D2023] transition-colors border border-[#EBECEF] cursor-pointer flex items-center justify-center gap-2"
          >
            <Bell className="w-3.5 h-3.5 text-[#0077FF]" />
            <span>Включить всплывающие уведомления браузера</span>
          </button>
        </div>

        {/* 3. Отчёт смены */}
        <div className="pt-3 border-t border-[#F1F3F5] space-y-2.5">
          <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
            Отчёт смены
          </span>
          <div className="p-3 bg-[#F4F5F7] rounded-2xl text-xs space-y-1 font-mono text-[#1D2023] border border-[#EBECEF]">
            <div>• Всего звонков: {stats.totalCallsCount}</div>
            <div>• Сохранено клиентов: {stats.savedCount}</div>
            <div>• Конверсия смены: {stats.conversionRate.toFixed(1)}%</div>
          </div>

          <div className="flex items-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={handleCopyReport}
              className="flex-1 h-9 px-3 rounded-xl bg-[#1D2023] hover:bg-black text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              {reportCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{reportCopied ? 'Скопировано в буфер' : 'Скопировать отчёт'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadReport}
              className="h-9 px-3.5 rounded-xl bg-[#F4F5F7] hover:bg-gray-200 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-[#EBECEF]"
            >
              <Download className="w-4 h-4 text-[#626C77]" />
              <span>Файл .txt</span>
            </button>
          </div>
        </div>

        {/* 4. Резервные копии и восстановление заявок */}
        <div className="pt-3 border-t border-[#F1F3F5] space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#1D2023] uppercase tracking-wider block">
              Резервные копии и восстановление
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (onRestoreBackup) {
                    const ok = onRestoreBackup();
                    if (ok) {
                      setRestoreFeedback('Рабочие заявки успешно восстановлены из резервной копии!');
                      setTimeout(() => setRestoreFeedback(null), 3500);
                    } else {
                      setRestoreFeedback('Резервная копия пуста или еще не была создана.');
                      setTimeout(() => setRestoreFeedback(null), 3500);
                    }
                  }
                }}
                className="text-xs font-bold text-[#0077FF] hover:text-[#0055CC] flex items-center gap-1 cursor-pointer"
                title="Восстановить предыдущий список заявок из автосохраненного бэкапа"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Восстановить из авто-бэкапа</span>
              </button>
            </div>
          </div>

          {restoreFeedback && (
            <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-xs font-semibold text-[#0077FF] flex items-center gap-2 animate-in fade-in">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{restoreFeedback}</span>
            </div>
          )}

          {/* Быстрый импорт номеров списком */}
          <div>
            {!showImportBox ? (
              <button
                type="button"
                onClick={() => setShowImportBox(true)}
                className="text-xs text-[#626C77] hover:text-[#1D2023] font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-[#0077FF]" />
                <span>Вставить номера списком для восстановления (Excel / CRM / Блокнот)</span>
              </button>
            ) : (
              <div className="p-3 bg-[#F4F5F7] rounded-2xl border border-[#D5D8DD] space-y-2">
                <label className="text-[11px] font-bold text-[#1D2023] block">
                  Вставьте номера абонентов (каждый с новой строки или через запятую):
                </label>
                <textarea
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="+7 (912) 000-00-00&#10;+79270000000&#10;89991234567..."
                  rows={3}
                  className="w-full p-2.5 rounded-xl bg-white border border-[#CBD5E1] text-xs font-mono text-[#1D2023] focus:border-[#0077FF] focus:outline-none"
                />
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] text-[#626C77]">
                    Регионы и таймеры рассчитаются автоматически
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowImportBox(false);
                        setImportText('');
                      }}
                      className="px-2.5 py-1 text-xs text-[#626C77] hover:text-[#1D2023] cursor-pointer"
                    >
                      Отмена
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (onImportLeadsText && importText.trim()) {
                          const count = onImportLeadsText(importText);
                          setImportResultMsg(`Успешно добавлено ${count} заявок в очередь!`);
                          setImportText('');
                          setShowImportBox(false);
                          setTimeout(() => setImportResultMsg(null), 3000);
                        }
                      }}
                      className="px-3.5 py-1 rounded-xl bg-[#0077FF] hover:bg-[#0055CC] text-white text-xs font-bold cursor-pointer"
                    >
                      Импортировать
                    </button>
                  </div>
                </div>
              </div>
            )}

            {importResultMsg && (
              <div className="mt-1.5 p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800">
                {importResultMsg}
              </div>
            )}
          </div>
        </div>

        {/* 5. Сброс смены */}
        <div className="pt-3 border-t border-[#F1F3F5] flex items-center justify-between gap-3 text-xs">
          {confirmReset ? (
            <div className="flex items-center gap-2">
              <span className="text-[#E30613] font-bold">Сбросить счетчики смены?</span>
              <button
                type="button"
                onClick={() => {
                  onResetShift();
                  setConfirmReset(false);
                }}
                className="px-3 py-1 bg-[#E30613] text-white rounded-lg font-bold cursor-pointer"
              >
                Да
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-2 py-1 text-gray-500 hover:text-black cursor-pointer"
              >
                Отмена
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="text-[#E30613] hover:underline font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Сбросить счетчики смены</span>
            </button>
          )}
        </div>

        {/* Нижние кнопки */}
        <div className="pt-3 border-t border-[#F1F3F5] flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-5 rounded-xl border border-[#D5D8DD] hover:bg-gray-50 text-[#1D2023] text-xs font-bold transition-colors cursor-pointer"
          >
            Закрыть
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="h-10 px-6 rounded-xl bg-[#E30613] hover:bg-[#C50410] active:scale-[0.98] text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};
