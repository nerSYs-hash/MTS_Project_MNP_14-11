const { contextBridge, ipcRenderer } = require('electron');

// Безопасный IPC мост между десктопной средой и веб-интерфейсом
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,
});
